#include "nl_movement.h"
#if defined(_WIN32)
#define NL_MOVEMENT_EXPORT extern "C" __declspec(dllexport)
#define NL_MOVEMENT_CALL __cdecl
#else
#define NL_MOVEMENT_EXPORT extern "C"
#define NL_MOVEMENT_CALL
#endif

// A stateless ABI: no entity writes, hooks, ConVar changes or packet manipulation.
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_api_version() {
    return nl_movement::abi_version;
}
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_input_size() {
    return sizeof(nl_movement::Input);
}
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_output_size() {
    return sizeof(nl_movement::Output);
}
NL_MOVEMENT_EXPORT int NL_MOVEMENT_CALL nl_movement_calculate(
    const nl_movement::Input* input,nl_movement::Output* output) {
    return nl_movement::calculate(input,output);
}

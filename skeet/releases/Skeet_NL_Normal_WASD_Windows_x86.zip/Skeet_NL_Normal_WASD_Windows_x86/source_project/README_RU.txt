Skeet 8802 + реконструированный Normal/WASD strafe Neverlose

Это исходники, из которых собраны DLL и injector Windows x86. Подготовлен перенос конкретной вычислительной
ветки Normal/WASD; полный movement Neverlose 1:1 здесь не заявляется.
Directional/circle-strafe, его предиктор столкновений и вся система prediction
Neverlose не перенесены. Autopeek и автостоп перед выстрелом не менялись,
согласно выбранной пользователем области работы.

Состав и подключение

  source/skeet/nl_movement.h   — расчёт направления, угла и стороны;
  source/skeet/nl_movement.cpp — четыре C ABI export-функции без состояния;
  lua/nl_movement.lua         — адаптер setup_command и checkbox;
  tests/                     — переносимые проверки и сравнение с NL SSE.

nl_movement.cpp включён в Visual Studio project и build_windows.py. При будущей
сборке его функции попадают в skeet.dll. build_windows.py выполнен успешно.
После загрузки собранного wrapper пользователь сможет загрузить
lua/nl_movement.lua в штатном Lua-разделе и включить MISC -> Movement ->
Neverlose WASD strafe. Сглаживание 0..100, начальное значение 50.

С текущей прежней DLL без новых exports адаптер включение отвергает:
команды не меняются, исходный Air strafe не отключается. Адаптер ищет уже
загруженный skeet.dll, проверяет версию ABI и размеры Input/Output.
Если wrapper переименован, имя модуля нужно поправить в Lua. Скрипт сам DLL
не загружает и не инжектирует. Настройки чужих DLL/модулей он не патчит.

Во включённом состоянии штатный Air strafe отключается, чтобы два алгоритма
не обрабатывали одну команду. При выключении и выгрузке исходное значение
восстанавливается с учётом чужого изменения. Checkbox изначально выключен.
Если другой movement-скрипт также пишет forwardmove/sidemove/move_yaw,
между ними нет общего арбитра; такую совместную работу здесь не проверяли.

Что реконструировано

В supplied nl.i64 / recovered image с базой 412A0000 разобраны:
  WASD prefix       4142911A..41429234;
  Normal steer      41429234..414297B0;
  AngleVectors      41574070..4157423A.

Подтверждённая математика: горизонтальная скорость, ideal=min(845.5/speed,90),
преобразование WASD через float AngleVectors, atan2, нормализация delta,
correction=ideal*0.04*(100-setting), ворота speed>80 и разворота >170,
выбор стороны и phase. Сохраняется float-порядок скалярных SSE-операций.
В native ABI нет абсолютных адресов Neverlose, чтения памяти противников,
изменения hit chance, lagrecords, seed, tickbase, packet state и стрельбы.
Исходный Skeet core не получает новых исполняемых detour-патчей для этого модуля.

Результаты проверок

  3294 steering cases: угол и сторона совпали с исходным NL SSE;
  1200 WASD-prefix cases: исходный AngleVectors и дальнейшая ветка также совпали;
  во всех 4494 случаях итоговый угол совпал побитово после округления float32;
  193 C++ boundary/host guard cases прошли;
  15 групп Lua host-policy/FFI проверок прошли.

SSE выполнялся в Unicorn на данных предоставленного NL image, без запуска
его loader/DLL/entrypoint. Защищённое получение ConVar заменено границей с
заданным cl_sidespeed; sin/cos/atan2/fmod — host libm с исходными float stores.
Следовательно, это дифференциальная проверка названной ветки при заданных
входах и контролируемых зависимостях, а не проверка всего Neverlose.
Lua тест использует моки GameSense/Windows exports и не доказывает Windows ABI.
Переносимые C++ тесты компилировались в Linux executable. Затем собраны DLL и
injector Windows x86. У готовой DLL проверены ресурсы и экспорты; 300 вызовов
скомпилированного movement-кода в Unicorn совпали с portable C++ по float32 углу.
DLL entrypoint и injector при этих проверках не исполнялись; atan2 — контролируемая
математическая граница. Полная Windows-загрузка в игре этим не проверена.

Границы соответствия

Нативный eligibility/settings prefix и Directional не перенесены. Адаптер
использует состояние local entity через API GameSense, а не собственный
предикт Neverlose. Фазу закрепляет за уникальным номером команды: повторный
расчёт той же команды пересчитывает скорость с той же фазой и исходным WASD.
На земле, в воде, на ladder/noclip и при walk управление не перезаписывается;
air crouch поддерживается. Это явные правила host-адаптации, а не заявление
о побайтовом совпадении всех правил исходного клиента Neverlose.

Из setup_command записываются только movement floats, move_yaw и четыре
направляющих input bit. Pitch/yaw, jump/duck, attack, allow_send_packet и
служебные команды не переписываются. Публичное назначение move_yaw и порядок
setup_command сверены с документацией:
https://docs.gamesense.gs/docs/events/setup_command/

Ранее пользователь наблюдал остановки с Lua-стрейфером на серверах. Эта версия
проверена по математике и правилам адаптера, но исчезновение той проблемы
не подтверждено: запуск в игре, серверные коррекции,
совместимость с AA/другими Lua, FPS и фактическая скорость не измерялись.
Нельзя называть весь movement 1:1 или обещать отсутствие остановок по этим тестам.

Базовый проект

Основан на Skeet_Default_Gameplay_Source_8802: прежние scan/precision/motion,
body preference и DT accuracy модули удалены; используется исходный skeet.bin.
SHA256 core:
bbb5ee98d00db63dfc5c454b238d5edd3f809976686be226dbc5f6ae55018b07
Меню/визуалы/инвентарь и загрузчик совместимости сохранены. Прежние архивы,
afterglow.lua и afterglow_adaptive.lua не изменялись.

Повтор проверки исходников:
  python verify_source.py
Для portable C++ проверок нужны g++ или другой C++17 compiler, без fast-math:
  g++ -std=c++17 -O2 -ffp-contract=off tests/nl_movement_probe.cpp source/skeet/nl_movement.cpp -o nl_movement_probe
  ./nl_movement_probe
Для сравнения с бинарником нужны Python+unicorn и собственный nl.image.bin:
  python tests/compare_nl_sse.py /path/to/nl.image.bin ./nl_movement_probe
Для host-policy тестов нужен Python+lupa:
  python tests/test_lua_adapter.py
Результаты текущей сессии сохранены в reports/.

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <cwchar>
#include <cstdint>
#include <cstring>
#include "../loader_protocol.h"
#include "../improved_protocol.h"

struct Handle {
    HANDLE value;
    explicit Handle(HANDLE h = nullptr) : value(h) {}
    ~Handle() { if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value); }
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
};
static int error(const char* operation) {
    DWORD code = GetLastError();
    char description[512]{};
    FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, code, 0, description, sizeof(description), nullptr);
    std::fprintf(stderr, "%s (Windows error %lu): %s\n", operation, code, description);
    return 1;
}
static DWORD game_pid() {
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0));
    if (snapshot.value == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W item{}; item.dwSize = sizeof(item);
    if (Process32FirstW(snapshot.value, &item)) do {
        if (!_wcsicmp(item.szExeFile, L"csgo.exe")) return item.th32ProcessID;
    } while (Process32NextW(snapshot.value, &item));
    return 0;
}
static std::uintptr_t remote_load_library(HANDLE process, DWORD pid) {
    auto fn = GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
    HMODULE owner = nullptr;
    if (!fn || !GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
        GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, reinterpret_cast<LPCWSTR>(fn), &owner)) return 0;
    wchar_t path[MAX_PATH]{};
    if (!GetModuleFileNameW(owner, path, MAX_PATH)) return 0;
    const wchar_t* name = std::wcsrchr(path, L'\\');
    name = name ? name + 1 : path;
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid));
    if (snapshot.value == INVALID_HANDLE_VALUE) return 0;
    MODULEENTRY32W item{}; item.dwSize = sizeof(item);
    if (Module32FirstW(snapshot.value, &item)) do {
        if (_wcsicmp(item.szModule, name)) continue;
        auto* local = reinterpret_cast<BYTE*>(owner);
        auto* local_dos = reinterpret_cast<IMAGE_DOS_HEADER*>(local);
        auto* local_nt = reinterpret_cast<IMAGE_NT_HEADERS32*>(local + local_dos->e_lfanew);
        IMAGE_DOS_HEADER dos{}; IMAGE_NT_HEADERS32 nt{};
        SIZE_T got = 0;
        if (!ReadProcessMemory(process, item.modBaseAddr, &dos, sizeof(dos), &got) ||
            got != sizeof(dos) || dos.e_magic != IMAGE_DOS_SIGNATURE ||
            dos.e_lfanew < 0 || static_cast<DWORD>(dos.e_lfanew) > (item.modBaseSize >= sizeof(nt) ? item.modBaseSize - sizeof(nt) : 0) ||
            !ReadProcessMemory(process, item.modBaseAddr + dos.e_lfanew, &nt, sizeof(nt), &got) ||
            got != sizeof(nt) || nt.Signature != IMAGE_NT_SIGNATURE ||
            nt.FileHeader.Machine != IMAGE_FILE_MACHINE_I386 ||
            nt.FileHeader.TimeDateStamp != local_nt->FileHeader.TimeDateStamp ||
            nt.OptionalHeader.SizeOfImage != local_nt->OptionalHeader.SizeOfImage) return 0;
        const auto offset = reinterpret_cast<std::uintptr_t>(fn) - reinterpret_cast<std::uintptr_t>(owner);
        if (offset >= item.modBaseSize) return 0;
        return reinterpret_cast<std::uintptr_t>(item.modBaseAddr) + offset;
    } while (Module32NextW(snapshot.value, &item));
    return 0;
}
// SEC_IMAGE maps the on-disk PE layout for inspection; it does not execute DllMain.
static DWORD status_rva(const wchar_t* path,const char* symbol,SIZE_T symbol_size,SIZE_T object_size) {
    Handle file(CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr));
    if (file.value == INVALID_HANDLE_VALUE) return 0;
    Handle mapping(CreateFileMappingW(file.value, nullptr, PAGE_READONLY | SEC_IMAGE, 0, 0, nullptr));
    if (!mapping.value) return 0;
    auto* base = static_cast<BYTE*>(MapViewOfFile(mapping.value, FILE_MAP_READ, 0, 0, 0));
    if (!base) return 0;
    DWORD result = 0;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS32*>(base + dos->e_lfanew);
    if (nt->FileHeader.Machine == IMAGE_FILE_MACHINE_I386 &&
        nt->OptionalHeader.Magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC &&
        (nt->FileHeader.Characteristics & IMAGE_FILE_DLL)) {
        const DWORD size = nt->OptionalHeader.SizeOfImage;
        auto inside = [size](DWORD rva, std::uint64_t length) { return rva < size && length <= size - rva; };
        const auto dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
        if (inside(dir.VirtualAddress, sizeof(IMAGE_EXPORT_DIRECTORY))) {
            auto* exports = reinterpret_cast<IMAGE_EXPORT_DIRECTORY*>(base + dir.VirtualAddress);
            if (inside(exports->AddressOfNames, std::uint64_t(exports->NumberOfNames) * 4) &&
                inside(exports->AddressOfNameOrdinals, std::uint64_t(exports->NumberOfNames) * 2) &&
                inside(exports->AddressOfFunctions, std::uint64_t(exports->NumberOfFunctions) * 4)) {
                auto* names = reinterpret_cast<DWORD*>(base + exports->AddressOfNames);
                auto* ordinals = reinterpret_cast<WORD*>(base + exports->AddressOfNameOrdinals);
                auto* functions = reinterpret_cast<DWORD*>(base + exports->AddressOfFunctions);
                for (DWORD i = 0; i < exports->NumberOfNames; ++i) {
                    if (!inside(names[i], symbol_size) ||
                        std::memcmp(base + names[i], symbol, symbol_size) ||
                        ordinals[i] >= exports->NumberOfFunctions) continue;
                    const DWORD rva = functions[ordinals[i]];
                    if (inside(rva, object_size)) result = rva;
                }
            }
        }
    }
    UnmapViewOfFile(base);
    return result;
}
static void ui_report(FILE* log,const ImprovedStatus& value) {
    std::printf("%s: %s (frames %lu, tabs %lu)\n",value.build,value.message,value.frames,value.tabs);
    if(log) {
        std::fprintf(log,"%s\nstage=%ld frames=%lu menu=0x%08lX chain_head=0x%08lX tabs=%lu custom_index=%lu\n%s\n",
            value.build,value.stage,value.frames,value.menu,value.chain_head,value.tabs,value.custom_index,value.message);
        std::fflush(log);
    }
}
static int watch_improved(HANDLE process,DWORD module,DWORD rva,const wchar_t* dll_path) {
    wchar_t log_path[32768]{};std::wcscpy(log_path,dll_path);
    auto* slash=std::wcsrchr(log_path,L'\\');if(slash)std::wcscpy(slash+1,L"improved-status.txt");
    FILE* log=slash?_wfopen(log_path,L"w"):nullptr;
    if(log)std::fprintf(log,"%s\nDLL: %ls\n",kImprovedBuild,dll_path);
    std::puts("Open the menu with Insert now. Checking Improved for up to 30 seconds...");
    LONG previous=-1;const auto start=GetTickCount64();ImprovedStatus value{};
    while(GetTickCount64()-start<30000) {
        SIZE_T got=0;
        if(!ReadProcessMemory(process,reinterpret_cast<void*>(module+rva),&value,sizeof(value),&got)||got!=sizeof(value)||value.version!=1)break;
        value.build[63]=0;value.message[163]=0;
        if(value.stage!=previous){ui_report(log,value);previous=value.stage;}
        if(value.stage==ImprovedActive||value.stage==ImprovedFailed) {
            if(log)std::fclose(log);
            return value.stage==ImprovedActive?0:1;
        }
        if(WaitForSingleObject(process,0)==WAIT_OBJECT_0)break;
        Sleep(100);
    }
    ui_report(log,value);
    std::puts("Improved was not confirmed. The diagnostic file is improved-status.txt beside the DLL.");
    if(log)std::fclose(log);
    return 2;
}
int wmain() {
    SetConsoleTitleW(L"Improved Records 1 + NL Movement");
    std::puts(kImprovedBuild);
    wchar_t path[32768]{};
    const DWORD length = GetModuleFileNameW(nullptr, path, 32768);
    if (!length || length >= 32768) return error("Cannot determine injector location");
    wchar_t* last = std::wcsrchr(path, L'\\');
    if (!last || last - path + 11 >= 32768) return 1;
    std::wcscpy(last + 1, L"skeet.dll");
    constexpr char loader_symbol[]="skeet_loader_status",ui_symbol[]="skeet_improved_status";
    const DWORD export_rva=status_rva(path,loader_symbol,sizeof(loader_symbol),sizeof(LoaderStatus));
    const DWORD ui_rva=status_rva(path,ui_symbol,sizeof(ui_symbol),sizeof(ImprovedStatus));
    constexpr char movement_symbol[]="nl_movement_v2_calculate";
    const DWORD movement_rva=status_rva(path,movement_symbol,sizeof(movement_symbol),1);
    if (!export_rva||!ui_rva||!movement_rva) {
        std::fprintf(stderr, "Place the matching combined skeet.dll beside injector.exe (status and movement v2 exports required).\n");
        return 1;
    }
    std::puts("Waiting up to 60 seconds for legacy csgo.exe (x86). CS2 is not supported.");
    std::puts("Use a local -insecure session. This build has not been tested inside the game.");
    DWORD pid = 0;
    const auto start = GetTickCount64();
    while (!(pid = game_pid()) && GetTickCount64() - start < 60000) Sleep(100);
    if (!pid) { std::fprintf(stderr, "csgo.exe was not found.\n"); return 1; }
    Handle process(OpenProcess(SYNCHRONIZE | PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
        PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, pid));
    if (!process.value) return error("Cannot open csgo.exe");
    BOOL self_wow = FALSE, target_wow = FALSE;
    if (!IsWow64Process(GetCurrentProcess(), &self_wow) ||
        !IsWow64Process(process.value, &target_wow)) return error("Cannot check process architecture");
    if (self_wow != target_wow) { std::fprintf(stderr, "The target must be a 32-bit legacy CS:GO process.\n"); return 1; }
    const auto remote_fn = remote_load_library(process.value, pid);
    if (!remote_fn) { SetLastError(ERROR_REVISION_MISMATCH); return error("Cannot resolve target LoadLibraryW owner/RVA"); }
    void* image = VirtualAllocEx(process.value, reinterpret_cast<void*>(kImageBase), kImageSize,
        MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if (image != reinterpret_cast<void*>(kImageBase)) {
        if (image) VirtualFreeEx(process.value, image, 0, MEM_RELEASE);
        SetLastError(ERROR_INVALID_ADDRESS);
        return error("Original fixed image address is occupied; restart the game before retrying");
    }
    auto release_image = [&]() { VirtualFreeEx(process.value, image, 0, MEM_RELEASE); };
    ImageReservation marker{kReservationMagic, 1, pid, kImageSize};
    SIZE_T written = 0;
    if (!WriteProcessMemory(process.value, image, &marker, sizeof(marker), &written) || written != sizeof(marker)) {
        DWORD code = GetLastError(); release_image(); SetLastError(code); return error("Cannot mark image reservation");
    }
    const SIZE_T path_bytes = (std::wcslen(path) + 1) * sizeof(wchar_t);
    void* argument = VirtualAllocEx(process.value, nullptr, path_bytes, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!argument || !WriteProcessMemory(process.value, argument, path, path_bytes, &written) || written != path_bytes) {
        DWORD code = GetLastError();
        if (argument) VirtualFreeEx(process.value, argument, 0, MEM_RELEASE);
        release_image(); SetLastError(code); return error("Cannot copy DLL path");
    }
    Handle thread(CreateRemoteThread(process.value, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(remote_fn), argument, 0, nullptr));
    if (!thread.value) {
        DWORD code = GetLastError();
        VirtualFreeEx(process.value, argument, 0, MEM_RELEASE);
        release_image(); SetLastError(code); return error("Cannot start DLL load");
    }
    if (WaitForSingleObject(thread.value, 30000) != WAIT_OBJECT_0) {
        std::fprintf(stderr, "DLL load did not finish. Remote allocations retained because the thread may still use them. Restart the game before retrying.\n");
        return 1;
    }
    DWORD module = 0;
    const BOOL got_exit = GetExitCodeThread(thread.value, &module);
    VirtualFreeEx(process.value, argument, 0, MEM_RELEASE);
    if (!got_exit) return error("Cannot read DLL load result");
    if (!module) {
        release_image(); SetLastError(ERROR_DLL_INIT_FAILED); return error("Target LoadLibraryW returned NULL");
    }
    std::puts("DLL mapped. Waiting for its initialization status...");
    const auto initialize_start = GetTickCount64();
    while (GetTickCount64() - initialize_start < 125000) {
        LoaderStatus status{};
        SIZE_T got = 0;
        if (!ReadProcessMemory(process.value, reinterpret_cast<void*>(module + export_rva), &status, sizeof(status), &got) ||
            got != sizeof(status) || status.version != 1) return error("Cannot read DLL initialization status");
        status.message[sizeof(status.message) - 1] = 0;
        if (status.state == LoaderFailed || status.state == LoaderEntryStarted) {
            std::printf("%s (code %lu)\n", status.message, status.error);
            if (status.state == LoaderFailed) std::puts("Restart the game before retrying.");
            return status.state == LoaderEntryStarted ? watch_improved(process.value,module,ui_rva,path) : 1;
        }
        if (WaitForSingleObject(process.value, 0) == WAIT_OBJECT_0) {
            std::fprintf(stderr, "The game exited during initialization.\n"); return 1;
        }
        Sleep(100);
    }
    std::fprintf(stderr, "Initialization status timed out; in-game functionality is not confirmed. Restart before retrying.\n");
    return 1;
}

#pragma once
#include "record_options.h"
#include "record_world.h"
namespace record_controls {
using namespace SkeetSDK;
struct Widgets {
    PElement backtrack=nullptr,consistent=nullptr,limited=nullptr;
    PElement age=nullptr,gap=nullptr,count=nullptr,horizon=nullptr,extrapolate=nullptr,hint=nullptr;
    PElement hull_hint=nullptr;
    PElement status[6]{};
};
inline PElement checkbox(const native_ui_proxy::Api& api,Child* child,const wchar_t* name,int* value) {
    auto* p=api.allocate(sizeof(Checkbox));if(!p)return nullptr;
    std::memset(p,0,sizeof(Checkbox));const int saved=*value;api.check(p,child,name,value);*value=saved;
    api.insert(child,false,p);return static_cast<PElement>(p);
}
inline PElement slider(const native_ui_proxy::Api& api,Child* child,const wchar_t* name,int lo,int hi,int* value,unsigned unit) {
    auto* p=api.allocate(sizeof(Slider));if(!p)return nullptr;
    std::memset(p,0,sizeof(Slider));const int saved=*value;api.slider(p,child,name,lo,hi,value,true,unit,1.f);*value=saved;
    api.insert(child,false,p);return static_cast<PElement>(p);
}
inline PElement label(const native_ui_proxy::Api& api,Child* child,const wchar_t* name) {
    auto* p=api.allocate(sizeof(Label));if(!p)return nullptr;
    std::memset(p,0,sizeof(Label));api.label(p,child,name);api.insert(child,false,p);return static_cast<PElement>(p);
}
inline bool create(const native_ui_proxy::Api& api,Child** child,Widgets& w) {
    using namespace record_options;
    if(!api.check||!api.slider||!api.label||!api.insert)return false;
    w.backtrack=checkbox(api,child[0],L"Backtrack",&backtrack);if(!w.backtrack)return false;
    w.age=slider(api,child[0],L"Max age",16,200,&max_age_ms,unsigned(L'm')|(unsigned(L's')<<16));
    w.consistent=checkbox(api,child[1],L"Consistent pose",&consistent);if(!w.consistent)return false;
    w.gap=slider(api,child[1],L"Max gap",1,16,&gap,L't');
    w.limited=checkbox(api,child[1],L"Limit records",&limit_records);if(!w.limited)return false;
    w.count=slider(api,child[1],L"Record limit",1,32,&record_limit,0);
    w.extrapolate=checkbox(api,child[2],L"Extrapolation",&extrapolate);
    w.horizon=slider(api,child[2],L"Max ticks",1,2,&horizon,L't');
    w.hint=label(api,child[2],L"Consistent pose required");
    w.hull_hint=label(api,child[2],L"Collision data unavailable");
    const wchar_t* text[]={L"Last: native",L"Last: exact record",L"Last: interpolated",L"Last: extrapolated",L"Last: rejected pose",L"Module unavailable"};
    for(unsigned i=0;i<6;i++){w.status[i]=label(api,child[2],text[i]);if(!w.status[i])return false;}
    return w.age&&w.gap&&w.count&&w.extrapolate&&w.horizon&&w.hint&&w.hull_hint;
}
inline void frame(Widgets& w,Child** children) {
    using namespace record_options;
    if(installed)record_world::initialize();publish();
    bool dirty[3]{};
    const auto visible=[&](PElement p,bool value,unsigned group){
        if(p&&p->GetAs<Checkbox>()->Header.Flags.Visible!=value){p->GetAs<Checkbox>()->Header.Flags.Visible=value;dirty[group]=true;}
    };
    visible(w.age,installed&&backtrack,0);visible(w.gap,installed&&consistent,1);
    visible(w.count,installed&&limit_records,1);visible(w.horizon,installed&&consistent&&extrapolate,2);
    visible(w.hint,installed&&!consistent,2);
    const bool hull=record_world::ready.load(std::memory_order_acquire);
    visible(w.hull_hint,installed&&consistent&&!hull,2);
    for(auto* p:{w.backtrack,w.consistent,w.limited})if(p)p->GetAs<Checkbox>()->Header.Flags.Editable=installed;
    if(w.extrapolate)w.extrapolate->GetAs<Checkbox>()->Header.Flags.Editable=installed&&consistent&&hull;
    const unsigned flags=policy.load(std::memory_order_acquire)&15;
    const unsigned status=!installed?5:(!flags?0:std::min(4u,last_status.load(std::memory_order_relaxed)));
    for(unsigned i=0;i<6;i++)visible(w.status[i],i==status,2);
    for(unsigned i=0;i<3;i++)if(dirty[i])children[i]->CalculateLayout();
}
}

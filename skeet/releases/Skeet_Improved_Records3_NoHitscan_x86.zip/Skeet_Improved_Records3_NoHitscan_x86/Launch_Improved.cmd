@echo off
cd /d "%~dp0"
injector.exe
echo.
echo UI diagnostic: improved-status.txt
pause

#pragma once
#include "nl_trace_host.h"
#include "record_session.h"
#include <atomic>
namespace record_world {
inline bool readable(const void* p,std::size_t bytes) {
    if(!p||!bytes)return false;
    auto at=reinterpret_cast<std::uintptr_t>(p);const auto end=at+bytes;
    if(end<at)return false;
    while(at<end) {
        MEMORY_BASIC_INFORMATION m{};
        if(!VirtualQuery(reinterpret_cast<void*>(at),&m,sizeof(m))||m.State!=MEM_COMMIT||
           (m.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
        const auto next=reinterpret_cast<std::uintptr_t>(m.BaseAddress)+m.RegionSize;
        if(next<=at)return false;at=next;
    }
    return true;
}
struct RecvTable;
struct RecvProp {
    const char* name;int type,flags,string_size;bool inside_array;unsigned char padding[3];
    void* extra;RecvProp* array;void* length_proxy;void* proxy;void* table_proxy;
    RecvTable* table;int offset,stride,elements;const char* parent;
};
struct RecvTable {RecvProp* props;int count;void* decoder;const char* name;bool initialized,in_main;};
struct ClientClass {void* create;void* event;const char* name;RecvTable* table;ClientClass* next;int id;};
static_assert(sizeof(RecvProp)==60&&offsetof(RecvProp,offset)==44&&offsetof(RecvProp,table)==40);
inline bool named(const char* a,const char* b) {
    for(unsigned i=0;i<64;i++) {
        if(!readable(a+i,1)||a[i]!=b[i])return false;
        if(!b[i])return true;
    }
    return false;
}
inline int find(RecvTable* table,const char* name,int type,int depth,unsigned& budget) {
    if(depth>10||!readable(table,sizeof(*table))||table->count<0||table->count>2048||
       !readable(table->props,std::size_t(table->count)*sizeof(RecvProp)))return -1;
    for(int i=0;i<table->count;i++) {
        if(!budget)return -1;--budget;const auto& p=table->props[i];
        if(p.offset<0||p.offset>65536)continue;
        if(p.type==type&&named(p.name,name))return p.offset;
        if(p.type==6&&p.table) {
            const int child=find(p.table,name,type,depth+1,budget);
            if(child>=0&&p.offset+child<=65536)return p.offset+child;
        }
    }
    return -1;
}
inline std::atomic<bool> ready{false};
inline int mins_offset=-1,maxs_offset=-1,simulation_offset=-1;
inline void* engine=nullptr;
inline void initialize() {
    if(ready.load(std::memory_order_acquire))return;
    static ULONGLONG last_attempt=0;const auto now=GetTickCount64();
    if(last_attempt&&now-last_attempt<1000)return;last_attempt=now;
    using Factory=void*(__cdecl*)(const char*,int*);
    auto* client=GetModuleHandleW(L"client.dll");auto* module=GetModuleHandleW(L"engine.dll");
    if(!client||!module)return;
    auto cf=reinterpret_cast<Factory>(GetProcAddress(client,"CreateInterface"));
    auto ef=reinterpret_cast<Factory>(GetProcAddress(module,"CreateInterface"));if(!cf||!ef)return;
    auto* base=cf("VClient018",nullptr);auto* trace=ef("EngineTraceClient004",nullptr);
    if(!readable(base,4)||!trace)return;
    auto** vt=*reinterpret_cast<void***>(base);if(!readable(vt,9*4)||!vt[8])return;
    using Classes=ClientClass*(__thiscall*)(void*);
    auto* cls=reinterpret_cast<Classes>(vt[8])(base);
    for(unsigned n=0;cls&&n<512;n++) {
        if(!readable(cls,sizeof(*cls)))return;
        auto* table=cls->table;
        if(readable(table,sizeof(*table))&&named(table->name,"DT_CSPlayer")) {
            unsigned a=8192,b=8192,c=8192;
            const int mn=find(table,"m_vecMins",2,0,a),mx=find(table,"m_vecMaxs",2,0,b);
            // Source receives simulation time as an integer delta, then its
            // RecvProxy writes float seconds. Searching only DPT_Float made
            // collision initialization fail on the actual integer RecvProp.
            int sim=find(table,"m_flSimulationTime",0,0,c);
            if(sim<0){c=8192;sim=find(table,"m_flSimulationTime",1,0,c);}
            if(mn<0||mx<0||sim<0||mn==mx)return;
            mins_offset=mn;maxs_offset=mx;simulation_offset=sim;engine=trace;
            ready.store(true,std::memory_order_release);return;
        }
        cls=cls->next;
    }
}
inline bool sweep(void* actor,record_session::Vec a,record_session::Vec b,int tick,float interval) {
    if(!ready.load(std::memory_order_acquire)||!actor||!record_session::finite(a)||!record_session::finite(b))return false;
    const auto* bytes=static_cast<const unsigned char*>(actor);
    if(!readable(bytes+mins_offset,12)||!readable(bytes+maxs_offset,12)||!readable(bytes+simulation_offset,4))return false;
    nl_prediction::Vec mins,maxs;float simulation;
    std::memcpy(&mins,bytes+mins_offset,12);std::memcpy(&maxs,bytes+maxs_offset,12);std::memcpy(&simulation,bytes+simulation_offset,4);
    if(!nl_prediction::finite(mins)||!nl_prediction::finite(maxs)||!std::isfinite(simulation)||
       !std::isfinite(interval)||interval<=0||std::fabs(simulation/interval-float(tick))>1.5f)return false;
    const auto size=maxs-mins;
    if(size.x<=0||size.x>128||size.y<=0||size.y>128||size.z<16||size.z>128)return false;
    nl_trace_host::Host host;host.bind_actor(engine,actor);nl_prediction::Trace result{};
    if(!host({a.x,a.y,a.z},{b.x,b.y,b.z},mins,maxs,result))return false;
    return !result.allsolid&&!result.startsolid&&std::isfinite(result.fraction)&&result.fraction==1.f;
}
}

#pragma once
#include <algorithm>
#include <cmath>

namespace improved_layout {
struct Rect {int x=0,y=0,w=0,h=0;};
struct Plan {
    bool valid=false;int minimum_height=0,count=0,custom=-1;
    Rect slots[32]{};Rect panels[3]{};
};
// All callers supply nonnegative dimensions; avoid a platform libm dependency.
inline int px(float x){return static_cast<int>(x+.5f);}
inline int display_slot(int logical,int custom) {
    if(logical==0)return 0;
    if(logical==custom)return 1;
    return logical<custom?logical+1:logical;
}
inline Plan calculate(int width,int height,float dpi,int count,int custom,
                      int left,int top,int sidebar_width,int tallest_icon,const int* visual_rows=nullptr) {
    Plan p{};
    if(!std::isfinite(dpi)||dpi<.5f||dpi>3.f||width<300||height<200||
       count<10||count>32||custom<9||custom>=count||left<0||top<0||sidebar_width<10)return p;
    const int bottom=std::max(2,px(8*dpi));
    const int minimum_row=std::max(px(48*dpi),tallest_icon+std::max(2,px(4*dpi)));
    p.minimum_height=top+bottom+count*minimum_row;
    p.count=count;p.custom=custom;
    if(height<p.minimum_height||left+sidebar_width>=width)return p;
    const int stride=std::min(px(64*dpi),(height-top-bottom)/count);
    const int gap=std::max(1,px(dpi));
    bool seen[32]{};
    for(int i=0;i<count;i++) {
        const int row=visual_rows?visual_rows[i]:display_slot(i,custom);
        if(row<0||row>=count||seen[row])return {};
        seen[row]=true;p.slots[i]={left,top+row*stride,sidebar_width,stride-gap};
    }
    const int padding=std::max(5,px(18*dpi));
    const int x=left+sidebar_width+padding,y=std::max(top,px(20*dpi));
    const int content_w=width-x-padding,content_h=height-y-padding;
    if(content_w<100||content_h<100)return p;
    const int section_gap=std::max(4,px(12*dpi));
    const int half=(content_w-section_gap)/2;
    const int half_h=(content_h-section_gap)/2;
    p.panels[0]={x,y,half,half_h};
    p.panels[1]={x,y+half_h+section_gap,half,content_h-half_h-section_gap};
    p.panels[2]={x+half+section_gap,y,content_w-half-section_gap,content_h};
    p.valid=true;return p;
}
inline bool hit(Rect r,int x,int y){return x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;}
}

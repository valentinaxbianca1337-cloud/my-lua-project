#include "../source/skeet/improved_tab_layout.h"
#include <cassert>
#include <iostream>
#include <set>
using namespace improved_layout;
int main() {
    unsigned cases=0;
    for(float dpi:{.5f,.75f,1.f,1.25f,1.5f,2.f,3.f})
      for(int count:{10,11,16,32})for(int custom:{9,count-1})
       for(int width:{500,800,1200})for(int height:{300,500,700,1000,1600}) {
        const int w=px(width*dpi),h=px(height*dpi),icon=px(44*dpi);
        auto p=calculate(w,h,dpi,count,custom,0,px(5*dpi),px(75*dpi),icon);
        if(w<300||h<200)continue;
        const int fitted=std::max(h,p.minimum_height);
        p=calculate(w,fitted,dpi,count,custom,0,px(5*dpi),px(75*dpi),icon);
        assert(p.valid&&p.slots[custom].y>p.slots[0].y&&p.slots[custom].y<p.slots[1].y);
        std::set<int> rows;
        for(int i=0;i<count;i++) {
            auto r=p.slots[i];assert(rows.insert(r.y).second);
            assert(r.x>=0&&r.y>=0&&r.x+r.w<w&&r.y+r.h<fitted);
            assert(r.h>=icon&&r.w>=icon);
            const int cx=r.x+r.w/2,cy=r.y+r.h/2;
            unsigned hits=0;for(int j=0;j<count;j++)hits+=hit(p.slots[j],cx,cy);
            assert(hits==1);
            for(int j=i+1;j<count;j++) {
                const auto s=p.slots[j];
                assert(r.y+r.h<s.y||s.y+s.h<r.y);
            }
        }
        for(const auto r:p.panels)assert(r.x>=p.slots[0].x+p.slots[0].w&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=w&&r.y+r.h<=fitted);
        const auto restored=calculate(w,fitted,dpi,count,custom,0,px(5*dpi),px(75*dpi),icon);
        for(int i=0;i<count;i++)assert(restored.slots[i].y==p.slots[i].y&&restored.slots[i].h==p.slots[i].h);
        ++cases;
       }
    assert(!calculate(800,700,0,10,9,0,0,75,44).valid);
    assert(!calculate(800,700,1,9,9,0,0,75,44).valid);
    std::cout<<cases<<" sidebar resize/DPI geometry cases passed\n";
}

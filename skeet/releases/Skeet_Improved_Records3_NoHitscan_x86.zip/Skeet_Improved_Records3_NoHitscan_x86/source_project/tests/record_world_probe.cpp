#include <windows.h>
#include "../source/skeet/record_world.h"
extern "C" {
__declspec(dllexport) void world_reset_probe(){record_world::ready.store(false);record_world::mins_offset=record_world::maxs_offset=record_world::simulation_offset=-1;record_world::engine=nullptr;}
__declspec(dllexport) void world_initialize_probe(){record_world::initialize();}
__declspec(dllexport) unsigned world_ready_probe(){return record_world::ready.load();}
__declspec(dllexport) int world_offset_probe(unsigned i){return i==0?record_world::mins_offset:(i==1?record_world::maxs_offset:record_world::simulation_offset);}
__declspec(dllexport) int world_find_probe(record_world::RecvTable* table,const char* name,int type,unsigned* budget){return record_world::find(table,name,type,0,*budget);}
__declspec(dllexport) int world_sweep_probe(void* actor,const record_session::Vec* a,const record_session::Vec* b,int tick,float dt){return record_world::sweep(actor,*a,*b,tick,dt);}
}

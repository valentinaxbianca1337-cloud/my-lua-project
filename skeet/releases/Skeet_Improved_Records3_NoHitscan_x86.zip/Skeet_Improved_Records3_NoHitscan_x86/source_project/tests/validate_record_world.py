"""Native x86 receive-table discovery and swept standing/crouching player hulls.
Windows and engine interfaces are controlled; no live process is loaded.
"""
from pathlib import Path
import struct,json,math,os,sys
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(os.environ.get("RECORD_PROJECT",str(Path(__file__).resolve().parents[1])));pe=pefile.PE(str(r/'build/record_world_probe.dll'));base=pe.OPTIONAL_HEADER.ImageBase
u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(base,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(base,pe.get_memory_mapped_image())
mem=0x70000000;api=0x70100000;stop=api+0xfff0;sp=mem+0xf000
u.mem_map(mem,0x100000);u.mem_map(api,0x10000)
put=lambda a,v:u.mem_write(a,struct.pack('<I',v&0xffffffff))
word=lambda a:struct.unpack('<I',u.mem_read(a,4))[0]
vec=lambda a:struct.unpack('<3f',u.mem_read(a,12))
floats=lambda a,*v:u.mem_write(a,struct.pack('<'+'f'*len(v),*v))
symbols={s.name.decode().lstrip('_@').split('@')[0]:base+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def text(a):return bytes(u.mem_read(a,128)).split(b'\0')[0].decode()
def wide(a):return bytes(u.mem_read(a,128)).decode('utf-16-le').split('\0')[0]
def ret(stack,result=0,cleanup=0):
 target=word(stack);u.reg_write(UC_X86_REG_EAX,result&0xffffffff);u.reg_write(UC_X86_REG_ESP,stack+4+cleanup);u.reg_write(UC_X86_REG_EIP,target)
imports={}
for lib in pe.DIRECTORY_ENTRY_IMPORT:
 for item in lib.imports:
  a=api+0x1000+len(imports)*16;put(item.address,a);imports[a]=item.name.decode()if item.name else '#'+str(item.ordinal)
client,engine,actor,root,props,nested,childprops,cls=[mem+i*0x1000 for i in range(1,9)]
cf,ef,classes,trace=[api+0x100+i*0x20 for i in range(4)]
put(client,client+0x100);put(client+0x120,classes);put(engine,engine+0x100);put(engine+0x114,trace)
strings=mem+0x12000;cursor=strings
def string(s):
 global cursor
 a=cursor;data=s.encode()+b'\0';cursor+=len(data);u.mem_write(a,data);return a
def table(at,ps,count,name):put(at,ps);put(at+4,count);put(at+12,string(name))
def prop(at,name,type,off,child=0):put(at,string(name));put(at+4,type);put(at+40,child);put(at+44,off)
table(root,props,2,'DT_CSPlayer');table(nested,childprops,2,'DT_CollisionProperty')
prop(props,'m_Collision',6,128,nested);prop(props+60,'m_flSimulationTime',int(os.environ.get('SIM_RECV_TYPE','0')),32)
prop(childprops,'m_vecMins',2,16);prop(childprops+60,'m_vecMaxs',2,28)
put(cls+12,root);put(cls+16,0)
observed=[];fraction=1.;allsolid=False;startsolid=False;clock=0

def hook(machine,a,size,user):
 global clock
 if a==stop:u.emu_stop();return
 if a not in imports and a not in [cf,ef,classes,trace]:return
 stack=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
 if a in imports:
  name=imports[a]
  if name=='GetTickCount64':
   clock+=2000;u.reg_write(UC_X86_REG_EDX,0);ret(stack,clock);return
  if name=='GetModuleHandleW':assert wide(word(stack+4))in ['client.dll','engine.dll'];ret(stack,0xc001 if wide(word(stack+4))=='client.dll'else 0xe001,4);return
  if name=='GetProcAddress':assert text(word(stack+8))=='CreateInterface';ret(stack,cf if word(stack+4)==0xc001 else ef,8);return
  if name=='VirtualQuery':
   pointer,info,n=[word(stack+i)for i in [4,8,12]];assert n==28
   for lo,hi,permissions in u.mem_regions():
    if lo<=pointer<=hi:
     for off,value in [(0,lo),(4,lo),(8,4),(12,hi-lo+1),(16,0x1000),(20,4),(24,0x20000)]:put(info+off,value)
     ret(stack,28,12);return
   ret(stack,0,12);return
  if name in ['memset','memcpy','memmove']:
   dst,src,n=[word(stack+i)for i in [4,8,12]];u.mem_write(dst,bytes([src&255])*n if name=='memset'else bytes(u.mem_read(src,n)));ret(stack,dst);return
  raise AssertionError(name)
 if a==cf:assert text(word(stack+4))=='VClient018';ret(stack,client);return
 if a==ef:assert text(word(stack+4))=='EngineTraceClient004';ret(stack,engine);return
 if a==classes:assert this==client;ret(stack,cls);return
 assert a==trace and this==engine
 ray,mask,filter_,output=[word(stack+i)for i in [4,8,12,16]]
 assert ray%16==0 and mask==0x201400b and word(filter_+4)==actor
 observed.append({'start':vec(ray),'delta':vec(ray+16),'offset':vec(ray+32),'extents':vec(ray+48)})
 floats(output+44,fraction);u.mem_write(output+54,bytes([allsolid,startsolid]));ret(stack,0,16)
u.hook_add(UC_HOOK_CODE,hook)
def call(name,args=()):
 for i,v in enumerate([stop,*args]):put(sp+4*i,v)
 u.reg_write(UC_X86_REG_ESP,sp);u.emu_start(symbols[name],stop,count=2000000)
 assert u.reg_read(UC_X86_REG_EIP)==stop and u.reg_read(UC_X86_REG_ESP)==sp+4
 return u.reg_read(UC_X86_REG_EAX)
a,b=mem+0x20000,mem+0x20010;floats(a,0,0,0);floats(b,1,0,0);dt=struct.unpack('<I',struct.pack('<f',1/64))[0]
args=[actor,a,b,100,dt]
assert call('world_sweep_probe',args)==0
call('world_initialize_probe')
if '--expect-unavailable' in sys.argv:
 assert call('world_ready_probe')==0
 print(json.dumps({'baseline_integer_recvprop_rejected':True,'game_tested':False}));raise SystemExit(0)
assert call('world_ready_probe')==1
assert [call('world_offset_probe',[i])for i in range(3)]==[144,156,32]
for height in [54,72]:
 floats(actor+144,-16,-16,0);floats(actor+156,16,16,height);floats(actor+32,100/64)
 assert call('world_sweep_probe',args)==1
 assert observed[-1]['extents']==(16,16,height/2)and observed[-1]['start']==(0,0,height/2)
 assert observed[-1]['offset']==(0,0,-height/2)and observed[-1]['delta']==(1,0,0)
rejections=0
for bad in ['wall','allsolid','startsolid','nan_trace','old_sim','nan_sim','bad_bounds','bad_interval','unmapped_actor']:
 fraction=.5 if bad=='wall'else(float('nan')if bad=='nan_trace'else 1.)
 allsolid=bad=='allsolid';startsolid=bad=='startsolid'
 floats(actor+32,float('nan')if bad=='nan_sim'else(97/64 if bad=='old_sim'else 100/64))
 floats(actor+156,16,16,4 if bad=='bad_bounds'else 72)
 altered=list(args)
 if bad=='bad_interval':altered[-1]=0
 if bad=='unmapped_actor':altered[0]=0x12300000
 assert call('world_sweep_probe',altered)==0,bad
 rejections+=1
budget=mem+0x21000;name=string('m_vecMins')
put(budget,100);assert call('world_find_probe',[root,name,2,budget])==144
put(budget,0);assert call('world_find_probe',[root,name,2,budget])==0xffffffff and word(budget)==0
put(nested+4,2049);put(budget,100);assert call('world_find_probe',[root,name,2,budget])==0xffffffff
put(nested+4,2);prop(childprops,'recursive',6,0,root);put(budget,8)
assert call('world_find_probe',[root,name,2,budget])==0xffffffff and word(budget)==0
# Both supported network types must bind the same float storage offset.
prop(childprops,'m_vecMins',2,16)
recv_types=[]
for kind in [0,1,2,4]:
 prop(props+60,'m_flSimulationTime',kind,32);call('world_reset_probe');call('world_initialize_probe')
 assert call('world_ready_probe')==int(kind in [0,1]),kind
 if kind in [0,1]:assert call('world_offset_probe',[2])==32
 recv_types.append(kind)
report={'simulation_receive_types_checked':recv_types,'integer_and_float_bind':True,'other_types_rejected':True,'passed':True,'native_receive_table_offsets':True,'nested_offsets':[144,156,32],'standing_and_crouch_hull':True,'sweep_rejections':rejections,'recursive_search_budget_and_invalid_count_rejected':True,'live_engine_executed':False}
(r/'reports/record_world.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

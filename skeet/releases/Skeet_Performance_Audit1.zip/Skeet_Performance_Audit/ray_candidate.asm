43329d2b: 55                         push       ebp
43329d2c: 8bec                       mov        ebp, esp
43329d2e: 83e4f0                     and        esp, 0xfffffff0
43329d31: 81ece8000000               sub        esp, 0xe8
43329d37: 56                         push       esi
43329d38: 8b7510                     mov        esi, dword ptr [ebp + 0x10]
43329d3b: 894c2430                   mov        dword ptr [esp + 0x30], ecx
43329d3f: 8bce                       mov        ecx, esi
43329d41: 57                         push       edi
43329d42: 89542444                   mov        dword ptr [esp + 0x44], edx
43329d46: e889320d00                 call       0x433fcfd4
43329d4b: 8b7d0c                     mov        edi, dword ptr [ebp + 0xc]
43329d4e: 8bcf                       mov        ecx, edi
43329d50: ff742434                   push       dword ptr [esp + 0x34]
43329d54: 8b07                       mov        eax, dword ptr [edi]
43329d56: ff5008                     call       dword ptr [eax + 8]
43329d59: 8b07                       mov        eax, dword ptr [edi]
43329d5b: 8bcf                       mov        ecx, edi
43329d5d: 6a00                       push       0
43329d5f: ff5010                     call       dword ptr [eax + 0x10]
43329d62: 8b442444                   mov        eax, dword ptr [esp + 0x44]
43329d66: f30f107008                 movss      xmm6, dword ptr [eax + 8]
43329d6b: f30f7e00                   movq       xmm0, qword ptr [eax]
43329d6f: 8b4508                     mov        eax, dword ptr [ebp + 8]
43329d72: 660fd6442424               movq       qword ptr [esp + 0x24], xmm0
43329d78: f30f106c2424               movss      xmm5, dword ptr [esp + 0x24]
43329d7e: f30f107c2428               movss      xmm7, dword ptr [esp + 0x28]
43329d84: f30f1020                   movss      xmm4, dword ptr [eax]
43329d88: f30f105804                 movss      xmm3, dword ptr [eax + 4]
43329d8d: f30f5ce5                   subss      xmm4, xmm5
43329d91: f30f105008                 movss      xmm2, dword ptr [eax + 8]
43329d96: f30f5cdf                   subss      xmm3, xmm7
43329d9a: f30f5cd6                   subss      xmm2, xmm6
43329d9e: f30f1174242c               movss      dword ptr [esp + 0x2c], xmm6
43329da4: 0f11742460                 movups     xmmword ptr [esp + 0x60], xmm6
43329da9: 0f28cc                     movaps     xmm1, xmm4
43329dac: f30f59cc                   mulss      xmm1, xmm4
43329db0: 0f28c3                     movaps     xmm0, xmm3
43329db3: f30f59c3                   mulss      xmm0, xmm3
43329db7: f30f58c8                   addss      xmm1, xmm0
43329dbb: 0f28c2                     movaps     xmm0, xmm2
43329dbe: f30f59c2                   mulss      xmm0, xmm2
43329dc2: f30f58c8                   addss      xmm1, xmm0
43329dc6: 0f28c1                     movaps     xmm0, xmm1
43329dc9: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
43329dd1: f30f51c0                   sqrtss     xmm0, xmm0
43329dd5: 0f11842490000000           movups     xmmword ptr [esp + 0x90], xmm0
43329ddd: f30f11442478               movss      dword ptr [esp + 0x78], xmm0
43329de3: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
43329deb: f30f5ec8                   divss      xmm1, xmm0
43329def: 0f28c1                     movaps     xmm0, xmm1
43329df2: f30f59c4                   mulss      xmm0, xmm4
43329df6: f30f106620                 movss      xmm4, dword ptr [esi + 0x20]
43329dfb: f30f11642414               movss      dword ptr [esp + 0x14], xmm4
43329e01: f30f11442438               movss      dword ptr [esp + 0x38], xmm0
43329e07: 0f28c1                     movaps     xmm0, xmm1
43329e0a: f30f59ca                   mulss      xmm1, xmm2
43329e0e: f30f59c3                   mulss      xmm0, xmm3
43329e12: f30f114c2440               movss      dword ptr [esp + 0x40], xmm1
43329e18: f30f104f20                 movss      xmm1, dword ptr [edi + 0x20]
43329e1d: f30f5c0d78fd4643           subss      xmm1, dword ptr [0x4346fd78] ; [4346fd78] f32=5
43329e25: f30f1144243c               movss      dword ptr [esp + 0x3c], xmm0
43329e2b: 0f57c0                     xorps      xmm0, xmm0
43329e2e: f30f1144241c               movss      dword ptr [esp + 0x1c], xmm0
43329e34: f30f100514054743           movss      xmm0, dword ptr [0x43470514] ; [43470514] f32=1
43329e3c: e8f45d0000                 call       0x4332fc35
43329e41: f30f104e14                 movss      xmm1, dword ptr [esi + 0x14]
43329e46: 0f28d0                     movaps     xmm2, xmm0
43329e49: f30f580df0f14643           addss      xmm1, dword ptr [0x4346f1f0] ; [4346f1f0] f32=16
43329e51: 0f10842490000000           movups     xmm0, xmmword ptr [esp + 0x90]
43329e59: f30f11542448               movss      dword ptr [esp + 0x48], xmm2
43329e5f: 0f2fc1                     comiss     xmm0, xmm1
43329e62: 7607                       jbe        0x43329e6b
43329e64: 33c0                       xor        eax, eax
43329e66: e9a2050000                 jmp        0x4332a40d
43329e6b: 0f2fd4                     comiss     xmm2, xmm4
43329e6e: 0f878d050000               ja         0x4332a401
43329e74: f30f5c0580294743           subss      xmm0, dword ptr [0x43472980] ; [43472980] f32=0.100000001
43329e7c: 8d562c                     lea        edx, [esi + 0x2c]
43329e7f: 8d420c                     lea        eax, [edx + 0xc]
43329e82: 89442430                   mov        dword ptr [esp + 0x30], eax
43329e86: 0f11842490000000           movups     xmmword ptr [esp + 0x90], xmm0
43329e8e: f30f104614                 movss      xmm0, dword ptr [esi + 0x14]
43329e93: f30f5c44241c               subss      xmm0, dword ptr [esp + 0x1c]
43329e99: f30f104c2438               movss      xmm1, dword ptr [esp + 0x38]
43329e9f: f30f105c243c               movss      xmm3, dword ptr [esp + 0x3c]
43329ea5: f30f10642440               movss      xmm4, dword ptr [esp + 0x40]
43329eab: 83a424e000000000           and        dword ptr [esp + 0xe0], 0
43329eb3: f30f59c8                   mulss      xmm1, xmm0
43329eb7: c68424e400000001           mov        byte ptr [esp + 0xe4], 1
43329ebf: f30f59d8                   mulss      xmm3, xmm0
43329ec3: c68424e500000001           mov        byte ptr [esp + 0xe5], 1
43329ecb: f30f58cd                   addss      xmm1, xmm5
43329ecf: f30f59e0                   mulss      xmm4, xmm0
43329ed3: f30f58df                   addss      xmm3, xmm7
43329ed7: f30f11442418               movss      dword ptr [esp + 0x18], xmm0
43329edd: f30f11ac24a0000000         movss      dword ptr [esp + 0xa0], xmm5
43329ee6: f30f58e6                   addss      xmm4, xmm6
43329eea: f30f11bc24a4000000         movss      dword ptr [esp + 0xa4], xmm7
43329ef3: 0f28d1                     movaps     xmm2, xmm1
43329ef6: f30f114c244c               movss      dword ptr [esp + 0x4c], xmm1
43329efc: f30f5cd5                   subss      xmm2, xmm5
43329f00: f30f11b424a8000000         movss      dword ptr [esp + 0xa8], xmm6
43329f09: 0f28cb                     movaps     xmm1, xmm3
43329f0c: f30f115c2450               movss      dword ptr [esp + 0x50], xmm3
43329f12: f30f5ccf                   subss      xmm1, xmm7
43329f16: 0f57db                     xorps      xmm3, xmm3
43329f19: 0f28c4                     movaps     xmm0, xmm4
43329f1c: f30f11642420               movss      dword ptr [esp + 0x20], xmm4
43329f22: f30f5cc6                   subss      xmm0, xmm6
43329f26: 0f299c24c0000000           movaps     xmmword ptr [esp + 0xc0], xmm3
43329f2e: f30f119424b0000000         movss      dword ptr [esp + 0xb0], xmm2
43329f37: f30f59d2                   mulss      xmm2, xmm2
43329f3b: f30f118c24b4000000         movss      dword ptr [esp + 0xb4], xmm1
43329f44: f30f59c9                   mulss      xmm1, xmm1
43329f48: f30f118424b8000000         movss      dword ptr [esp + 0xb8], xmm0
43329f51: f30f59c0                   mulss      xmm0, xmm0
43329f55: f30f58ca                   addss      xmm1, xmm2
43329f59: 0f299c24d0000000           movaps     xmmword ptr [esp + 0xd0], xmm3
43329f61: f30f58c8                   addss      xmm1, xmm0
43329f65: 0f2e0d6cee4643             ucomiss    xmm1, dword ptr [0x4346ee6c] ; [4346ee6c] f32=0
43329f6c: 9f                         lahf       
43329f6d: f6c444                     test       ah, 0x44
43329f70: 7a08                       jp         0x43329f7a
43329f72: c68424e500000000           mov        byte ptr [esp + 0xe5], 0
43329f7a: 8b0d04834643               mov        ecx, dword ptr [0x43468304] ; [43468304] f32=83.272728
43329f80: 52                         push       edx
43329f81: 57                         push       edi
43329f82: ff7718                     push       dword ptr [edi + 0x18]
43329f85: 8b01                       mov        eax, dword ptr [ecx]
43329f87: 8d9424ac000000             lea        edx, [esp + 0xac]
43329f8e: 52                         push       edx
43329f8f: ff5014                     call       dword ptr [eax + 0x14]
43329f92: f7471800000040             test       dword ptr [edi + 0x18], 0x40000000
43329f99: 0f84f0000000               je         0x4332a08f
43329f9f: 8b442430                   mov        eax, dword ptr [esp + 0x30]
43329fa3: 8d542454                   lea        edx, [esp + 0x54]
43329fa7: f30f100578034743           movss      xmm0, dword ptr [0x43470378] ; [43470378] f32=40
43329faf: 8d4c2424                   lea        ecx, [esp + 0x24]
43329fb3: f30f10742438               movss      xmm6, dword ptr [esp + 0x38]
43329fb9: f30f106c243c               movss      xmm5, dword ptr [esp + 0x3c]
43329fbf: f30f10642440               movss      xmm4, dword ptr [esp + 0x40]
43329fc5: f30f1010                   movss      xmm2, dword ptr [eax]
43329fc9: f30f5c542424               subss      xmm2, dword ptr [esp + 0x24]
43329fcf: f30f104808                 movss      xmm1, dword ptr [eax + 8]
43329fd4: f30f5c4c2460               subss      xmm1, dword ptr [esp + 0x60]
43329fda: f30f59f0                   mulss      xmm6, xmm0
43329fde: f30f59e8                   mulss      xmm5, xmm0
43329fe2: f30f5874244c               addss      xmm6, dword ptr [esp + 0x4c]
43329fe8: f30f59e0                   mulss      xmm4, xmm0
43329fec: f30f104004                 movss      xmm0, dword ptr [eax + 4]
43329ff1: 8d462c                     lea        eax, [esi + 0x2c]
43329ff4: f30f5c442428               subss      xmm0, dword ptr [esp + 0x28]
43329ffa: f30f586c2450               addss      xmm5, dword ptr [esp + 0x50]
4332a000: f30f58642420               addss      xmm4, dword ptr [esp + 0x20]
4332a006: f30f59d2                   mulss      xmm2, xmm2
4332a00a: 50                         push       eax
4332a00b: f30f59c0                   mulss      xmm0, xmm0
4332a00f: 57                         push       edi
4332a010: f30f59c9                   mulss      xmm1, xmm1
4332a014: f30f58d0                   addss      xmm2, xmm0
4332a018: f30f1174245c               movss      dword ptr [esp + 0x5c], xmm6
4332a01e: f30f10442430               movss      xmm0, dword ptr [esp + 0x30]
4332a024: f30f5cc5                   subss      xmm0, xmm5
4332a028: f30f116c2460               movss      dword ptr [esp + 0x60], xmm5
4332a02e: f30f11642464               movss      dword ptr [esp + 0x64], xmm4
4332a034: f30f58d1                   addss      xmm2, xmm1
4332a038: f30f104c2468               movss      xmm1, dword ptr [esp + 0x68]
4332a03e: f30f5ccc                   subss      xmm1, xmm4
4332a042: f30f59c0                   mulss      xmm0, xmm0
4332a046: 0f28da                     movaps     xmm3, xmm2
4332a049: f30f1054242c               movss      xmm2, dword ptr [esp + 0x2c]
4332a04f: f30f5cd6                   subss      xmm2, xmm6
4332a053: f30f59c9                   mulss      xmm1, xmm1
4332a057: f30f51db                   sqrtss     xmm3, xmm3
4332a05b: f30f59d2                   mulss      xmm2, xmm2
4332a05f: f30f119c2484000000         movss      dword ptr [esp + 0x84], xmm3
4332a068: f30f58d0                   addss      xmm2, xmm0
4332a06c: f30f58d1                   addss      xmm2, xmm1
4332a070: 0f28c2                     movaps     xmm0, xmm2
4332a073: f30f51c0                   sqrtss     xmm0, xmm0
4332a077: f30f5ed8                   divss      xmm3, xmm0
4332a07b: f30f11842488000000         movss      dword ptr [esp + 0x88], xmm0
4332a084: 0f57c0                     xorps      xmm0, xmm0
4332a087: 0f28cb                     movaps     xmm1, xmm3
4332a08a: e8177f0c00                 call       0x433f1fa6
4332a08f: 8b7c2430                   mov        edi, dword ptr [esp + 0x30]
4332a093: 8b442444                   mov        eax, dword ptr [esp + 0x44]
4332a097: f30f1017                   movss      xmm2, dword ptr [edi]
4332a09b: f30f5c10                   subss      xmm2, dword ptr [eax]
4332a09f: f30f104704                 movss      xmm0, dword ptr [edi + 4]
4332a0a4: f30f5c4004                 subss      xmm0, dword ptr [eax + 4]
4332a0a9: f30f104f08                 movss      xmm1, dword ptr [edi + 8]
4332a0ae: f30f5c4808                 subss      xmm1, dword ptr [eax + 8]
4332a0b3: f30f59d2                   mulss      xmm2, xmm2
4332a0b7: f30f59c0                   mulss      xmm0, xmm0
4332a0bb: f30f59c9                   mulss      xmm1, xmm1
4332a0bf: f30f58d0                   addss      xmm2, xmm0
4332a0c3: f30f58d1                   addss      xmm2, xmm1
4332a0c7: 0f28c2                     movaps     xmm0, xmm2
4332a0ca: f30f51c0                   sqrtss     xmm0, xmm0
4332a0ce: 0f2f842490000000           comiss     xmm0, dword ptr [esp + 0x90]
4332a0d6: f30f11842484000000         movss      dword ptr [esp + 0x84], xmm0
4332a0df: 0f835b020000               jae        0x4332a340
4332a0e5: f30f104658                 movss      xmm0, dword ptr [esi + 0x58]
4332a0ea: f30f59442418               mulss      xmm0, dword ptr [esp + 0x18]
4332a0f0: f30f5844241c               addss      xmm0, dword ptr [esp + 0x1c]
4332a0f6: f30f1144241c               movss      dword ptr [esp + 0x1c], xmm0
4332a0fc: f30f5905941d4743           mulss      xmm0, dword ptr [0x43471d94] ; [43471d94] f32=0.00200000009
4332a104: 0f5ac8                     cvtps2pd   xmm1, xmm0
4332a107: f30f104618                 movss      xmm0, dword ptr [esi + 0x18]
4332a10c: 0f5ac0                     cvtps2pd   xmm0, xmm0
4332a10f: e8bc121e34                 call       0x7750b3d0
4332a114: f30f104c2414               movss      xmm1, dword ptr [esp + 0x14]
4332a11a: 0f5ac9                     cvtps2pd   xmm1, xmm1
4332a11d: f20f59c1                   mulsd      xmm0, xmm1
4332a121: 0f57c9                     xorps      xmm1, xmm1
4332a124: f20f5ac8                   cvtsd2ss   xmm1, xmm0
4332a128: f30f104658                 movss      xmm0, dword ptr [esi + 0x58]
4332a12d: 0f2e0514054743             ucomiss    xmm0, dword ptr [0x43470514] ; [43470514] f32=1
4332a134: f30f114c2414               movss      dword ptr [esp + 0x14], xmm1
4332a13a: 9f                         lahf       
4332a13b: f6c444                     test       ah, 0x44
4332a13e: 0f8bb5020000               jnp        0x4332a3f9
4332a144: 8b8680000000               mov        eax, dword ptr [esi + 0x80]
4332a14a: 83c00b                     add        eax, 0xb
4332a14d: f30f10442448               movss      xmm0, dword ptr [esp + 0x48]
4332a153: 6bf80c                     imul       edi, eax, 0xc
4332a156: 03fe                       add        edi, esi
4332a158: 8b742430                   mov        esi, dword ptr [esp + 0x30]
4332a15c: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4332a15d: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4332a15e: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4332a15f: 8b7510                     mov        esi, dword ptr [ebp + 0x10]
4332a162: ff8680000000               inc        dword ptr [esi + 0x80]
4332a168: 0f2fc1                     comiss     xmm0, xmm1
4332a16b: 0f8790020000               ja         0x4332a401
4332a171: 8b0d68924643               mov        ecx, dword ptr [0x43469268] ; [43469268] f32=-7.31834806e-32
4332a177: 8b01                       mov        eax, dword ptr [ecx]
4332a179: 8b5014                     mov        edx, dword ptr [eax + 0x14]
4332a17c: 0fbf466c                   movsx      eax, word ptr [esi + 0x6c]
4332a180: 50                         push       eax
4332a181: ffd2                       call       edx
4332a183: f30f1044241c               movss      xmm0, dword ptr [esp + 0x1c]
4332a189: 0f2f05a0244743             comiss     xmm0, dword ptr [0x434724a0] ; [434724a0] f32=3000
4332a190: 89442420                   mov        dword ptr [esp + 0x20], eax
4332a194: 760e                       jbe        0x4332a1a4
4332a196: f30f104610                 movss      xmm0, dword ptr [esi + 0x10]
4332a19b: 0f2f056cee4643             comiss     xmm0, dword ptr [0x4346ee6c] ; [4346ee6c] f32=0
4332a1a2: 7716                       ja         0x4332a1ba
4332a1a4: f30f104058                 movss      xmm0, dword ptr [eax + 0x58]
4332a1a9: f20f100dd8214743           movsd      xmm1, qword ptr [0x434721d8] ; [434721d8] f32=-1.58818684e-23
4332a1b1: 0f5ac0                     cvtps2pd   xmm0, xmm0
4332a1b4: 660f2fc8                   comisd     xmm1, xmm0
4332a1b8: 7604                       jbe        0x4332a1be
4332a1ba: 83662800                   and        dword ptr [esi + 0x28], 0
4332a1be: 8b450c                     mov        eax, dword ptr [ebp + 0xc]
4332a1c1: f7401800000040             test       dword ptr [eax + 0x18], 0x40000000
4332a1c8: 7507                       jne        0x4332a1d1
4332a1ca: c7467001000000             mov        dword ptr [esi + 0x70], 1
4332a1d1: 8b7e78                     mov        edi, dword ptr [esi + 0x78]
4332a1d4: 85ff                       test       edi, edi
4332a1d6: 7427                       je         0x4332a1ff
4332a1d8: c74424189e182711           mov        dword ptr [esp + 0x18], 0x1127189e
4332a1e0: 8bd7                       mov        edx, edi
4332a1e2: 8b442418                   mov        eax, dword ptr [esp + 0x18]
4332a1e6: 8b0f                       mov        ecx, dword ptr [edi]
4332a1e8: 8b8c08dae9d8ee             mov        ecx, dword ptr [eax + ecx - 0x11271626]
4332a1ef: 898c2488000000             mov        dword ptr [esp + 0x88], ecx
4332a1f6: e844b10b00                 call       0x433e533f
4332a1fb: 84c0                       test       al, al
4332a1fd: 7502                       jne        0x4332a201
4332a1ff: 33ff                       xor        edi, edi
4332a201: 8b4d0c                     mov        ecx, dword ptr [ebp + 0xc]
4332a204: 57                         push       edi
4332a205: 8b01                       mov        eax, dword ptr [ecx]
4332a207: ff5010                     call       dword ptr [eax + 0x10]
4332a20a: 8b5678                     mov        edx, dword ptr [esi + 0x78]
4332a20d: 85d2                       test       edx, edx
4332a20f: 7442                       je         0x4332a253
4332a211: c744241880fdffff           mov        dword ptr [esp + 0x18], 0xfffffd80
4332a219: 8b442418                   mov        eax, dword ptr [esp + 0x18]
4332a21d: 8b0a                       mov        ecx, dword ptr [edx]
4332a21f: 2bc8                       sub        ecx, eax
4332a221: 8b09                       mov        ecx, dword ptr [ecx]
4332a223: 898c248c000000             mov        dword ptr [esp + 0x8c], ecx
4332a22a: e810b10b00                 call       0x433e533f
4332a22f: 84c0                       test       al, al
4332a231: 7420                       je         0x4332a253
4332a233: 85ff                       test       edi, edi
4332a235: 0f84c6010000               je         0x4332a401
4332a23b: a1dca54643                 mov        eax, dword ptr [0x4346a5dc] ; [4346a5dc] f32=1.8317819e-12
4332a240: 8b00                       mov        eax, dword ptr [eax]
4332a242: 330530844643               xor        eax, dword ptr [0x43468430] ; [43468430] f32=-475142720
4332a248: 35d290e2cd                 xor        eax, 0xcde290d2
4332a24d: 803c3800                   cmp        byte ptr [eax + edi], 0
4332a251: 746f                       je         0x4332a2c2
4332a253: 8d4628                     lea        eax, [esi + 0x28]
4332a256: 833800                     cmp        dword ptr [eax], 0
4332a259: 0f8ea2010000               jle        0x4332a401
4332a25f: 8b7d0c                     mov        edi, dword ptr [ebp + 0xc]
4332a262: 8d4c2414                   lea        ecx, [esp + 0x14]
4332a266: 51                         push       ecx
4332a267: 8b4c2438                   mov        ecx, dword ptr [esp + 0x38]
4332a26b: 8d54243c                   lea        edx, [esp + 0x3c]
4332a26f: 50                         push       eax
4332a270: ff742428                   push       dword ptr [esp + 0x28]
4332a274: 8d442430                   lea        eax, [esp + 0x30]
4332a278: 57                         push       edi
4332a279: 56                         push       esi
4332a27a: 50                         push       eax
4332a27b: e8c73d0700                 call       0x4339e047
4332a280: 84c0                       test       al, al
4332a282: 0f85ac000000               jne        0x4332a334
4332a288: f30f10642414               movss      xmm4, dword ptr [esp + 0x14]
4332a28e: f30f10442448               movss      xmm0, dword ptr [esp + 0x48]
4332a294: 0f2fc4                     comiss     xmm0, xmm4
4332a297: f30f11642414               movss      dword ptr [esp + 0x14], xmm4
4332a29d: 0f875e010000               ja         0x4332a401
4332a2a3: f30f1074242c               movss      xmm6, dword ptr [esp + 0x2c]
4332a2a9: 8d562c                     lea        edx, [esi + 0x2c]
4332a2ac: f30f107c2428               movss      xmm7, dword ptr [esp + 0x28]
4332a2b2: f30f106c2424               movss      xmm5, dword ptr [esp + 0x24]
4332a2b8: 0f11742460                 movups     xmmword ptr [esp + 0x60], xmm6
4332a2bd: e9ccfbffff                 jmp        0x43329e8e
4332a2c2: 8d4f08                     lea        ecx, [edi + 8]
4332a2c5: 8b01                       mov        eax, dword ptr [ecx]
4332a2c7: ff5028                     call       dword ptr [eax + 0x28]
4332a2ca: c1e005                     shl        eax, 5
4332a2cd: 80b808be474300             cmp        byte ptr [eax + 0x4347be08], 0
4332a2d4: 0f8527010000               jne        0x4332a401
4332a2da: 8b442434                   mov        eax, dword ptr [esp + 0x34]
4332a2de: 85c0                       test       eax, eax
4332a2e0: 7411                       je         0x4332a2f3
4332a2e2: 8bd7                       mov        edx, edi
4332a2e4: 8bc8                       mov        ecx, eax
4332a2e6: e8a14c0700                 call       0x4339ef8c
4332a2eb: 84c0                       test       al, al
4332a2ed: 0f840e010000               je         0x4332a401
4332a2f3: 8b450c                     mov        eax, dword ptr [ebp + 0xc]
4332a2f6: f7401800000040             test       dword ptr [eax + 0x18], 0x40000000
4332a2fd: 742a                       je         0x4332a329
4332a2ff: 8b5670                     mov        edx, dword ptr [esi + 0x70]
4332a302: 8d42ff                     lea        eax, [edx - 1]
4332a305: 83f807                     cmp        eax, 7
4332a308: 771f                       ja         0x4332a329
4332a30a: 0fb7460c                   movzx      eax, word ptr [esi + 0xc]
4332a30e: 8bcf                       mov        ecx, edi
4332a310: f30f10461c                 movss      xmm0, dword ptr [esi + 0x1c]
4332a315: 50                         push       eax
4332a316: e8fe010600                 call       0x4338a519
4332a31b: 0f28c8                     movaps     xmm1, xmm0
4332a31e: f30f594c2414               mulss      xmm1, dword ptr [esp + 0x14]
4332a324: e9d0000000                 jmp        0x4332a3f9
4332a329: f30f104c2414               movss      xmm1, dword ptr [esp + 0x14]
4332a32f: e9c5000000                 jmp        0x4332a3f9
4332a334: 834e0404                   or         dword ptr [esi + 4], 4
4332a338: 0f57c9                     xorps      xmm1, xmm1
4332a33b: e9b9000000                 jmp        0x4332a3f9
4332a340: 8b4508                     mov        eax, dword ptr [ebp + 8]
4332a343: f30f105c2424               movss      xmm3, dword ptr [esp + 0x24]
4332a349: f30f106c2428               movss      xmm5, dword ptr [esp + 0x28]
4332a34f: 0f28d3                     movaps     xmm2, xmm3
4332a352: f30f5c5c244c               subss      xmm3, dword ptr [esp + 0x4c]
4332a358: f30f5c10                   subss      xmm2, dword ptr [eax]
4332a35c: 0f10642460                 movups     xmm4, xmmword ptr [esp + 0x60]
4332a361: 0f28c5                     movaps     xmm0, xmm5
4332a364: f30f5c4004                 subss      xmm0, dword ptr [eax + 4]
4332a369: f30f5c6c2450               subss      xmm5, dword ptr [esp + 0x50]
4332a36f: 0f28cc                     movaps     xmm1, xmm4
4332a372: f30f59d2                   mulss      xmm2, xmm2
4332a376: f30f5c4808                 subss      xmm1, dword ptr [eax + 8]
4332a37b: f30f5c642420               subss      xmm4, dword ptr [esp + 0x20]
4332a381: f30f59c0                   mulss      xmm0, xmm0
4332a385: f30f59db                   mulss      xmm3, xmm3
4332a389: f30f59c9                   mulss      xmm1, xmm1
4332a38d: f30f58d0                   addss      xmm2, xmm0
4332a391: f30f59ed                   mulss      xmm5, xmm5
4332a395: f30f59e4                   mulss      xmm4, xmm4
4332a399: f30f58dd                   addss      xmm3, xmm5
4332a39d: f30f58d1                   addss      xmm2, xmm1
4332a3a1: f30f58dc                   addss      xmm3, xmm4
4332a3a5: 0f28ca                     movaps     xmm1, xmm2
4332a3a8: f30f51c9                   sqrtss     xmm1, xmm1
4332a3ac: 0f28c3                     movaps     xmm0, xmm3
4332a3af: f30f51c0                   sqrtss     xmm0, xmm0
4332a3b3: f30f5ec8                   divss      xmm1, xmm0
4332a3b7: f30f104618                 movss      xmm0, dword ptr [esi + 0x18]
4332a3bc: f30f594c2418               mulss      xmm1, dword ptr [esp + 0x18]
4332a3c2: 0f5ac0                     cvtps2pd   xmm0, xmm0
4332a3c5: f30f584c241c               addss      xmm1, dword ptr [esp + 0x1c]
4332a3cb: f30f590d941d4743           mulss      xmm1, dword ptr [0x43471d94] ; [43471d94] f32=0.00200000009
4332a3d3: f30f5ac9                   cvtss2sd   xmm1, xmm1
4332a3d7: e8f40f1e34                 call       0x7750b3d0
4332a3dc: 8b7508                     mov        esi, dword ptr [ebp + 8]
4332a3df: f30f104c2414               movss      xmm1, dword ptr [esp + 0x14]
4332a3e5: 0f5ac9                     cvtps2pd   xmm1, xmm1
4332a3e8: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4332a3e9: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4332a3ea: f20f59c1                   mulsd      xmm0, xmm1
4332a3ee: 0f57c9                     xorps      xmm1, xmm1
4332a3f1: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4332a3f2: 8b7510                     mov        esi, dword ptr [ebp + 0x10]
4332a3f5: f20f5ac8                   cvtsd2ss   xmm1, xmm0
4332a3f9: 0f57c0                     xorps      xmm0, xmm0
4332a3fc: 0f2fc1                     comiss     xmm0, xmm1
4332a3ff: 7603                       jbe        0x4332a404
4332a401: 0f57c9                     xorps      xmm1, xmm1
4332a404: f30f114e08                 movss      dword ptr [esi + 8], xmm1
4332a409: f30f2cc1                   cvttss2si  eax, xmm1
4332a40d: 5f                         pop        edi
4332a40e: 5e                         pop        esi
4332a40f: 8be5                       mov        esp, ebp
4332a411: 5d                         pop        ebp
4332a412: c20c00                     ret        0xc

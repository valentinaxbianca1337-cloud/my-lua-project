"""Exercise statistics and real Lua state machine against controlled GS APIs.
No game, Windows recorder or DLL entrypoint is run.
"""
from pathlib import Path
import json, math
from lupa.luajit21 import LuaRuntime

ROOT=Path(__file__).resolve().parents[1]
def convert(v):
    if not hasattr(v,'items'): return v
    d=dict(v.items())
    if d and all(isinstance(k,int) and 1<=k<=len(d) for k in d):
        return [convert(d[k])for k in range(1,len(d)+1)]
    return {str(k):convert(x)for k,x in d.items()}

def machine():
    lua=LuaRuntime(unpack_returned_tuples=True);written={};logs=[]
    lua.globals().encode_json=lambda v:json.dumps(convert(v),allow_nan=False)
    lua.globals().capture_file=lambda name,data:written.update({name:json.loads(data)})
    lua.globals().capture_log=lambda s:logs.append(s)
    lua.execute('''
    clock=0;menu=true;map="de_cbble";controls={};buttons={};events={}
    ui={};client={};globals={};entity={}
    function ui.reference(a,b,name)
      if name=="Enabled" then controls.rage=true;controls.hotkey=true;return "rage","hotkey" end
      controls[name]={"Head"};return name
    end
    function ui.new_textbox(a,b,name) controls[name]="test";return name end
    function ui.new_slider(a,b,name,lo,hi,value) controls[name]=value;return name end
    function ui.new_button(a,b,name,fn) buttons[name]=fn;return name end
    function ui.get(name) return controls[name] end
    function ui.set(...) error("recorder must not mutate any control") end
    function ui.is_menu_open() return menu end
    function client.timestamp() return clock end
    function client.log(s) capture_log(s) end
    function client.set_event_callback(name,fn) events[name]=fn end
    function client.camera_angles() return 0,90 end
    function client.screen_size() return 1920,1080 end
    function globals.mapname() return map end
    function globals.tickcount() return math.floor(clock*.064) end
    function globals.tickinterval() return 1/64 end
    function globals.absoluteframetime() return .005 end
    function entity.get_local_player() return 1 end
    function entity.is_alive(i) return true end
    function entity.is_dormant(i) return false end
    function entity.get_players(enemies) return {2} end
    function entity.get_prop(i,name) return i*100,0,0 end
    function entity.get_player_weapon(i) return 3 end
    function entity.get_classname(i) return "CWeaponSSG08" end
    cvar=setmetatable({},{__index=function() return {get_string=function() return "0" end} end})
    json={stringify=function(v) return encode_json(v) end}
    writefile=function(n,v) capture_file(n,v) end
    ''')
    module=lua.execute((ROOT/'performance_audit.lua').read_text())
    return lua,module,written,logs

def step(lua,t):
    lua.globals().clock=t;lua.globals().events['paint_ui']()
def begin(lua):
    lua.globals().controls['Performance sample length']=5
    lua.globals().buttons['Start performance sample']()
    lua.globals().menu=False;step(lua,0);step(lua,2000)

lua,m,w,logs=machine()
s=convert(m['stats'](lua.table_from([5,5,5,25,50])))
assert s['samples']==5 and s['mean_ms']==18 and s['median_ms']==5 and s['p95_ms']==50
assert math.isclose(s['fps_from_mean'],1000/18)
assert s['frames_over_16_667ms']==2 and s['frames_over_33_333ms']==1
assert convert(m['stats'](lua.table_from([])))=={'samples':0}
zero=convert(m['stats'](lua.table_from([0,0])))
assert 'fps_from_mean' not in zero and zero['mean_ms']==0
begin(lua)
for t in range(2005,7001,5):
    lua.globals().events['setup_command']();step(lua,t)
r=w['performance_audit.json']['runs'][0]
assert r['valid'] and r['frames']['samples']==1000 and r['frames']['mean_ms']==5
assert r['frames']['fps_from_mean']==200 and r['events']['setup_command']==1000
assert r['start']['settings']['rage']==[True,True] and r['sampler_callback_ms']['mean_ms']==0
assert r['engine_absolute_frames']['mean_ms']==5
assert lua.globals().controls.rage is True
checks=5
for condition in ['menu','map','rage','hotkey','cancel','shutdown','few_frames','reverse_clock','pending_cancel']:
    lua,m,w,logs=machine()
    if condition=='pending_cancel':lua.globals().buttons['Start performance sample']()
    else:begin(lua)
    if condition=='menu':lua.globals().menu=True;step(lua,2010)
    elif condition=='map':lua.globals().map='de_dust2';step(lua,2010)
    elif condition in ['rage','hotkey']:
        lua.globals().controls[condition]=False
        for t in range(2005,7001,5):step(lua,t)
    elif condition in ['cancel','pending_cancel']:lua.globals().buttons['Cancel performance sample']()
    elif condition=='shutdown':lua.globals().events['shutdown']()
    elif condition=='few_frames':step(lua,7000)
    elif condition=='reverse_clock':step(lua,1990);step(lua,7000)
    r=w['performance_audit.json']['runs'][0]
    assert not r['valid'],condition
    checks+=1
lua,m,w,logs=machine();lua.globals().map=None
lua.globals().buttons['Start performance sample']();step(lua,5000)
assert not w and 'Join a map' in logs[-1];checks+=1
lua,m,w,logs=machine();lua.execute('ui.reference=function() error("missing") end')
lua.execute((ROOT/'performance_audit.lua').read_text());begin(lua)
for t in range(2005,7001,5):step(lua,t)
assert w['performance_audit.json']['runs'][0]['valid'];checks+=1
lua,m,w,logs=machine()
lua.execute('original_get=ui.get;ui.get=function(n) if n=="hotkey" then return true,"Always on" end return original_get(n) end')
begin(lua)
for t in range(2005,7001,5):step(lua,t)
assert w['performance_audit.json']['runs'][0]['valid'];checks+=1
lua,m,w,logs=machine();lua.execute('writefile=function() return false end');begin(lua)
for t in range(2005,7001,5):step(lua,t)
assert not w and 'Report could not be written' in logs[-1];checks+=1
# No FFI/native pointers, native setting writes or commands are permitted.
source=(ROOT/'performance_audit.lua').read_text()
for token in ['ui.set(', 'client.exec(', 'ffi.', 'VirtualProtect', 'create_interface']:
    assert token not in source,token
report={'passed':True,'lua_cases':checks,'native_gameplay_writes':False,
        'zero_timer_resolution_cost_is_json_safe':True,
        'lua_runtime':'LuaJIT 2.1','mock_api_only':True,'game_executed':False,'windows_wpr_executed':False}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

@echo off
setlocal
set "AUDIT_TRACE=%~dp0cpu_profile.etl"
where wpr.exe >nul 2>nul
if errorlevel 1 (
  echo Windows Performance Recorder was not found.
  pause
  exit /b 1
)
if exist "%AUDIT_TRACE%" (
  echo cpu_profile.etl already exists. Rename it before recording another scene.
  pause
  exit /b 1
)
echo Run this file as Administrator.
echo Prepare the reproducible scene. After recording starts, return to the game.
echo Recording lasts 15 seconds. Do not change settings during the capture.
pause
wpr.exe -start GeneralProfile -filemode -instancename SkeetPerfAudit
if errorlevel 1 (
  echo Recording did not start. Check Administrator rights and wpr -status -instancename SkeetPerfAudit.
  echo An existing recording has NOT been cancelled.
  pause
  exit /b 1
)
echo Recording. Return to the game now.
timeout /t 15 /nobreak >nul
wpr.exe -stop "%AUDIT_TRACE%" "GameSense performance audit" -instancename SkeetPerfAudit
if errorlevel 1 (
  echo Saving failed. Check wpr -status -instancename SkeetPerfAudit to inspect the recording.
  pause
  exit /b 1
)
echo Saved "%AUDIT_TRACE%"
pause

433eb28b: 56                         push       esi
433eb28c: 8bf1                       mov        esi, ecx
433eb28e: 33c0                       xor        eax, eax
433eb290: 834e70ff                   or         dword ptr [esi + 0x70], 0xffffffff
433eb294: 834e7cff                   or         dword ptr [esi + 0x7c], 0xffffffff
433eb298: 66894662                   mov        word ptr [esi + 0x62], ax
433eb29c: 894678                     mov        dword ptr [esi + 0x78], eax
433eb29f: 8a44240c                   mov        al, byte ptr [esp + 0xc]
433eb2a3: c746580000803f             mov        dword ptr [esi + 0x58], 0x3f800000
433eb2aa: 8806                       mov        byte ptr [esi], al
433eb2ac: e8231d0100                 call       0x433fcfd4
433eb2b1: 8b4c2408                   mov        ecx, dword ptr [esp + 8]
433eb2b5: 8d560c                     lea        edx, [esi + 0xc]
433eb2b8: e890d9fdff                 call       0x433c8c4d
433eb2bd: 8bc6                       mov        eax, esi
433eb2bf: 5e                         pop        esi
433eb2c0: c20800                     ret        8

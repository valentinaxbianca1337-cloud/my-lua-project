4335ef18: 8b842454120000             mov        eax, dword ptr [esp + 0x1254]
4335ef1f: 2b842450120000             sub        eax, dword ptr [esp + 0x1250]
4335ef26: 99                         cdq        
4335ef27: f77c2448                   idiv       dword ptr [esp + 0x48]
4335ef2b: 894c2428                   mov        dword ptr [esp + 0x28], ecx
4335ef2f: 89742424                   mov        dword ptr [esp + 0x24], esi
4335ef33: 89742414                   mov        dword ptr [esp + 0x14], esi
4335ef37: 85c0                       test       eax, eax
4335ef39: 0f84d5170000               je         0x43360714
4335ef3f: 8b7508                     mov        esi, dword ptr [ebp + 8]
4335ef42: 8b8424d8000000             mov        eax, dword ptr [esp + 0xd8]
4335ef49: 81c6dc000000               add        esi, 0xdc
4335ef4f: 8b5518                     mov        edx, dword ptr [ebp + 0x18]
4335ef52: 894c2428                   mov        dword ptr [esp + 0x28], ecx
4335ef56: 8b4c2414                   mov        ecx, dword ptr [esp + 0x14]
4335ef5a: 89742434                   mov        dword ptr [esp + 0x34], esi
4335ef5e: 89442430                   mov        dword ptr [esp + 0x30], eax
4335ef62: 6bf918                     imul       edi, ecx, 0x18
4335ef65: 8d8c2448010000             lea        ecx, [esp + 0x148]
4335ef6c: 03bc2450120000             add        edi, dword ptr [esp + 0x1250]
4335ef73: 897c2444                   mov        dword ptr [esp + 0x44], edi
4335ef77: 8b4714                     mov        eax, dword ptr [edi + 0x14]
4335ef7a: 0bc2                       or         eax, edx
4335ef7c: 8944247c                   mov        dword ptr [esp + 0x7c], eax
4335ef80: 8b4710                     mov        eax, dword ptr [edi + 0x10]
4335ef83: 89442440                   mov        dword ptr [esp + 0x40], eax
4335ef87: e82929fdff                 call       0x433318b5
4335ef8c: 838c243c020000ff           or         dword ptr [esp + 0x23c], 0xffffffff
4335ef94: 8d8c24200f0000             lea        ecx, [esp + 0xf20]
4335ef9b: 838c2448020000ff           or         dword ptr [esp + 0x248], 0xffffffff
4335efa3: 33c0                       xor        eax, eax
4335efa5: 668984242e020000           mov        word ptr [esp + 0x22e], ax
4335efad: 89842444020000             mov        dword ptr [esp + 0x244], eax
4335efb4: c78424240200000000803f     mov        dword ptr [esp + 0x224], 0x3f800000
4335efbf: f30f101f                   movss      xmm3, dword ptr [edi]
4335efc3: f30f105704                 movss      xmm2, dword ptr [edi + 4]
4335efc8: f30f5c1e                   subss      xmm3, dword ptr [esi]
4335efcc: f30f5c5604                 subss      xmm2, dword ptr [esi + 4]
4335efd1: f30f106708                 movss      xmm4, dword ptr [edi + 8]
4335efd6: f30f5c6608                 subss      xmm4, dword ptr [esi + 8]
4335efdb: 0fb605e0a34643             movzx      eax, byte ptr [0x4346a3e0] ; [4346a3e0] f32=0
4335efe2: 0f28cb                     movaps     xmm1, xmm3
4335efe5: f30f59cb                   mulss      xmm1, xmm3
4335efe9: 0f28c2                     movaps     xmm0, xmm2
4335efec: 50                         push       eax
4335efed: f30f59c2                   mulss      xmm0, xmm2
4335eff1: 8b4508                     mov        eax, dword ptr [ebp + 8]
4335eff4: f30f58c8                   addss      xmm1, xmm0
4335eff8: 0f28c4                     movaps     xmm0, xmm4
4335effb: f30f59c4                   mulss      xmm0, xmm4
4335efff: ff700c                     push       dword ptr [eax + 0xc]
4335f002: f30f58c8                   addss      xmm1, xmm0
4335f006: 0f28c1                     movaps     xmm0, xmm1
4335f009: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
4335f011: f30f51c0                   sqrtss     xmm0, xmm0
4335f015: f30f118424dc030000         movss      dword ptr [esp + 0x3dc], xmm0
4335f01e: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
4335f026: f30f5ec8                   divss      xmm1, xmm0
4335f02a: f30f59d9                   mulss      xmm3, xmm1
4335f02e: f30f59d1                   mulss      xmm2, xmm1
4335f032: f30f59e1                   mulss      xmm4, xmm1
4335f036: f30f119c248c000000         movss      dword ptr [esp + 0x8c], xmm3
4335f03f: f30f119c2408010000         movss      dword ptr [esp + 0x108], xmm3
4335f048: f30f11542468               movss      dword ptr [esp + 0x68], xmm2
4335f04e: f30f1194240c010000         movss      dword ptr [esp + 0x10c], xmm2
4335f057: f30f1164245c               movss      dword ptr [esp + 0x5c], xmm4
4335f05d: f30f11a42410010000         movss      dword ptr [esp + 0x110], xmm4
4335f066: e820c20800                 call       0x433eb28b
4335f06b: f30f10a42484000000         movss      xmm4, dword ptr [esp + 0x84]
4335f074: f30f10542460               movss      xmm2, dword ptr [esp + 0x60]
4335f07a: 0f28cc                     movaps     xmm1, xmm4
4335f07d: f30f10742454               movss      xmm6, dword ptr [esp + 0x54]
4335f083: 0f28c2                     movaps     xmm0, xmm2
4335f086: f30f59c2                   mulss      xmm0, xmm2
4335f08a: f30f59cc                   mulss      xmm1, xmm4
4335f08e: f30f10ac24340f0000         movss      xmm5, dword ptr [esp + 0xf34]
4335f097: f30f58c8                   addss      xmm1, xmm0
4335f09b: 0f28c6                     movaps     xmm0, xmm6
4335f09e: f30f59c6                   mulss      xmm0, xmm6
4335f0a2: f30f58c8                   addss      xmm1, xmm0
4335f0a6: 0f28c1                     movaps     xmm0, xmm1
4335f0a9: f30f104e04                 movss      xmm1, dword ptr [esi + 4]
4335f0ae: f30f51c0                   sqrtss     xmm0, xmm0
4335f0b2: f30f118424e4030000         movss      dword ptr [esp + 0x3e4], xmm0
4335f0bb: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
4335f0c3: f30f5ee8                   divss      xmm5, xmm0
4335f0c7: f30f1006                   movss      xmm0, dword ptr [esi]
4335f0cb: 0f28dd                     movaps     xmm3, xmm5
4335f0ce: f30f59dc                   mulss      xmm3, xmm4
4335f0d2: 0f28e5                     movaps     xmm4, xmm5
4335f0d5: f30f59e2                   mulss      xmm4, xmm2
4335f0d9: f30f105608                 movss      xmm2, dword ptr [esi + 8]
4335f0de: f30f59ee                   mulss      xmm5, xmm6
4335f0e2: f30f118424f0030000         movss      dword ptr [esp + 0x3f0], xmm0
4335f0eb: f30f118c24f4030000         movss      dword ptr [esp + 0x3f4], xmm1
4335f0f4: f30f119424f8030000         movss      dword ptr [esp + 0x3f8], xmm2
4335f0fd: f30f119c2400040000         movss      dword ptr [esp + 0x400], xmm3
4335f106: f30f11a42404040000         movss      dword ptr [esp + 0x404], xmm4
4335f10f: f30f59e4                   mulss      xmm4, xmm4
4335f113: 33d2                       xor        edx, edx
4335f115: 42                         inc        edx
4335f116: 33c9                       xor        ecx, ecx
4335f118: f30f59db                   mulss      xmm3, xmm3
4335f11c: 0f57c0                     xorps      xmm0, xmm0
4335f11f: 898c2430040000             mov        dword ptr [esp + 0x430], ecx
4335f126: f30f11ac2408040000         movss      dword ptr [esp + 0x408], xmm5
4335f12f: f30f59ed                   mulss      xmm5, xmm5
4335f133: 88942434040000             mov        byte ptr [esp + 0x434], dl
4335f13a: f30f58e3                   addss      xmm4, xmm3
4335f13e: 0f29842410040000           movaps     xmmword ptr [esp + 0x410], xmm0
4335f146: 0f57db                     xorps      xmm3, xmm3
4335f149: 0f29842420040000           movaps     xmmword ptr [esp + 0x420], xmm0
4335f151: 88942435040000             mov        byte ptr [esp + 0x435], dl
4335f158: f30f58e5                   addss      xmm4, xmm5
4335f15c: 0f2ee3                     ucomiss    xmm4, xmm3
4335f15f: 9f                         lahf       
4335f160: f6c444                     test       ah, 0x44
4335f163: 7a07                       jp         0x4335f16c
4335f165: 888c2435040000             mov        byte ptr [esp + 0x435], cl
4335f16c: f30f102514054743           movss      xmm4, dword ptr [0x43470514] ; [43470514] f32=1
4335f174: 8bf9                       mov        edi, ecx
4335f176: c7442448ffffff7f           mov        dword ptr [esp + 0x48], 0x7fffffff
4335f17e: 8bc1                       mov        eax, ecx
4335f180: f30f11642420               movss      dword ptr [esp + 0x20], xmm4
4335f186: 897c241c                   mov        dword ptr [esp + 0x1c], edi
4335f18a: 894c2450                   mov        dword ptr [esp + 0x50], ecx
4335f18e: 8b80b0494743               mov        eax, dword ptr [eax + 0x434749b0]
4335f194: 3b8424e01c0000             cmp        eax, dword ptr [esp + 0x1ce0]
4335f19b: 0f83c8000000               jae        0x4335f269
4335f1a1: 8b7c2448                   mov        edi, dword ptr [esp + 0x48]
4335f1a5: 8d8c24f01c0000             lea        ecx, [esp + 0x1cf0]
4335f1ac: 69c090000000               imul       eax, eax, 0x90
4335f1b2: 03c8                       add        ecx, eax
4335f1b4: 894c2438                   mov        dword ptr [esp + 0x38], ecx
4335f1b8: 8d7140                     lea        esi, [ecx + 0x40]
4335f1bb: 8b4604                     mov        eax, dword ptr [esi + 4]
4335f1be: 83e00f                     and        eax, 0xf
4335f1c1: 393c8570494743             cmp        dword ptr [eax*4 + 0x43474970], edi
4335f1c8: 8b7c241c                   mov        edi, dword ptr [esp + 0x1c]
4335f1cc: 0f8797000000               ja         0x4335f269
4335f1d2: c78424240200000000803f     mov        dword ptr [esp + 0x224], 0x3f800000
4335f1dd: 8d8424f8010000             lea        eax, [esp + 0x1f8]
4335f1e4: f30f104630                 movss      xmm0, dword ptr [esi + 0x30]
4335f1e9: 0f2fc3                     comiss     xmm0, xmm3
4335f1ec: 50                         push       eax
4335f1ed: 7610                       jbe        0x4335f1ff
4335f1ef: 8bd6                       mov        edx, esi
4335f1f1: 8d8c24f4030000             lea        ecx, [esp + 0x3f4]
4335f1f8: e80c9c0900                 call       0x433f8e09
4335f1fd: eb13                       jmp        0x4335f212
4335f1ff: 8b5104                     mov        edx, dword ptr [ecx + 4]
4335f202: 8d4110                     lea        eax, [ecx + 0x10]
4335f205: 50                         push       eax
4335f206: 8d8c24f8030000             lea        ecx, [esp + 0x3f8]
4335f20d: e87c080400                 call       0x4339fa8e
4335f212: f30f10642420               movss      xmm4, dword ptr [esp + 0x20]
4335f218: 33d2                       xor        edx, edx
4335f21a: 42                         inc        edx
4335f21b: 85c0                       test       eax, eax
4335f21d: 782e                       js         0x4335f24d
4335f21f: 0f2fa42424020000           comiss     xmm4, dword ptr [esp + 0x224]
4335f227: 7624                       jbe        0x4335f24d
4335f229: f30f10a42424020000         movss      xmm4, dword ptr [esp + 0x224]
4335f232: 8b7c2438                   mov        edi, dword ptr [esp + 0x38]
4335f236: f30f11642420               movss      dword ptr [esp + 0x20], xmm4
4335f23c: 897c241c                   mov        dword ptr [esp + 0x1c], edi
4335f240: 395604                     cmp        dword ptr [esi + 4], edx
4335f243: 7521                       jne        0x4335f266
4335f245: c744244802000000           mov        dword ptr [esp + 0x48], 2
4335f24d: 8b442450                   mov        eax, dword ptr [esp + 0x50]
4335f251: 0f57db                     xorps      xmm3, xmm3
4335f254: 83c004                     add        eax, 4
4335f257: 89442450                   mov        dword ptr [esp + 0x50], eax
4335f25b: 83f83c                     cmp        eax, 0x3c
4335f25e: 0f822affffff               jb         0x4335f18e
4335f264: eb03                       jmp        0x4335f269
4335f266: 0f57db                     xorps      xmm3, xmm3
4335f269: 85ff                       test       edi, edi
4335f26b: 8b7c245c                   mov        edi, dword ptr [esp + 0x5c]
4335f26f: 0f847e130000               je         0x433605f3
4335f275: f30f108c2400040000         movss      xmm1, dword ptr [esp + 0x400]
4335f27e: f30f10842404040000         movss      xmm0, dword ptr [esp + 0x404]
4335f287: f30f10942408040000         movss      xmm2, dword ptr [esp + 0x408]
4335f290: 8b44241c                   mov        eax, dword ptr [esp + 0x1c]
4335f294: f30f59cc                   mulss      xmm1, xmm4
4335f298: f30f59c4                   mulss      xmm0, xmm4
4335f29c: 8b4844                     mov        ecx, dword ptr [eax + 0x44]
4335f29f: f30f588c24f0030000         addss      xmm1, dword ptr [esp + 0x3f0]
4335f2a8: f30f59d4                   mulss      xmm2, xmm4
4335f2ac: 898c243c020000             mov        dword ptr [esp + 0x23c], ecx
4335f2b3: f30f588424f4030000         addss      xmm0, dword ptr [esp + 0x3f4]
4335f2bc: 8b00                       mov        eax, dword ptr [eax]
4335f2be: f30f589424f8030000         addss      xmm2, dword ptr [esp + 0x3f8]
4335f2c7: 89842448020000             mov        dword ptr [esp + 0x248], eax
4335f2ce: f30f118c2404020000         movss      dword ptr [esp + 0x204], xmm1
4335f2d7: f30f11842408020000         movss      dword ptr [esp + 0x208], xmm0
4335f2e0: f30f1194240c020000         movss      dword ptr [esp + 0x20c], xmm2
4335f2e9: 3b4c2440                   cmp        ecx, dword ptr [esp + 0x40]
4335f2ed: 0f8500130000               jne        0x433605f3
4335f2f3: 8b44247c                   mov        eax, dword ptr [esp + 0x7c]
4335f2f7: 23c2                       and        eax, edx
4335f2f9: 89442440                   mov        dword ptr [esp + 0x40], eax
4335f2fd: 0f84ff030000               je         0x4335f702
4335f303: 8b4508                     mov        eax, dword ptr [ebp + 8]
4335f306: 0f57ff                     xorps      xmm7, xmm7
4335f309: f30f117c2420               movss      dword ptr [esp + 0x20], xmm7
4335f30f: 83b8d80000001f             cmp        dword ptr [eax + 0xd8], 0x1f
4335f316: 0f842e010000               je         0x4335f44a
4335f31c: 8b542434                   mov        edx, dword ptr [esp + 0x34]
4335f320: f30f5c0a                   subss      xmm1, dword ptr [edx]
4335f324: f30f5c4204                 subss      xmm0, dword ptr [edx + 4]
4335f329: f30f5c5208                 subss      xmm2, dword ptr [edx + 8]
4335f32e: f30f59c9                   mulss      xmm1, xmm1
4335f332: f30f59c0                   mulss      xmm0, xmm0
4335f336: f30f59d2                   mulss      xmm2, xmm2
4335f33a: f30f58c8                   addss      xmm1, xmm0
4335f33e: f30f58ca                   addss      xmm1, xmm2
4335f342: 0f28c1                     movaps     xmm0, xmm1
4335f345: 0f57c9                     xorps      xmm1, xmm1
4335f348: f30f51c0                   sqrtss     xmm0, xmm0
4335f34c: f30f118424e8030000         movss      dword ptr [esp + 0x3e8], xmm0
4335f355: f30f5905941d4743           mulss      xmm0, dword ptr [0x43471d94] ; [43471d94] f32=0.00200000009
4335f35d: f30f5ac8                   cvtss2sd   xmm1, xmm0
4335f361: f30f108424380f0000         movss      xmm0, dword ptr [esp + 0xf38]
4335f36a: 0f5ac0                     cvtps2pd   xmm0, xmm0
4335f36d: e85ec01a34                 call       0x7750b3d0
4335f372: f30f108c24400f0000         movss      xmm1, dword ptr [esp + 0xf40]
4335f37b: ffb4243c020000             push       dword ptr [esp + 0x23c]
4335f382: 8b8c2494000000             mov        ecx, dword ptr [esp + 0x94]
4335f389: 0f5ac9                     cvtps2pd   xmm1, xmm1
4335f38c: f20f59c1                   mulsd      xmm0, xmm1
4335f390: f20f5ac0                   cvtsd2ss   xmm0, xmm0
4335f394: f30f11442424               movss      dword ptr [esp + 0x24], xmm0
4335f39a: e8efd30900                 call       0x433fc78e
4335f39f: 84c0                       test       al, al
4335f3a1: 741f                       je         0x4335f3c2
4335f3a3: f30f1084243c0f0000         movss      xmm0, dword ptr [esp + 0xf3c]
4335f3ac: f30f590540224743           mulss      xmm0, dword ptr [0x43472240] ; [43472240] f32=0.5
4335f3b4: f30f59442420               mulss      xmm0, dword ptr [esp + 0x20]
4335f3ba: f30f11442420               movss      dword ptr [esp + 0x20], xmm0
4335f3c0: eb06                       jmp        0x4335f3c8
4335f3c2: f30f10442420               movss      xmm0, dword ptr [esp + 0x20]
4335f3c8: 660f6e9fd0000000           movd       xmm3, dword ptr [edi + 0xd0]
4335f3d0: 8b7708                     mov        esi, dword ptr [edi + 8]
4335f3d3: f30f2cc8                   cvttss2si  ecx, xmm0
4335f3d7: 0f5bdb                     cvtdq2ps   xmm3, xmm3
4335f3da: 85c9                       test       ecx, ecx
4335f3dc: 7f07                       jg         0x4335f3e5
4335f3de: baffffff7f                 mov        edx, 0x7fffffff
4335f3e3: eb12                       jmp        0x4335f3f7
4335f3e5: 8d46ff                     lea        eax, [esi - 1]
4335f3e8: 03c1                       add        eax, ecx
4335f3ea: 99                         cdq        
4335f3eb: f7f9                       idiv       ecx
4335f3ed: 33c9                       xor        ecx, ecx
4335f3ef: 41                         inc        ecx
4335f3f0: 3bc1                       cmp        eax, ecx
4335f3f2: 8bd1                       mov        edx, ecx
4335f3f4: 0f4fd0                     cmovg      edx, eax
4335f3f7: 660f6ece                   movd       xmm1, esi
4335f3fb: 0f28c3                     movaps     xmm0, xmm3
4335f3fe: 660f6ed2                   movd       xmm2, edx
4335f402: 0f5bc9                     cvtdq2ps   xmm1, xmm1
4335f405: 0f5bd2                     cvtdq2ps   xmm2, xmm2
4335f408: f30f5eca                   divss      xmm1, xmm2
4335f40c: e82408fdff                 call       0x4332fc35
4335f411: 8b8c243c020000             mov        ecx, dword ptr [esp + 0x23c]
4335f418: 0f28f8                     movaps     xmm7, xmm0
4335f41b: f30f10442420               movss      xmm0, dword ptr [esp + 0x20]
4335f421: 0f57db                     xorps      xmm3, xmm3
4335f424: 0f2ec3                     ucomiss    xmm0, xmm3
4335f427: 9f                         lahf       
4335f428: 33d2                       xor        edx, edx
4335f42a: f6c444                     test       ah, 0x44
4335f42d: 7b06                       jnp        0x4335f435
4335f42f: f30f5ef8                   divss      xmm7, xmm0
4335f433: eb0e                       jmp        0x4335f443
4335f435: 8bc1                       mov        eax, ecx
4335f437: 83e00f                     and        eax, 0xf
4335f43a: f30f103c8540454743         movss      xmm7, dword ptr [eax*4 + 0x43474540]
4335f443: 42                         inc        edx
4335f444: f30f117c2420               movss      dword ptr [esp + 0x20], xmm7
4335f44a: f30f10ac24340f0000         movss      xmm5, dword ptr [esp + 0xf34]
4335f453: 8b442434                   mov        eax, dword ptr [esp + 0x34]
4335f457: 0f28f5                     movaps     xmm6, xmm5
4335f45a: f30f59b42484000000         mulss      xmm6, dword ptr [esp + 0x84]
4335f463: 0f28e5                     movaps     xmm4, xmm5
4335f466: f30f59642460               mulss      xmm4, dword ptr [esp + 0x60]
4335f46c: f30f596c2454               mulss      xmm5, dword ptr [esp + 0x54]
4335f472: 3bca                       cmp        ecx, edx
4335f474: 0f84dd000000               je         0x4335f557
4335f47a: 8bf0                       mov        esi, eax
4335f47c: 8dbc248c070000             lea        edi, [esp + 0x78c]
4335f483: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335f484: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335f485: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335f486: f30f104004                 movss      xmm0, dword ptr [eax + 4]
4335f48b: 8dbc24a0270000             lea        edi, [esp + 0x27a0]
4335f492: f30f104808                 movss      xmm1, dword ptr [eax + 8]
4335f497: f30f58e0                   addss      xmm4, xmm0
4335f49b: f30f5830                   addss      xmm6, dword ptr [eax]
4335f49f: f30f58e9                   addss      xmm5, xmm1
4335f4a3: 33c0                       xor        eax, eax
4335f4a5: 89442450                   mov        dword ptr [esp + 0x50], eax
4335f4a9: f30f11a4249c070000         movss      dword ptr [esp + 0x79c], xmm4
4335f4b2: f30f11b42498070000         movss      dword ptr [esp + 0x798], xmm6
4335f4bb: f30f11ac24a0070000         movss      dword ptr [esp + 0x7a0], xmm5
4335f4c4: 8bc8                       mov        ecx, eax
4335f4c6: 894c2448                   mov        dword ptr [esp + 0x48], ecx
4335f4ca: 3907                       cmp        dword ptr [edi], eax
4335f4cc: 0f861d110000               jbe        0x433605ef
4335f4d2: 8db780000000               lea        esi, [edi + 0x80]
4335f4d8: f30f1006                   movss      xmm0, dword ptr [esi]
4335f4dc: 0f2fc3                     comiss     xmm0, xmm3
4335f4df: 7633                       jbe        0x4335f514
4335f4e1: 8b46d4                     mov        eax, dword ptr [esi - 0x2c]
4335f4e4: 83e00f                     and        eax, 0xf
4335f4e7: f30f10048540454743         movss      xmm0, dword ptr [eax*4 + 0x43474540]
4335f4f0: 0f2fc7                     comiss     xmm0, xmm7
4335f4f3: 721f                       jb         0x4335f514
4335f4f5: 8d4ed8                     lea        ecx, [esi - 0x28]
4335f4f8: 8d94248c070000             lea        edx, [esp + 0x78c]
4335f4ff: e8ded60300                 call       0x4339cbe2
4335f504: f30f100e                   movss      xmm1, dword ptr [esi]
4335f508: 0f2fc8                     comiss     xmm1, xmm0
4335f50b: 7322                       jae        0x4335f52f
4335f50d: 8b4c2448                   mov        ecx, dword ptr [esp + 0x48]
4335f511: 0f57db                     xorps      xmm3, xmm3
4335f514: 41                         inc        ecx
4335f515: 81c690000000               add        esi, 0x90
4335f51b: 894c2448                   mov        dword ptr [esp + 0x48], ecx
4335f51f: 3b0f                       cmp        ecx, dword ptr [edi]
4335f521: 0f83c8100000               jae        0x433605ef
4335f527: f30f107c2420               movss      xmm7, dword ptr [esp + 0x20]
4335f52d: eba9                       jmp        0x4335f4d8
4335f52f: 8b542450                   mov        edx, dword ptr [esp + 0x50]
4335f533: 81c7c00a0000               add        edi, 0xac0
4335f539: 42                         inc        edx
4335f53a: 89542450                   mov        dword ptr [esp + 0x50], edx
4335f53e: 83fa03                     cmp        edx, 3
4335f541: 0f8db0010000               jge        0x4335f6f7
4335f547: f30f107c2420               movss      xmm7, dword ptr [esp + 0x20]
4335f54d: 0f57db                     xorps      xmm3, xmm3
4335f550: 33c0                       xor        eax, eax
4335f552: e96dffffff                 jmp        0x4335f4c4
4335f557: f30f1000                   movss      xmm0, dword ptr [eax]
4335f55b: 33c9                       xor        ecx, ecx
4335f55d: f30f104804                 movss      xmm1, dword ptr [eax + 4]
4335f562: f30f105008                 movss      xmm2, dword ptr [eax + 8]
4335f567: f30f11a424940a0000         movss      dword ptr [esp + 0xa94], xmm4
4335f570: f30f11b424900a0000         movss      dword ptr [esp + 0xa90], xmm6
4335f579: f30f59e4                   mulss      xmm4, xmm4
4335f57d: 898c24c00a0000             mov        dword ptr [esp + 0xac0], ecx
4335f584: f30f59f6                   mulss      xmm6, xmm6
4335f588: 889424c40a0000             mov        byte ptr [esp + 0xac4], dl
4335f58f: f30f11ac24980a0000         movss      dword ptr [esp + 0xa98], xmm5
4335f598: f30f59ed                   mulss      xmm5, xmm5
4335f59c: 889424c50a0000             mov        byte ptr [esp + 0xac5], dl
4335f5a3: f30f58e6                   addss      xmm4, xmm6
4335f5a7: f30f118424800a0000         movss      dword ptr [esp + 0xa80], xmm0
4335f5b0: 0f57c0                     xorps      xmm0, xmm0
4335f5b3: f30f118c24840a0000         movss      dword ptr [esp + 0xa84], xmm1
4335f5bc: f30f119424880a0000         movss      dword ptr [esp + 0xa88], xmm2
4335f5c5: 0f298424a00a0000           movaps     xmmword ptr [esp + 0xaa0], xmm0
4335f5cd: 0f298424b00a0000           movaps     xmmword ptr [esp + 0xab0], xmm0
4335f5d5: f30f58e5                   addss      xmm4, xmm5
4335f5d9: 0f2ee3                     ucomiss    xmm4, xmm3
4335f5dc: 9f                         lahf       
4335f5dd: f6c444                     test       ah, 0x44
4335f5e0: 7a07                       jp         0x4335f5e9
4335f5e2: 888c24c50a0000             mov        byte ptr [esp + 0xac5], cl
4335f5e9: 894c2448                   mov        dword ptr [esp + 0x48], ecx
4335f5ed: 8db424b4270000             lea        esi, [esp + 0x27b4]
4335f5f4: 838c24dc0c0000ff           or         dword ptr [esp + 0xcdc], 0xffffffff
4335f5fc: 8d8424980c0000             lea        eax, [esp + 0xc98]
4335f603: 838c24e80c0000ff           or         dword ptr [esp + 0xce8], 0xffffffff
4335f60b: 50                         push       eax
4335f60c: 898c24e80c0000             mov        dword ptr [esp + 0xce8], ecx
4335f613: 8d460c                     lea        eax, [esi + 0xc]
4335f616: c78424c80c00000000803f     mov        dword ptr [esp + 0xcc8], 0x3f800000
4335f621: 8d8c24840a0000             lea        ecx, [esp + 0xa84]
4335f628: 66c78424d20c00000000       mov        word ptr [esp + 0xcd2], 0
4335f632: 8b16                       mov        edx, dword ptr [esi]
4335f634: 50                         push       eax
4335f635: e854040400                 call       0x4339fa8e
4335f63a: 85c0                       test       eax, eax
4335f63c: 0f88b10f0000               js         0x433605f3
4335f642: f30f108424c40c0000         movss      xmm0, dword ptr [esp + 0xcc4]
4335f64b: 33c9                       xor        ecx, ecx
4335f64d: 8bc1                       mov        eax, ecx
4335f64f: f30f11442438               movss      dword ptr [esp + 0x38], xmm0
4335f655: 89442420                   mov        dword ptr [esp + 0x20], eax
4335f659: 394eec                     cmp        dword ptr [esi - 0x14], ecx
4335f65c: 767f                       jbe        0x4335f6dd
4335f65e: 8bce                       mov        ecx, esi
4335f660: 0f57c9                     xorps      xmm1, xmm1
4335f663: 894c241c                   mov        dword ptr [esp + 0x1c], ecx
4335f667: 8b11                       mov        edx, dword ptr [ecx]
4335f669: f30f104230                 movss      xmm0, dword ptr [edx + 0x30]
4335f66e: 0f2fc1                     comiss     xmm0, xmm1
4335f671: 7654                       jbe        0x4335f6c7
4335f673: 837a0403                   cmp        dword ptr [edx + 4], 3
4335f677: 7406                       je         0x4335f67f
4335f679: 837a0402                   cmp        dword ptr [edx + 4], 2
4335f67d: 7548                       jne        0x4335f6c7
4335f67f: 8d8424980c0000             lea        eax, [esp + 0xc98]
4335f686: c78424c40c00000000803f     mov        dword ptr [esp + 0xcc4], 0x3f800000
4335f691: 8b11                       mov        edx, dword ptr [ecx]
4335f693: 50                         push       eax
4335f694: 8d410c                     lea        eax, [ecx + 0xc]
4335f697: 50                         push       eax
4335f698: 8d8c24880a0000             lea        ecx, [esp + 0xa88]
4335f69f: e8ea030400                 call       0x4339fa8e
4335f6a4: 85c0                       test       eax, eax
4335f6a6: 7814                       js         0x4335f6bc
4335f6a8: f30f10442438               movss      xmm0, dword ptr [esp + 0x38]
4335f6ae: 0f2f8424c40c0000           comiss     xmm0, dword ptr [esp + 0xcc4]
4335f6b6: 0f87370f0000               ja         0x433605f3
4335f6bc: 8b442420                   mov        eax, dword ptr [esp + 0x20]
4335f6c0: 0f57c9                     xorps      xmm1, xmm1
4335f6c3: 8b4c241c                   mov        ecx, dword ptr [esp + 0x1c]
4335f6c7: 40                         inc        eax
4335f6c8: 81c190000000               add        ecx, 0x90
4335f6ce: 89442420                   mov        dword ptr [esp + 0x20], eax
4335f6d2: 894c241c                   mov        dword ptr [esp + 0x1c], ecx
4335f6d6: 3b46ec                     cmp        eax, dword ptr [esi - 0x14]
4335f6d9: 728c                       jb         0x4335f667
4335f6db: 33c9                       xor        ecx, ecx
4335f6dd: 8b442448                   mov        eax, dword ptr [esp + 0x48]
4335f6e1: 81c6c00a0000               add        esi, 0xac0
4335f6e7: 40                         inc        eax
4335f6e8: 89442448                   mov        dword ptr [esp + 0x48], eax
4335f6ec: 83f803                     cmp        eax, 3
4335f6ef: 0f8cfffeffff               jl         0x4335f5f4
4335f6f5: eb04                       jmp        0x4335f6fb
4335f6f7: 8b7c245c                   mov        edi, dword ptr [esp + 0x5c]
4335f6fb: 8b8c243c020000             mov        ecx, dword ptr [esp + 0x23c]
4335f702: 660f6e8fd0000000           movd       xmm1, dword ptr [edi + 0xd0]
4335f70a: 83e10f                     and        ecx, 0xf
4335f70d: 0f5bc9                     cvtdq2ps   xmm1, xmm1
4335f710: 33c0                       xor        eax, eax
4335f712: 8b542434                   mov        edx, dword ptr [esp + 0x34]
4335f716: 89842420080000             mov        dword ptr [esp + 0x820], eax
4335f71d: 89842424080000             mov        dword ptr [esp + 0x824], eax
4335f724: 89842428080000             mov        dword ptr [esp + 0x828], eax
4335f72b: 8d8424200f0000             lea        eax, [esp + 0xf20]
4335f732: 0f280590f24643             movaps     xmm0, xmmword ptr [0x4346f290] ; [4346f290] f32=0
4335f739: f30f5e0c8d40454743         divss      xmm1, dword ptr [ecx*4 + 0x43474540]
4335f742: 8b0d08584743               mov        ecx, dword ptr [0x43475808] ; [43475808] f32=0
4335f748: 50                         push       eax
4335f749: 8d842420080000             lea        eax, [esp + 0x820]
4335f750: c784242008000004044743     mov        dword ptr [esp + 0x820], 0x43470404
4335f75b: 50                         push       eax
4335f75c: 8d84240c020000             lea        eax, [esp + 0x20c]
4335f763: 50                         push       eax
4335f764: 0f11842438080000           movups     xmmword ptr [esp + 0x838], xmm0
4335f76c: f30f118c2448080000         movss      dword ptr [esp + 0x848], xmm1
4335f775: e8b1a5fcff                 call       0x43329d2b
4335f77a: f30f2c8424280f0000         cvttss2si  eax, dword ptr [esp + 0xf28]
4335f783: 85c0                       test       eax, eax
4335f785: 0f8e680e0000               jle        0x433605f3
4335f78b: ffb4243c020000             push       dword ptr [esp + 0x23c]
4335f792: 8d8c24240f0000             lea        ecx, [esp + 0xf24]
4335f799: ffb42494000000             push       dword ptr [esp + 0x94]
4335f7a0: e828a70800                 call       0x433e9ecd
4335f7a5: 8b742444                   mov        esi, dword ptr [esp + 0x44]
4335f7a9: 8dbc2448010000             lea        edi, [esp + 0x148]
4335f7b0: 33c9                       xor        ecx, ecx
4335f7b2: 41                         inc        ecx
4335f7b3: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335f7b4: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335f7b5: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335f7b6: 8b7c245c                   mov        edi, dword ptr [esp + 0x5c]
4335f7ba: 8bb42480000000             mov        esi, dword ptr [esp + 0x80]
4335f7c1: 89842464010000             mov        dword ptr [esp + 0x164], eax
4335f7c8: 8b842448020000             mov        eax, dword ptr [esp + 0x248]
4335f7cf: 89842468010000             mov        dword ptr [esp + 0x168], eax
4335f7d6: 8b84243c020000             mov        eax, dword ptr [esp + 0x23c]
4335f7dd: 8984246c010000             mov        dword ptr [esp + 0x16c], eax
4335f7e4: 8b44247c                   mov        eax, dword ptr [esp + 0x7c]
4335f7e8: 89842470010000             mov        dword ptr [esp + 0x170], eax
4335f7ef: 8b8424240f0000             mov        eax, dword ptr [esp + 0xf24]
4335f7f6: d1e8                       shr        eax, 1
4335f7f8: c78424740100000000803f     mov        dword ptr [esp + 0x174], 0x3f800000
4335f803: 84c1                       test       cl, al
4335f805: 7424                       je         0x4335f82b
4335f807: 8b5704                     mov        edx, dword ptr [edi + 4]
4335f80a: 83e23f                     and        edx, 0x3f
4335f80d: 8bca                       mov        ecx, edx
4335f80f: c1e905                     shr        ecx, 5
4335f812: 6a1f                       push       0x1f
4335f814: 58                         pop        eax
4335f815: 23d0                       and        edx, eax
4335f817: 8b848eac010000             mov        eax, dword ptr [esi + ecx*4 + 0x1ac]
4335f81e: 0fabd0                     bts        eax, edx
4335f821: 89848eac010000             mov        dword ptr [esi + ecx*4 + 0x1ac], eax
4335f828: 33c9                       xor        ecx, ecx
4335f82a: 41                         inc        ecx
4335f82b: ff87e8000000               inc        dword ptr [edi + 0xe8]
4335f831: f6867801000010             test       byte ptr [esi + 0x178], 0x10
4335f838: 8bb42464010000             mov        esi, dword ptr [esp + 0x164]
4335f83f: 0f846e0c0000               je         0x433604b3
4335f845: 3bb7d0000000               cmp        esi, dword ptr [edi + 0xd0]
4335f84b: 0f8c620c0000               jl         0x433604b3
4335f851: 8b4508                     mov        eax, dword ptr [ebp + 8]
4335f854: 83b8d80000001f             cmp        dword ptr [eax + 0xd8], 0x1f
4335f85b: 750e                       jne        0x4335f86b
4335f85d: 0f57ed                     xorps      xmm5, xmm5
4335f860: f30f116c2420               movss      dword ptr [esp + 0x20], xmm5
4335f866: e98f000000                 jmp        0x4335f8fa
4335f86b: 8b4708                     mov        eax, dword ptr [edi + 8]
4335f86e: 85f6                       test       esi, esi
4335f870: 7f07                       jg         0x4335f879
4335f872: baffffff7f                 mov        edx, 0x7fffffff
4335f877: eb0d                       jmp        0x4335f886
4335f879: 48                         dec        eax
4335f87a: 03c6                       add        eax, esi
4335f87c: 99                         cdq        
4335f87d: f7fe                       idiv       esi
4335f87f: 8bd1                       mov        edx, ecx
4335f881: 3bc1                       cmp        eax, ecx
4335f883: 0f4fd0                     cmovg      edx, eax
4335f886: 8b84246c010000             mov        eax, dword ptr [esp + 0x16c]
4335f88d: 660f6ec6                   movd       xmm0, esi
4335f891: 83e00f                     and        eax, 0xf
4335f894: 0f5bc0                     cvtdq2ps   xmm0, xmm0
4335f897: 660f6e4f08                 movd       xmm1, dword ptr [edi + 8]
4335f89c: f30f5e048540454743         divss      xmm0, dword ptr [eax*4 + 0x43474540]
4335f8a5: 0f5bc9                     cvtdq2ps   xmm1, xmm1
4335f8a8: f30f11442438               movss      dword ptr [esp + 0x38], xmm0
4335f8ae: 660f6ec2                   movd       xmm0, edx
4335f8b2: 0f5bc0                     cvtdq2ps   xmm0, xmm0
4335f8b5: f30f5ec8                   divss      xmm1, xmm0
4335f8b9: 660f6e87d0000000           movd       xmm0, dword ptr [edi + 0xd0]
4335f8c1: 0f5bc0                     cvtdq2ps   xmm0, xmm0
4335f8c4: e86c03fdff                 call       0x4332fc35
4335f8c9: f30f104c2438               movss      xmm1, dword ptr [esp + 0x38]
4335f8cf: 0f57ed                     xorps      xmm5, xmm5
4335f8d2: 0f2ecd                     ucomiss    xmm1, xmm5
4335f8d5: 9f                         lahf       
4335f8d6: f6c444                     test       ah, 0x44
4335f8d9: 7b06                       jnp        0x4335f8e1
4335f8db: f30f5ec1                   divss      xmm0, xmm1
4335f8df: eb13                       jmp        0x4335f8f4
4335f8e1: 8b84246c010000             mov        eax, dword ptr [esp + 0x16c]
4335f8e8: 83e00f                     and        eax, 0xf
4335f8eb: f30f10048540454743         movss      xmm0, dword ptr [eax*4 + 0x43474540]
4335f8f4: f30f11442420               movss      dword ptr [esp + 0x20], xmm0
4335f8fa: 837c244000                 cmp        dword ptr [esp + 0x40], 0
4335f8ff: f30f108424340f0000         movss      xmm0, dword ptr [esp + 0xf34]
4335f908: 0f84ab050000               je         0x4335feb9
4335f90e: f30f108c2484000000         movss      xmm1, dword ptr [esp + 0x84]
4335f917: 33c9                       xor        ecx, ecx
4335f919: 8bb4243c020000             mov        esi, dword ptr [esp + 0x23c]
4335f920: 0f2ecd                     ucomiss    xmm1, xmm5
4335f923: 89b424a0000000             mov        dword ptr [esp + 0xa0], esi
4335f92a: 894c247c                   mov        dword ptr [esp + 0x7c], ecx
4335f92e: f30f118424a4000000         movss      dword ptr [esp + 0xa4], xmm0
4335f937: f30f10442460               movss      xmm0, dword ptr [esp + 0x60]
4335f93d: 9f                         lahf       
4335f93e: f6c444                     test       ah, 0x44
4335f941: 7a5d                       jp         0x4335f9a0
4335f943: 0f2ec5                     ucomiss    xmm0, xmm5
4335f946: 9f                         lahf       
4335f947: f6c444                     test       ah, 0x44
4335f94a: 7a54                       jp         0x4335f9a0
4335f94c: f30f10942488000000         movss      xmm2, dword ptr [esp + 0x88]
4335f955: 0f57ff                     xorps      xmm7, xmm7
4335f958: f30f10442454               movss      xmm0, dword ptr [esp + 0x54]
4335f95e: 0f57f6                     xorps      xmm6, xmm6
4335f961: 0f5705d0034743             xorps      xmm0, xmmword ptr [0x434703d0] ; [434703d0] f32=-0
4335f968: 0f57e4                     xorps      xmm4, xmm4
4335f96b: f30f117c2440               movss      dword ptr [esp + 0x40], xmm7
4335f971: 0f57c9                     xorps      xmm1, xmm1
4335f974: f30f11bc24f4000000         movss      dword ptr [esp + 0xf4], xmm7
4335f97d: f30f11542418               movss      dword ptr [esp + 0x18], xmm2
4335f983: f30f119424f8000000         movss      dword ptr [esp + 0xf8], xmm2
4335f98c: f30f1174242c               movss      dword ptr [esp + 0x2c], xmm6
4335f992: f30f11b424fc000000         movss      dword ptr [esp + 0xfc], xmm6
4335f99b: e948010000                 jmp        0x4335fae8
4335f9a0: f30f10642454               movss      xmm4, dword ptr [esp + 0x54]
4335f9a6: 0f28d0                     movaps     xmm2, xmm0
4335f9a9: f30f59c5                   mulss      xmm0, xmm5
4335f9ad: 0f28d9                     movaps     xmm3, xmm1
4335f9b0: f30f59e5                   mulss      xmm4, xmm5
4335f9b4: f30f59dd                   mulss      xmm3, xmm5
4335f9b8: f30f5cd4                   subss      xmm2, xmm4
4335f9bc: f30f103514054743           movss      xmm6, dword ptr [0x43470514] ; [43470514] f32=1
4335f9c4: f30f5ce1                   subss      xmm4, xmm1
4335f9c8: f30f5cd8                   subss      xmm3, xmm0
4335f9cc: 0f28ca                     movaps     xmm1, xmm2
4335f9cf: f30f59ca                   mulss      xmm1, xmm2
4335f9d3: 0f28c4                     movaps     xmm0, xmm4
4335f9d6: f30f59c4                   mulss      xmm0, xmm4
4335f9da: f30f58c8                   addss      xmm1, xmm0
4335f9de: 0f28c3                     movaps     xmm0, xmm3
4335f9e1: f30f59c3                   mulss      xmm0, xmm3
4335f9e5: f30f58c8                   addss      xmm1, xmm0
4335f9e9: 0f28c1                     movaps     xmm0, xmm1
4335f9ec: f30f51c0                   sqrtss     xmm0, xmm0
4335f9f0: f30f118424ec030000         movss      dword ptr [esp + 0x3ec], xmm0
4335f9f9: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
4335fa01: f30f5ef0                   divss      xmm6, xmm0
4335fa05: 0f28ce                     movaps     xmm1, xmm6
4335fa08: 0f28fe                     movaps     xmm7, xmm6
4335fa0b: f30f59cc                   mulss      xmm1, xmm4
4335fa0f: f30f10642454               movss      xmm4, dword ptr [esp + 0x54]
4335fa15: f30f59fa                   mulss      xmm7, xmm2
4335fa19: f30f10542460               movss      xmm2, dword ptr [esp + 0x60]
4335fa1f: f30f59f3                   mulss      xmm6, xmm3
4335fa23: 0f28c2                     movaps     xmm0, xmm2
4335fa26: f30f109c2484000000         movss      xmm3, dword ptr [esp + 0x84]
4335fa2f: f30f59e1                   mulss      xmm4, xmm1
4335fa33: f30f59c6                   mulss      xmm0, xmm6
4335fa37: f30f59de                   mulss      xmm3, xmm6
4335fa3b: f30f5ce0                   subss      xmm4, xmm0
4335fa3f: f30f114c2418               movss      dword ptr [esp + 0x18], xmm1
4335fa45: f30f10442454               movss      xmm0, dword ptr [esp + 0x54]
4335fa4b: f30f59c7                   mulss      xmm0, xmm7
4335fa4f: f30f59d7                   mulss      xmm2, xmm7
4335fa53: f30f5cd8                   subss      xmm3, xmm0
4335fa57: f30f118c24f8000000         movss      dword ptr [esp + 0xf8], xmm1
4335fa60: f30f10842484000000         movss      xmm0, dword ptr [esp + 0x84]
4335fa69: f30f59c1                   mulss      xmm0, xmm1
4335fa6d: 0f28cc                     movaps     xmm1, xmm4
4335fa70: f30f59cc                   mulss      xmm1, xmm4
4335fa74: f30f5cd0                   subss      xmm2, xmm0
4335fa78: f30f117c2440               movss      dword ptr [esp + 0x40], xmm7
4335fa7e: 0f28c3                     movaps     xmm0, xmm3
4335fa81: f30f11bc24f4000000         movss      dword ptr [esp + 0xf4], xmm7
4335fa8a: f30f59c3                   mulss      xmm0, xmm3
4335fa8e: f30f1174242c               movss      dword ptr [esp + 0x2c], xmm6
4335fa94: f30f11b424fc000000         movss      dword ptr [esp + 0xfc], xmm6
4335fa9d: f30f58c8                   addss      xmm1, xmm0
4335faa1: 0f28c2                     movaps     xmm0, xmm2
4335faa4: f30f59c2                   mulss      xmm0, xmm2
4335faa8: f30f58c8                   addss      xmm1, xmm0
4335faac: 0f28c1                     movaps     xmm0, xmm1
4335faaf: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
4335fab7: f30f51c0                   sqrtss     xmm0, xmm0
4335fabb: f30f11842474060000         movss      dword ptr [esp + 0x674], xmm0
4335fac4: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
4335facc: f30f5ec8                   divss      xmm1, xmm0
4335fad0: 0f28c1                     movaps     xmm0, xmm1
4335fad3: f30f59c4                   mulss      xmm0, xmm4
4335fad7: 0f28e1                     movaps     xmm4, xmm1
4335fada: f30f59ca                   mulss      xmm1, xmm2
4335fade: f30f10542418               movss      xmm2, dword ptr [esp + 0x18]
4335fae4: f30f59e3                   mulss      xmm4, xmm3
4335fae8: 8b842480000000             mov        eax, dword ptr [esp + 0x80]
4335faef: 051c110000                 add        eax, 0x111c
4335faf4: f30f118c24f0000000         movss      dword ptr [esp + 0xf0], xmm1
4335fafd: f30f114c2458               movss      dword ptr [esp + 0x58], xmm1
4335fb03: f30f11a424ec000000         movss      dword ptr [esp + 0xec], xmm4
4335fb0c: f30f11642438               movss      dword ptr [esp + 0x38], xmm4
4335fb12: f30f118424e8000000         movss      dword ptr [esp + 0xe8], xmm0
4335fb1b: f30f1184248c000000         movss      dword ptr [esp + 0x8c], xmm0
4335fb24: 89442478                   mov        dword ptr [esp + 0x78], eax
4335fb28: c744246420000000           mov        dword ptr [esp + 0x64], 0x20
4335fb30: eb03                       jmp        0x4335fb35
4335fb32: 0f57ed                     xorps      xmm5, xmm5
4335fb35: f30f594004                 mulss      xmm0, dword ptr [eax + 4]
4335fb3a: 0f28df                     movaps     xmm3, xmm7
4335fb3d: f30f5918                   mulss      xmm3, dword ptr [eax]
4335fb41: f30f5910                   mulss      xmm2, dword ptr [eax]
4335fb45: f30f589c2484000000         addss      xmm3, dword ptr [esp + 0x84]
4335fb4e: f30f58542460               addss      xmm2, dword ptr [esp + 0x60]
4335fb54: f30f58d8                   addss      xmm3, xmm0
4335fb58: 0f28c4                     movaps     xmm0, xmm4
4335fb5b: f30f594004                 mulss      xmm0, dword ptr [eax + 4]
4335fb60: 0f28e6                     movaps     xmm4, xmm6
4335fb63: f30f5920                   mulss      xmm4, dword ptr [eax]
4335fb67: f30f58d0                   addss      xmm2, xmm0
4335fb6b: 0f28c1                     movaps     xmm0, xmm1
4335fb6e: f30f594004                 mulss      xmm0, dword ptr [eax + 4]
4335fb73: 0f28cb                     movaps     xmm1, xmm3
4335fb76: 8b442434                   mov        eax, dword ptr [esp + 0x34]
4335fb7a: f30f59cb                   mulss      xmm1, xmm3
4335fb7e: f30f58642454               addss      xmm4, dword ptr [esp + 0x54]
4335fb84: f30f58e0                   addss      xmm4, xmm0
4335fb88: 0f28c2                     movaps     xmm0, xmm2
4335fb8b: f30f59c2                   mulss      xmm0, xmm2
4335fb8f: f30f58c8                   addss      xmm1, xmm0
4335fb93: 0f28c4                     movaps     xmm0, xmm4
4335fb96: f30f59c4                   mulss      xmm0, xmm4
4335fb9a: f30f58c8                   addss      xmm1, xmm0
4335fb9e: 0f28c1                     movaps     xmm0, xmm1
4335fba1: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
4335fba9: f30f51c0                   sqrtss     xmm0, xmm0
4335fbad: f30f11842478060000         movss      dword ptr [esp + 0x678], xmm0
4335fbb6: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
4335fbbe: f30f5ec8                   divss      xmm1, xmm0
4335fbc2: f30f108424a4000000         movss      xmm0, dword ptr [esp + 0xa4]
4335fbcb: f30f59e1                   mulss      xmm4, xmm1
4335fbcf: 0f28f1                     movaps     xmm6, xmm1
4335fbd2: f30f59f3                   mulss      xmm6, xmm3
4335fbd6: 0f28d9                     movaps     xmm3, xmm1
4335fbd9: f30f59da                   mulss      xmm3, xmm2
4335fbdd: f30f59e0                   mulss      xmm4, xmm0
4335fbe1: f30f59f0                   mulss      xmm6, xmm0
4335fbe5: f30f59d8                   mulss      xmm3, xmm0
4335fbe9: 83fe01                     cmp        esi, 1
4335fbec: 0f842a010000               je         0x4335fd1c
4335fbf2: 8bf0                       mov        esi, eax
4335fbf4: 894c2450                   mov        dword ptr [esp + 0x50], ecx
4335fbf8: 8dbc24bc070000             lea        edi, [esp + 0x7bc]
4335fbff: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335fc00: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335fc01: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
4335fc02: f30f104004                 movss      xmm0, dword ptr [eax + 4]
4335fc07: 8dbc24a0270000             lea        edi, [esp + 0x27a0]
4335fc0e: f30f104808                 movss      xmm1, dword ptr [eax + 8]
4335fc13: f30f58c3                   addss      xmm0, xmm3
4335fc17: f30f5830                   addss      xmm6, dword ptr [eax]
4335fc1b: f30f58cc                   addss      xmm1, xmm4
4335fc1f: f30f118424cc070000         movss      dword ptr [esp + 0x7cc], xmm0
4335fc28: f30f11b424c8070000         movss      dword ptr [esp + 0x7c8], xmm6
4335fc31: f30f118c24d0070000         movss      dword ptr [esp + 0x7d0], xmm1
4335fc3a: 8bd1                       mov        edx, ecx
4335fc3c: 89542448                   mov        dword ptr [esp + 0x48], edx
4335fc40: 390f                       cmp        dword ptr [edi], ecx
4335fc42: 7655                       jbe        0x4335fc99
4335fc44: 8db780000000               lea        esi, [edi + 0x80]
4335fc4a: f30f1006                   movss      xmm0, dword ptr [esi]
4335fc4e: 0f2fc5                     comiss     xmm0, xmm5
4335fc51: 7635                       jbe        0x4335fc88
4335fc53: 8b46d4                     mov        eax, dword ptr [esi - 0x2c]
4335fc56: 83e00f                     and        eax, 0xf
4335fc59: f30f10048540454743         movss      xmm0, dword ptr [eax*4 + 0x43474540]
4335fc62: 0f2f442420                 comiss     xmm0, dword ptr [esp + 0x20]
4335fc67: 721f                       jb         0x4335fc88
4335fc69: 8d4ed8                     lea        ecx, [esi - 0x28]
4335fc6c: 8d9424bc070000             lea        edx, [esp + 0x7bc]
4335fc73: e86acf0300                 call       0x4339cbe2
4335fc78: f30f100e                   movss      xmm1, dword ptr [esi]
4335fc7c: 0f2fc8                     comiss     xmm1, xmm0
4335fc7f: 7379                       jae        0x4335fcfa
4335fc81: 8b542448                   mov        edx, dword ptr [esp + 0x48]
4335fc85: 0f57ed                     xorps      xmm5, xmm5
4335fc88: 42                         inc        edx
4335fc89: 81c690000000               add        esi, 0x90
4335fc8f: 89542448                   mov        dword ptr [esp + 0x48], edx
4335fc93: 3b17                       cmp        edx, dword ptr [edi]
4335fc95: 72b3                       jb         0x4335fc4a
4335fc97: 33c9                       xor        ecx, ecx
4335fc99: 8ad1                       mov        dl, cl
4335fc9b: 8b74247c                   mov        esi, dword ptr [esp + 0x7c]
4335fc9f: 84d2                       test       dl, dl
4335fca1: f30f1084248c000000         movss      xmm0, dword ptr [esp + 0x8c]
4335fcaa: f30f1074242c               movss      xmm6, dword ptr [esp + 0x2c]
4335fcb0: f30f104c2458               movss      xmm1, dword ptr [esp + 0x58]
4335fcb6: f30f107c2440               movss      xmm7, dword ptr [esp + 0x40]
4335fcbc: 8d4601                     lea        eax, [esi + 1]
4335fcbf: f30f10542418               movss      xmm2, dword ptr [esp + 0x18]
4335fcc5: 0f44c6                     cmove      eax, esi
4335fcc8: f30f10642438               movss      xmm4, dword ptr [esp + 0x38]
4335fcce: 8bd0                       mov        edx, eax
4335fcd0: 8b442478                   mov        eax, dword ptr [esp + 0x78]
4335fcd4: 8bb424a0000000             mov        esi, dword ptr [esp + 0xa0]
4335fcdb: 83c020                     add        eax, 0x20
4335fcde: 836c246401                 sub        dword ptr [esp + 0x64], 1
4335fce3: 8954247c                   mov        dword ptr [esp + 0x7c], edx
4335fce7: 89442478                   mov        dword ptr [esp + 0x78], eax
4335fceb: 0f8541feffff               jne        0x4335fb32
4335fcf1: 660f6ec2                   movd       xmm0, edx
4335fcf5: e99e070000                 jmp        0x43360498
4335fcfa: 8b442450                   mov        eax, dword ptr [esp + 0x50]
4335fcfe: 81c7c00a0000               add        edi, 0xac0
4335fd04: 40                         inc        eax
4335fd05: 89442450                   mov        dword ptr [esp + 0x50], eax
4335fd09: 83f803                     cmp        eax, 3
4335fd0c: 0f8d9e010000               jge        0x4335feb0
4335fd12: 0f57ed                     xorps      xmm5, xmm5
4335fd15: 33c9                       xor        ecx, ecx
4335fd17: e91effffff                 jmp        0x4335fc3a
4335fd1c: f30f1000                   movss      xmm0, dword ptr [eax]
4335fd20: f30f104804                 movss      xmm1, dword ptr [eax + 4]
4335fd25: f30f105008                 movss      xmm2, dword ptr [eax + 8]
4335fd2a: f30f119c24e40a0000         movss      dword ptr [esp + 0xae4], xmm3
4335fd33: f30f11b424e00a0000         movss      dword ptr [esp + 0xae0], xmm6
4335fd3c: f30f59db                   mulss      xmm3, xmm3
4335fd40: 898c24100b0000             mov        dword ptr [esp + 0xb10], ecx
4335fd47: f30f59f6                   mulss      xmm6, xmm6
4335fd4b: c68424140b000001           mov        byte ptr [esp + 0xb14], 1
4335fd53: f30f11a424e80a0000         movss      dword ptr [esp + 0xae8], xmm4
4335fd5c: f30f59e4                   mulss      xmm4, xmm4
4335fd60: c68424150b000001           mov        byte ptr [esp + 0xb15], 1
4335fd68: f30f58de                   addss      xmm3, xmm6
4335fd6c: f30f118424d00a0000         movss      dword ptr [esp + 0xad0], xmm0
4335fd75: 0f57c0                     xorps      xmm0, xmm0
4335fd78: f30f118c24d40a0000         movss      dword ptr [esp + 0xad4], xmm1
4335fd81: f30f119424d80a0000         movss      dword ptr [esp + 0xad8], xmm2
4335fd8a: 0f298424f00a0000           movaps     xmmword ptr [esp + 0xaf0], xmm0
4335fd92: 0f298424000b0000           movaps     xmmword ptr [esp + 0xb00], xmm0
4335fd9a: f30f58dc                   addss      xmm3, xmm4
4335fd9e: 0f2edd                     ucomiss    xmm3, xmm5
4335fda1: 9f                         lahf       
4335fda2: f6c444                     test       ah, 0x44
4335fda5: 7a07                       jp         0x4335fdae
4335fda7: 888c24150b0000             mov        byte ptr [esp + 0xb15], cl
4335fdae: 8bf9                       mov        edi, ecx
4335fdb0: 8db424b4270000             lea        esi, [esp + 0x27b4]
4335fdb7: 897c2448                   mov        dword ptr [esp + 0x48], edi
4335fdbb: 838c24340d0000ff           or         dword ptr [esp + 0xd34], 0xffffffff
4335fdc3: 8d8424f00c0000             lea        eax, [esp + 0xcf0]
4335fdca: 838c24400d0000ff           or         dword ptr [esp + 0xd40], 0xffffffff
4335fdd2: 50                         push       eax
4335fdd3: 898c24400d0000             mov        dword ptr [esp + 0xd40], ecx
4335fdda: 8d460c                     lea        eax, [esi + 0xc]
4335fddd: c78424200d00000000803f     mov        dword ptr [esp + 0xd20], 0x3f800000
4335fde8: 8d8c24d40a0000             lea        ecx, [esp + 0xad4]
4335fdef: 66c784242a0d00000000       mov        word ptr [esp + 0xd2a], 0
4335fdf9: 8b16                       mov        edx, dword ptr [esi]
4335fdfb: 50                         push       eax
4335fdfc: e88dfc0300                 call       0x4339fa8e
4335fe01: 85c0                       test       eax, eax
4335fe03: 0f888efeffff               js         0x4335fc97
4335fe09: f30f1084241c0d0000         movss      xmm0, dword ptr [esp + 0xd1c]
4335fe12: 33c9                       xor        ecx, ecx
4335fe14: 8bc1                       mov        eax, ecx
4335fe16: f30f11442450               movss      dword ptr [esp + 0x50], xmm0
4335fe1c: 8944241c                   mov        dword ptr [esp + 0x1c], eax
4335fe20: 394eec                     cmp        dword ptr [esi - 0x14], ecx
4335fe23: 7677                       jbe        0x4335fe9c
4335fe25: 8bfe                       mov        edi, esi
4335fe27: 0f57c9                     xorps      xmm1, xmm1
4335fe2a: 8b0f                       mov        ecx, dword ptr [edi]
4335fe2c: f30f104130                 movss      xmm0, dword ptr [ecx + 0x30]
4335fe31: 0f2fc1                     comiss     xmm0, xmm1
4335fe34: 7650                       jbe        0x4335fe86
4335fe36: 83790403                   cmp        dword ptr [ecx + 4], 3
4335fe3a: 7406                       je         0x4335fe42
4335fe3c: 83790402                   cmp        dword ptr [ecx + 4], 2
4335fe40: 7544                       jne        0x4335fe86
4335fe42: 8d8424f00c0000             lea        eax, [esp + 0xcf0]
4335fe49: c784241c0d00000000803f     mov        dword ptr [esp + 0xd1c], 0x3f800000
4335fe54: 8b17                       mov        edx, dword ptr [edi]
4335fe56: 8d8c24d00a0000             lea        ecx, [esp + 0xad0]
4335fe5d: 50                         push       eax
4335fe5e: 8d470c                     lea        eax, [edi + 0xc]
4335fe61: 50                         push       eax
4335fe62: e827fc0300                 call       0x4339fa8e
4335fe67: 85c0                       test       eax, eax
4335fe69: 7814                       js         0x4335fe7f
4335fe6b: f30f10442450               movss      xmm0, dword ptr [esp + 0x50]
4335fe71: 0f2f84241c0d0000           comiss     xmm0, dword ptr [esp + 0xd1c]
4335fe79: 0f8718feffff               ja         0x4335fc97
4335fe7f: 8b44241c                   mov        eax, dword ptr [esp + 0x1c]
4335fe83: 0f57c9                     xorps      xmm1, xmm1
4335fe86: 40                         inc        eax
4335fe87: 81c790000000               add        edi, 0x90
4335fe8d: 8944241c                   mov        dword ptr [esp + 0x1c], eax
4335fe91: 3b46ec                     cmp        eax, dword ptr [esi - 0x14]
4335fe94: 7294                       jb         0x4335fe2a
4335fe96: 8b7c2448                   mov        edi, dword ptr [esp + 0x48]
4335fe9a: 33c9                       xor        ecx, ecx
4335fe9c: 47                         inc        edi
4335fe9d: 81c6c00a0000               add        esi, 0xac0
4335fea3: 897c2448                   mov        dword ptr [esp + 0x48], edi
4335fea7: 83ff03                     cmp        edi, 3
4335feaa: 0f8c0bffffff               jl         0x4335fdbb
4335feb0: b201                       mov        dl, 1
4335feb2: 33c9                       xor        ecx, ecx
4335feb4: e9e2fdffff                 jmp        0x4335fc9b
4335feb9: 8b84243c020000             mov        eax, dword ptr [esp + 0x23c]
4335fec0: f30f107c2460               movss      xmm7, dword ptr [esp + 0x60]
4335fec6: f30f118424a0000000         movss      dword ptr [esp + 0xa0], xmm0
4335fecf: f30f10842484000000         movss      xmm0, dword ptr [esp + 0x84]
4335fed8: 0f2ec5                     ucomiss    xmm0, xmm5
4335fedb: 89442468                   mov        dword ptr [esp + 0x68], eax
4335fedf: 9f                         lahf       
4335fee0: f6c444                     test       ah, 0x44
4335fee3: 7a78                       jp         0x4335ff5d
4335fee5: 0f2efd                     ucomiss    xmm7, xmm5
4335fee8: 9f                         lahf       
4335fee9: f6c444                     test       ah, 0x44
4335feec: 7a6f                       jp         0x4335ff5d
4335feee: 0f57c0                     xorps      xmm0, xmm0
4335fef1: f30f11442438               movss      dword ptr [esp + 0x38], xmm0
4335fef7: f30f118424dc000000         movss      dword ptr [esp + 0xdc], xmm0
4335ff00: f30f10842488000000         movss      xmm0, dword ptr [esp + 0x88]
4335ff09: f30f11442458               movss      dword ptr [esp + 0x58], xmm0
4335ff0f: f30f118424e0000000         movss      dword ptr [esp + 0xe0], xmm0
4335ff18: 0f57c0                     xorps      xmm0, xmm0
4335ff1b: f30f11442450               movss      dword ptr [esp + 0x50], xmm0
4335ff21: f30f118424e4000000         movss      dword ptr [esp + 0xe4], xmm0
4335ff2a: f30f10442454               movss      xmm0, dword ptr [esp + 0x54]
4335ff30: 0f5705d0034743             xorps      xmm0, xmmword ptr [0x434703d0] ; [434703d0] f32=-0
4335ff37: f30f11442440               movss      dword ptr [esp + 0x40], xmm0
4335ff3d: f30f11842418010000         movss      dword ptr [esp + 0x118], xmm0
4335ff46: 0f57c0                     xorps      xmm0, xmm0
4335ff49: f30f1144247c               movss      dword ptr [esp + 0x7c], xmm0
4335ff4f: f30f11842420010000         movss      dword ptr [esp + 0x120], xmm0
4335ff58: e95b010000                 jmp        0x433600b8
4335ff5d: f30f10642454               movss      xmm4, dword ptr [esp + 0x54]
4335ff63: 0f28d8                     movaps     xmm3, xmm0
4335ff66: f30f59e5                   mulss      xmm4, xmm5
4335ff6a: 0f28d7                     movaps     xmm2, xmm7
4335ff6d: f30f59dd                   mulss      xmm3, xmm5
4335ff71: f30f5cd4                   subss      xmm2, xmm4
4335ff75: f30f5ce0                   subss      xmm4, xmm0
4335ff79: 0f28c7                     movaps     xmm0, xmm7
4335ff7c: f30f59c5                   mulss      xmm0, xmm5
4335ff80: 0f28ca                     movaps     xmm1, xmm2
4335ff83: f30f5cd8                   subss      xmm3, xmm0
4335ff87: f30f59ca                   mulss      xmm1, xmm2
4335ff8b: 0f28c4                     movaps     xmm0, xmm4
4335ff8e: f30f59c4                   mulss      xmm0, xmm4
4335ff92: f30f58c8                   addss      xmm1, xmm0
4335ff96: 0f28c3                     movaps     xmm0, xmm3
4335ff99: f30f59c3                   mulss      xmm0, xmm3
4335ff9d: f30f58c8                   addss      xmm1, xmm0
4335ffa1: 0f28c1                     movaps     xmm0, xmm1
4335ffa4: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
4335ffac: f30f51c0                   sqrtss     xmm0, xmm0
4335ffb0: f30f11842490030000         movss      dword ptr [esp + 0x390], xmm0
4335ffb9: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
4335ffc1: f30f5ec8                   divss      xmm1, xmm0
4335ffc5: 0f28f1                     movaps     xmm6, xmm1
4335ffc8: 0f28e9                     movaps     xmm5, xmm1
4335ffcb: f30f59cb                   mulss      xmm1, xmm3
4335ffcf: f30f59f4                   mulss      xmm6, xmm4
4335ffd3: 0f28c1                     movaps     xmm0, xmm1
4335ffd6: f30f59ea                   mulss      xmm5, xmm2
4335ffda: f30f59c7                   mulss      xmm0, xmm7
4335ffde: 0f28d9                     movaps     xmm3, xmm1
4335ffe1: 0f28e6                     movaps     xmm4, xmm6
4335ffe4: f30f114c2450               movss      dword ptr [esp + 0x50], xmm1
4335ffea: f30f59642454               mulss      xmm4, dword ptr [esp + 0x54]
4335fff0: 0f28d5                     movaps     xmm2, xmm5
4335fff3: f30f118c24e4000000         movss      dword ptr [esp + 0xe4], xmm1
4335fffc: f30f108c2484000000         movss      xmm1, dword ptr [esp + 0x84]
43360005: f30f5ce0                   subss      xmm4, xmm0
43360009: f30f59d9                   mulss      xmm3, xmm1
4336000d: 0f28c5                     movaps     xmm0, xmm5
43360010: f30f59d7                   mulss      xmm2, xmm7
43360014: f30f59442454               mulss      xmm0, dword ptr [esp + 0x54]
4336001a: f30f116c2438               movss      dword ptr [esp + 0x38], xmm5
43360020: f30f11ac24dc000000         movss      dword ptr [esp + 0xdc], xmm5
43360029: f30f5cd8                   subss      xmm3, xmm0
4336002d: f30f11742458               movss      dword ptr [esp + 0x58], xmm6
43360033: 0f28c6                     movaps     xmm0, xmm6
43360036: f30f11b424e0000000         movss      dword ptr [esp + 0xe0], xmm6
4336003f: f30f59c1                   mulss      xmm0, xmm1
43360043: 0f28cc                     movaps     xmm1, xmm4
43360046: f30f59cc                   mulss      xmm1, xmm4
4336004a: f30f5cd0                   subss      xmm2, xmm0
4336004e: 0f28c3                     movaps     xmm0, xmm3
43360051: f30f59c3                   mulss      xmm0, xmm3
43360055: f30f58c8                   addss      xmm1, xmm0
43360059: 0f28c2                     movaps     xmm0, xmm2
4336005c: f30f59c2                   mulss      xmm0, xmm2
43360060: f30f58c8                   addss      xmm1, xmm0
43360064: 0f28c1                     movaps     xmm0, xmm1
43360067: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
4336006f: f30f51c0                   sqrtss     xmm0, xmm0
43360073: f30f1184247c060000         movss      dword ptr [esp + 0x67c], xmm0
4336007c: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
43360084: f30f5ec8                   divss      xmm1, xmm0
43360088: 0f28c1                     movaps     xmm0, xmm1
4336008b: f30f59c4                   mulss      xmm0, xmm4
4336008f: f30f11442440               movss      dword ptr [esp + 0x40], xmm0
43360095: f30f11842418010000         movss      dword ptr [esp + 0x118], xmm0
4336009e: 0f28c1                     movaps     xmm0, xmm1
433600a1: f30f59ca                   mulss      xmm1, xmm2
433600a5: f30f59c3                   mulss      xmm0, xmm3
433600a9: f30f114c247c               movss      dword ptr [esp + 0x7c], xmm1
433600af: f30f118c2420010000         movss      dword ptr [esp + 0x120], xmm1
433600b8: 8b8c2490000000             mov        ecx, dword ptr [esp + 0x90]
433600bf: 8364241c00                 and        dword ptr [esp + 0x1c], 0
433600c4: 83c108                     add        ecx, 8
433600c7: f30f1184241c010000         movss      dword ptr [esp + 0x11c], xmm0
433600d0: f30f11442448               movss      dword ptr [esp + 0x48], xmm0
433600d6: 8b01                       mov        eax, dword ptr [ecx]
433600d8: ff5028                     call       dword ptr [eax + 0x28]
433600db: 85c0                       test       eax, eax
433600dd: 750c                       jne        0x433600eb
433600df: 9e                         sahf       
433600e0: b8e77ea2b1                 mov        eax, 0xb1a27ee7
433600e5: cb                         retf       
433600eb: 8bc8                       mov        ecx, eax
433600ed: e839890500                 call       0x433b8a2b
433600f2: 8b842480000000             mov        eax, dword ptr [esp + 0x80]
433600f9: 051c110000                 add        eax, 0x111c
433600fe: c784248c00000020000000     mov        dword ptr [esp + 0x8c], 0x20
43360109: 89442464                   mov        dword ptr [esp + 0x64], eax
4336010d: f30f1038                   movss      xmm7, dword ptr [eax]
43360111: 33c9                       xor        ecx, ecx
43360113: f30f104804                 movss      xmm1, dword ptr [eax + 4]
43360118: 0f28df                     movaps     xmm3, xmm7
4336011b: f30f595c2438               mulss      xmm3, dword ptr [esp + 0x38]
43360121: 0f28c1                     movaps     xmm0, xmm1
43360124: 8b442434                   mov        eax, dword ptr [esp + 0x34]
43360128: f30f59442440               mulss      xmm0, dword ptr [esp + 0x40]
4336012e: 0f28f7                     movaps     xmm6, xmm7
43360131: f30f589c2484000000         addss      xmm3, dword ptr [esp + 0x84]
4336013a: f30f59742458               mulss      xmm6, dword ptr [esp + 0x58]
43360140: f30f597c2450               mulss      xmm7, dword ptr [esp + 0x50]
43360146: f30f58742460               addss      xmm6, dword ptr [esp + 0x60]
4336014c: f30f58d8                   addss      xmm3, xmm0
43360150: f30f10ac24a0000000         movss      xmm5, dword ptr [esp + 0xa0]
43360159: f30f587c2454               addss      xmm7, dword ptr [esp + 0x54]
4336015f: 0f28c1                     movaps     xmm0, xmm1
43360162: f30f594c247c               mulss      xmm1, dword ptr [esp + 0x7c]
43360168: f30f59442448               mulss      xmm0, dword ptr [esp + 0x48]
4336016e: f30f58f9                   addss      xmm7, xmm1
43360172: 0f28cb                     movaps     xmm1, xmm3
43360175: f30f59cb                   mulss      xmm1, xmm3
43360179: f30f58f0                   addss      xmm6, xmm0
4336017d: 0f28c6                     movaps     xmm0, xmm6
43360180: f30f59c6                   mulss      xmm0, xmm6
43360184: f30f58c8                   addss      xmm1, xmm0
43360188: 0f28c7                     movaps     xmm0, xmm7
4336018b: f30f59c7                   mulss      xmm0, xmm7
4336018f: f30f58c8                   addss      xmm1, xmm0
43360193: 0f28c1                     movaps     xmm0, xmm1
43360196: f30f100d14054743           movss      xmm1, dword ptr [0x43470514] ; [43470514] f32=1
4336019e: f30f51c0                   sqrtss     xmm0, xmm0
433601a2: f30f11842464030000         movss      dword ptr [esp + 0x364], xmm0
433601ab: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
433601b3: f30f5ec8                   divss      xmm1, xmm0
433601b7: 0f28d1                     movaps     xmm2, xmm1
433601ba: f30f59f1                   mulss      xmm6, xmm1
433601be: f30f59d3                   mulss      xmm2, xmm3
433601c2: f30f59f9                   mulss      xmm7, xmm1
433601c6: 0f28c6                     movaps     xmm0, xmm6
433601c9: f30f59c6                   mulss      xmm0, xmm6
433601cd: 0f28ca                     movaps     xmm1, xmm2
433601d0: f30f59ca                   mulss      xmm1, xmm2
433601d4: f30f58c8                   addss      xmm1, xmm0
433601d8: 0f28c7                     movaps     xmm0, xmm7
433601db: f30f59c7                   mulss      xmm0, xmm7
433601df: f30f58c8                   addss      xmm1, xmm0
433601e3: 0f28c1                     movaps     xmm0, xmm1
433601e6: f30f104804                 movss      xmm1, dword ptr [eax + 4]
433601eb: f30f51c0                   sqrtss     xmm0, xmm0
433601ef: f30f11842468030000         movss      dword ptr [esp + 0x368], xmm0
433601f8: f30f580508214743           addss      xmm0, dword ptr [0x43472108] ; [43472108] f32=1.1920929e-07
43360200: f30f5ee8                   divss      xmm5, xmm0
43360204: f30f1000                   movss      xmm0, dword ptr [eax]
43360208: 0f28dd                     movaps     xmm3, xmm5
4336020b: 0f28e5                     movaps     xmm4, xmm5
4336020e: f30f59e6                   mulss      xmm4, xmm6
43360212: f30f59da                   mulss      xmm3, xmm2
43360216: f30f105008                 movss      xmm2, dword ptr [eax + 8]
4336021b: f30f11a42454040000         movss      dword ptr [esp + 0x454], xmm4
43360224: f30f59ef                   mulss      xmm5, xmm7
43360228: 898c2480040000             mov        dword ptr [esp + 0x480], ecx
4336022f: f30f119c2450040000         movss      dword ptr [esp + 0x450], xmm3
43360238: f30f59e4                   mulss      xmm4, xmm4
4336023c: c684248404000001           mov        byte ptr [esp + 0x484], 1
43360244: f30f59db                   mulss      xmm3, xmm3
43360248: c684248504000001           mov        byte ptr [esp + 0x485], 1
43360250: f30f11ac2458040000         movss      dword ptr [esp + 0x458], xmm5
43360259: f30f59ed                   mulss      xmm5, xmm5
4336025d: f30f58e3                   addss      xmm4, xmm3
43360261: f30f118c2444040000         movss      dword ptr [esp + 0x444], xmm1
4336026a: 0f57c9                     xorps      xmm1, xmm1
4336026d: f30f11842440040000         movss      dword ptr [esp + 0x440], xmm0
43360276: 0f57c0                     xorps      xmm0, xmm0
43360279: f30f11942448040000         movss      dword ptr [esp + 0x448], xmm2
43360282: 0f29842460040000           movaps     xmmword ptr [esp + 0x460], xmm0
4336028a: 0f29842470040000           movaps     xmmword ptr [esp + 0x470], xmm0
43360292: f30f58e5                   addss      xmm4, xmm5
43360296: 0f2ee1                     ucomiss    xmm4, xmm1
43360299: 9f                         lahf       
4336029a: f6c444                     test       ah, 0x44
4336029d: 7a07                       jp         0x433602a6
4336029f: 888c2485040000             mov        byte ptr [esp + 0x485], cl
433602a6: f30f101514054743           movss      xmm2, dword ptr [0x43470514] ; [43470514] f32=1
433602ae: 8bd1                       mov        edx, ecx
433602b0: 838c241c0a0000ff           or         dword ptr [esp + 0xa1c], 0xffffffff
433602b8: 8bc1                       mov        eax, ecx
433602ba: 838c24280a0000ff           or         dword ptr [esp + 0xa28], 0xffffffff
433602c2: c78424a4000000ffffff7f     mov        dword ptr [esp + 0xa4], 0x7fffffff
433602cd: 8bbc24a4000000             mov        edi, dword ptr [esp + 0xa4]
433602d4: c78424040a00000000803f     mov        dword ptr [esp + 0xa04], 0x3f800000
433602df: 66898c240e0a0000           mov        word ptr [esp + 0xa0e], cx
433602e7: 898c24240a0000             mov        dword ptr [esp + 0xa24], ecx
433602ee: f30f11542418               movss      dword ptr [esp + 0x18], xmm2
433602f4: 8954242c                   mov        dword ptr [esp + 0x2c], edx
433602f8: 89442478                   mov        dword ptr [esp + 0x78], eax
433602fc: 8b80b0494743               mov        eax, dword ptr [eax + 0x434749b0]
43360302: 3b8424e01c0000             cmp        eax, dword ptr [esp + 0x1ce0]
43360309: 0f83c0000000               jae        0x433603cf
4336030f: 69c090000000               imul       eax, eax, 0x90
43360315: 8d8c24f01c0000             lea        ecx, [esp + 0x1cf0]
4336031c: 03c8                       add        ecx, eax
4336031e: 898c24a4000000             mov        dword ptr [esp + 0xa4], ecx
43360325: 8d7140                     lea        esi, [ecx + 0x40]
43360328: 8b4604                     mov        eax, dword ptr [esi + 4]
4336032b: 83e00f                     and        eax, 0xf
4336032e: 393c8570494743             cmp        dword ptr [eax*4 + 0x43474970], edi
43360335: 0f8794000000               ja         0x433603cf
4336033b: c78424040a00000000803f     mov        dword ptr [esp + 0xa04], 0x3f800000
43360346: 8d8424d8090000             lea        eax, [esp + 0x9d8]
4336034d: f30f104630                 movss      xmm0, dword ptr [esi + 0x30]
43360352: 0f2fc1                     comiss     xmm0, xmm1
43360355: 50                         push       eax
43360356: 7610                       jbe        0x43360368
43360358: 8bd6                       mov        edx, esi
4336035a: 8d8c2444040000             lea        ecx, [esp + 0x444]
43360361: e8a38a0900                 call       0x433f8e09
43360366: eb13                       jmp        0x4336037b
43360368: 8b5104                     mov        edx, dword ptr [ecx + 4]
4336036b: 8d4110                     lea        eax, [ecx + 0x10]
4336036e: 50                         push       eax
4336036f: 8d8c2448040000             lea        ecx, [esp + 0x448]
43360376: e813f70300                 call       0x4339fa8e
4336037b: f30f10542418               movss      xmm2, dword ptr [esp + 0x18]
43360381: 85c0                       test       eax, eax
43360383: 782f                       js         0x433603b4
43360385: 0f2f9424040a0000           comiss     xmm2, dword ptr [esp + 0xa04]
4336038d: 7625                       jbe        0x433603b4
4336038f: 837e0401                   cmp        dword ptr [esi + 4], 1
43360393: f30f109424040a0000         movss      xmm2, dword ptr [esp + 0xa04]
4336039c: 8b9424a4000000             mov        edx, dword ptr [esp + 0xa4]
433603a3: f30f11542418               movss      dword ptr [esp + 0x18], xmm2
433603a9: 8954242c                   mov        dword ptr [esp + 0x2c], edx
433603ad: 7520                       jne        0x433603cf
433603af: 6a02                       push       2
433603b1: 5f                         pop        edi
433603b2: eb04                       jmp        0x433603b8
433603b4: 8b54242c                   mov        edx, dword ptr [esp + 0x2c]
433603b8: 8b442478                   mov        eax, dword ptr [esp + 0x78]
433603bc: 0f57c9                     xorps      xmm1, xmm1
433603bf: 83c004                     add        eax, 4
433603c2: 89442478                   mov        dword ptr [esp + 0x78], eax
433603c6: 83f83c                     cmp        eax, 0x3c
433603c9: 0f822dffffff               jb         0x433602fc
433603cf: 85d2                       test       edx, edx
433603d1: 0f84a0000000               je         0x43360477
433603d7: f30f10842450040000         movss      xmm0, dword ptr [esp + 0x450]
433603e0: 8b4a44                     mov        ecx, dword ptr [edx + 0x44]
433603e3: f30f59c2                   mulss      xmm0, xmm2
433603e7: 898c241c0a0000             mov        dword ptr [esp + 0xa1c], ecx
433603ee: 8b02                       mov        eax, dword ptr [edx]
433603f0: 898424280a0000             mov        dword ptr [esp + 0xa28], eax
433603f7: f30f58842440040000         addss      xmm0, dword ptr [esp + 0x440]
43360400: 8b4508                     mov        eax, dword ptr [ebp + 8]
43360403: f30f118424e4090000         movss      dword ptr [esp + 0x9e4], xmm0
4336040c: f30f10842454040000         movss      xmm0, dword ptr [esp + 0x454]
43360415: f30f59c2                   mulss      xmm0, xmm2
43360419: f30f58842444040000         addss      xmm0, dword ptr [esp + 0x444]
43360422: f30f118424e8090000         movss      dword ptr [esp + 0x9e8], xmm0
4336042b: f30f10842458040000         movss      xmm0, dword ptr [esp + 0x458]
43360434: f30f59c2                   mulss      xmm0, xmm2
43360438: f30f58842448040000         addss      xmm0, dword ptr [esp + 0x448]
43360441: f30f118424ec090000         movss      dword ptr [esp + 0x9ec], xmm0
4336044a: 83b89c01000001             cmp        dword ptr [eax + 0x19c], 1
43360451: 7f19                       jg         0x4336046c
43360453: 394c2468                   cmp        dword ptr [esp + 0x68], ecx
43360457: 7413                       je         0x4336046c
43360459: 83e10f                     and        ecx, 0xf
4336045c: f30f10048d40454743         movss      xmm0, dword ptr [ecx*4 + 0x43474540]
43360465: 0f2f442420                 comiss     xmm0, dword ptr [esp + 0x20]
4336046a: 720b                       jb         0x43360477
4336046c: 8b74241c                   mov        esi, dword ptr [esp + 0x1c]
43360470: 46                         inc        esi
43360471: 8974241c                   mov        dword ptr [esp + 0x1c], esi
43360475: eb04                       jmp        0x4336047b
43360477: 8b74241c                   mov        esi, dword ptr [esp + 0x1c]
4336047b: 8b442464                   mov        eax, dword ptr [esp + 0x64]
4336047f: 83c020                     add        eax, 0x20
43360482: 83ac248c00000001           sub        dword ptr [esp + 0x8c], 1
4336048a: 89442464                   mov        dword ptr [esp + 0x64], eax
4336048e: 0f8579fcffff               jne        0x4336010d
43360494: 660f6ec6                   movd       xmm0, esi
43360498: 8b7c245c                   mov        edi, dword ptr [esp + 0x5c]
4336049c: 0f5bc0                     cvtdq2ps   xmm0, xmm0
4336049f: f30f590528f64643           mulss      xmm0, dword ptr [0x4346f628] ; [4346f628] f32=0.03125
433604a7: f30f114738                 movss      dword ptr [edi + 0x38], xmm0
433604ac: 8bb42464010000             mov        esi, dword ptr [esp + 0x164]
433604b3: 8b4708                     mov        eax, dword ptr [edi + 8]
433604b6: f30f108c2474010000         movss      xmm1, dword ptr [esp + 0x174]
433604bf: f30f590da0044743           mulss      xmm1, dword ptr [0x434704a0] ; [434704a0] f32=100
433604c7: 89442468                   mov        dword ptr [esp + 0x68], eax
433604cb: 83c005                     add        eax, 5
433604ce: 6a7f                       push       0x7f
433604d0: 5a                         pop        edx
433604d1: 3bc2                       cmp        eax, edx
433604d3: 8bca                       mov        ecx, edx
433604d5: 8bd6                       mov        edx, esi
433604d7: 0f42c8                     cmovb      ecx, eax
433604da: 8b842470010000             mov        eax, dword ptr [esp + 0x170]
433604e1: 3bce                       cmp        ecx, esi
433604e3: 89442420                   mov        dword ptr [esp + 0x20], eax
433604e7: 6a7f                       push       0x7f
433604e9: 0f42d1                     cmovb      edx, ecx
433604ec: 83e27f                     and        edx, 0x7f
433604ef: 8bca                       mov        ecx, edx
433604f1: 81c980000000               or         ecx, 0x80
433604f7: 2402                       and        al, 2
433604f9: f30f2dc1                   cvtss2si   eax, xmm1
433604fd: 0f45ca                     cmovne     ecx, edx
43360500: 5a                         pop        edx
43360501: 85c0                       test       eax, eax
43360503: 7904                       jns        0x43360509
43360505: 33c0                       xor        eax, eax
43360507: eb05                       jmp        0x4336050e
43360509: 3bc2                       cmp        eax, edx
4336050b: 0f4fc2                     cmovg      eax, edx
4336050e: 23c2                       and        eax, edx
43360510: c78424a00100000f000000     mov        dword ptr [esp + 0x1a0], 0xf
4336051b: c1e008                     shl        eax, 8
4336051e: 0bc1                       or         eax, ecx
43360520: 33c9                       xor        ecx, ecx
43360522: 41                         inc        ecx
43360523: 8bd0                       mov        edx, eax
43360525: 204c2420                   and        byte ptr [esp + 0x20], cl
43360529: 81ca00800000               or         edx, 0x8000
4336052f: 807c242000                 cmp        byte ptr [esp + 0x20], 0
43360534: 0f44d0                     cmove      edx, eax
43360537: 83a4248401000000           and        dword ptr [esp + 0x184], 0
4336053f: 899424a0000000             mov        dword ptr [esp + 0xa0], edx
43360546: 85f6                       test       esi, esi
43360548: 7f07                       jg         0x43360551
4336054a: baffffff7f                 mov        edx, 0x7fffffff
4336054f: eb11                       jmp        0x43360562
43360551: 8b442468                   mov        eax, dword ptr [esp + 0x68]
43360555: 48                         dec        eax
43360556: 03c6                       add        eax, esi
43360558: 99                         cdq        
43360559: f7fe                       idiv       esi
4336055b: 8bd1                       mov        edx, ecx
4336055d: 3bc1                       cmp        eax, ecx
4336055f: 0f4fd0                     cmovg      edx, eax
43360562: 6a0f                       push       0xf
43360564: 58                         pop        eax
43360565: ff742430                   push       dword ptr [esp + 0x30]
43360569: 2bc2                       sub        eax, edx
4336056b: 8d8c2490010000             lea        ecx, [esp + 0x190]
43360572: 89842490010000             mov        dword ptr [esp + 0x190], eax
43360579: 8d942488010000             lea        edx, [esp + 0x188]
43360580: 8d8424a4010000             lea        eax, [esp + 0x1a4]
43360587: 50                         push       eax
43360588: e833e60100                 call       0x4337ebc0
4336058d: 8b94246c010000             mov        edx, dword ptr [esp + 0x16c]
43360594: 8b00                       mov        eax, dword ptr [eax]
43360596: 83e00f                     and        eax, 0xf
43360599: c1e010                     shl        eax, 0x10
4336059c: 0b8424a0000000             or         eax, dword ptr [esp + 0xa0]
433605a3: 80bfdd00000000             cmp        byte ptr [edi + 0xdd], 0
433605aa: 740f                       je         0x433605bb
433605ac: 83fa02                     cmp        edx, 2
433605af: 7405                       je         0x433605b6
433605b1: 83fa03                     cmp        edx, 3
433605b4: 7505                       jne        0x433605bb
433605b6: 0d00001000                 or         eax, 0x100000
433605bb: f30f10842474010000         movss      xmm0, dword ptr [esp + 0x174]
433605c4: 0f2f87d4000000             comiss     xmm0, dword ptr [edi + 0xd4]
433605cb: 7205                       jb         0x433605d2
433605cd: 0d00002000                 or         eax, 0x200000
433605d2: 8b8c2464010000             mov        ecx, dword ptr [esp + 0x164]
433605d9: 3b8fd0000000               cmp        ecx, dword ptr [edi + 0xd0]
433605df: 7c05                       jl         0x433605e6
433605e1: 0d00004000                 or         eax, 0x400000
433605e6: 8984247c010000             mov        dword ptr [esp + 0x17c], eax
433605ed: eb1b                       jmp        0x4336060a
433605ef: 8b7c245c                   mov        edi, dword ptr [esp + 0x5c]
433605f3: f30f10842474010000         movss      xmm0, dword ptr [esp + 0x174]
433605fc: 8b94246c010000             mov        edx, dword ptr [esp + 0x16c]
43360603: 8b8c2464010000             mov        ecx, dword ptr [esp + 0x164]
4336060a: 8b742444                   mov        esi, dword ptr [esp + 0x44]
4336060e: f6461402                   test       byte ptr [esi + 0x14], 2
43360612: 750a                       jne        0x4336061e
43360614: 8974244c                   mov        dword ptr [esp + 0x4c], esi
43360618: 894c2424                   mov        dword ptr [esp + 0x24], ecx
4336061c: eb04                       jmp        0x43360622
4336061e: 8b74244c                   mov        esi, dword ptr [esp + 0x4c]
43360622: 85c9                       test       ecx, ecx
43360624: 0f84b8000000               je         0x433606e2
4336062a: 3b8fd0000000               cmp        ecx, dword ptr [edi + 0xd0]
43360630: 0f8ca1000000               jl         0x433606d7
43360636: 0f2f87d4000000             comiss     xmm0, dword ptr [edi + 0xd4]
4336063d: 727c                       jb         0x433606bb
4336063f: 80bfdd00000000             cmp        byte ptr [edi + 0xdd], 0
43360646: 742d                       je         0x43360675
43360648: 8b442428                   mov        eax, dword ptr [esp + 0x28]
4336064c: a900001000                 test       eax, 0x100000
43360651: 7422                       je         0x43360675
43360653: 33c9                       xor        ecx, ecx
43360655: 41                         inc        ecx
43360656: 3bd1                       cmp        edx, ecx
43360658: 751b                       jne        0x43360675
4336065a: 848c2470010000             test       byte ptr [esp + 0x170], cl
43360661: 7412                       je         0x43360675
43360663: f687b800000008             test       byte ptr [edi + 0xb8], 8
4336066a: 7409                       je         0x43360675
4336066c: 25ffffefff                 and        eax, 0xffefffff
43360671: 89442428                   mov        dword ptr [esp + 0x28], eax
43360675: 8b4c2444                   mov        ecx, dword ptr [esp + 0x44]
43360679: 8dbc2454010000             lea        edi, [esp + 0x154]
43360680: 8b442424                   mov        eax, dword ptr [esp + 0x24]
43360684: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
43360685: 6a0e                       push       0xe
43360687: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
43360688: a5                         movsd      dword ptr es:[edi], dword ptr [esi]
43360689: 8bbc24e8470000             mov        edi, dword ptr [esp + 0x47e8]
43360690: 8db4244c010000             lea        esi, [esp + 0x14c]
43360697: 89842464010000             mov        dword ptr [esp + 0x164], eax
4336069e: f30f10410c                 movss      xmm0, dword ptr [ecx + 0xc]
433606a3: 59                         pop        ecx
433606a4: 8d4738                     lea        eax, [edi + 0x38]
433606a7: f30f11842478010000         movss      dword ptr [esp + 0x178], xmm0
433606b0: 898424e4470000             mov        dword ptr [esp + 0x47e4], eax
433606b7: f3a5                       rep movsd  dword ptr es:[edi], dword ptr [esi]
433606b9: eb27                       jmp        0x433606e2
433606bb: 8b8c2480000000             mov        ecx, dword ptr [esp + 0x80]
433606c2: 8b8178010000               mov        eax, dword ptr [ecx + 0x178]
433606c8: a809                       test       al, 9
433606ca: 750b                       jne        0x433606d7
433606cc: 0d00010000                 or         eax, 0x100
433606d1: 898178010000               mov        dword ptr [ecx + 0x178], eax
433606d7: 818c247001000080000000     or         dword ptr [esp + 0x170], 0x80
433606e2: 8b842454120000             mov        eax, dword ptr [esp + 0x1254]
433606e9: 2b842450120000             sub        eax, dword ptr [esp + 0x1250]
433606f0: 6a18                       push       0x18
433606f2: 5e                         pop        esi
433606f3: 99                         cdq        
433606f4: f7fe                       idiv       esi
433606f6: 8b4c2414                   mov        ecx, dword ptr [esp + 0x14]
433606fa: 8b742434                   mov        esi, dword ptr [esp + 0x34]
433606fe: 41                         inc        ecx
433606ff: 8b5518                     mov        edx, dword ptr [ebp + 0x18]
43360702: 894c2414                   mov        dword ptr [esp + 0x14], ecx
43360706: 3bc8                       cmp        ecx, eax
43360708: 0f8254e8ffff               jb         0x4335ef62
4336070e: 8b4c2428                   mov        ecx, dword ptr [esp + 0x28]
43360712: 33f6                       xor        esi, esi

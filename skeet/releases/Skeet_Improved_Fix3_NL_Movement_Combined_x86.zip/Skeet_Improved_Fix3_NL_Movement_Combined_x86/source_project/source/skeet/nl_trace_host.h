#pragma once
#include "nl_prediction.h"
#ifdef _WIN32
#include <windows.h>
#include <cstring>
#include <cstddef>
namespace nl_trace_host {
using nl_prediction::Vec;
struct alignas(16) Aligned {float x,y,z,w;};
struct alignas(16) Ray {
    Aligned start,delta,start_offset,extents;
    const void* transform;bool is_ray,is_swept;
};
struct Plane {Vec normal;float distance;unsigned char type,signbits,pad[2];};
struct Surface {const char* name;short props;unsigned short flags;};
struct Result {
    Vec start,end;Plane plane;float fraction;int contents;
    unsigned short disp_flags;bool allsolid,startsolid;
    float fraction_leftsolid;Surface surface;int hitgroup;
    short physicsbone;unsigned short worldsurface;void* entity;int hitbox;
};
static_assert(sizeof(Ray)==80&&offsetof(Ray,transform)==64);
static_assert(sizeof(Result)==84&&offsetof(Result,fraction)==44&&offsetof(Result,entity)==76);
struct Filter {void** table;void* skip;};
inline bool __fastcall should_hit(Filter* self,void*,void* entity,int){return entity!=self->skip;}
inline int __fastcall trace_type(Filter*,void*){return 0;}
using Factory=void*(__cdecl*)(const char*,int*);
using GetEntity=void*(__thiscall*)(void*,int);
using TraceRay=void(__thiscall*)(void*,const Ray&,unsigned,void*,Result*);
class Host {
    void* engine=nullptr;void* entity_list=nullptr;void* skip=nullptr;
public:
    bool initialize(unsigned index) {
        if(index<1||index>64)return false;
        auto* e=GetModuleHandleW(L"engine.dll");auto* c=GetModuleHandleW(L"client.dll");
        if(!e||!c)return false;
        auto ef=reinterpret_cast<Factory>(GetProcAddress(e,"CreateInterface"));
        auto cf=reinterpret_cast<Factory>(GetProcAddress(c,"CreateInterface"));
        if(!ef||!cf)return false;
        engine=ef("EngineTraceClient004",nullptr);entity_list=cf("VClientEntityList003",nullptr);
        if(!engine||!entity_list)return false;
        auto** table=*reinterpret_cast<void***>(entity_list);
        skip=reinterpret_cast<GetEntity>(table[3])(entity_list,int(index));
        return skip!=nullptr;
    }
    bool operator()(Vec a,Vec b,Vec mins,Vec maxs,nl_prediction::Trace& out) {
        if(!engine||!skip)return false;
        const Vec delta=b-a,center=(mins+maxs)*.5f,extents=(maxs-mins)*.5f;
        Ray ray{};
        ray.start={a.x+center.x,a.y+center.y,a.z+center.z,0};
        ray.delta={delta.x,delta.y,delta.z,0};
        ray.start_offset={-center.x,-center.y,-center.z,0};
        ray.extents={extents.x,extents.y,extents.z,0};
        ray.is_ray=extents.x*extents.x+extents.y*extents.y+extents.z*extents.z<1.e-6f;
        ray.is_swept=delta.x*delta.x+delta.y*delta.y+delta.z*delta.z!=0;
        void* filter_table[]={reinterpret_cast<void*>(&should_hit),reinterpret_cast<void*>(&trace_type)};
        Filter filter{filter_table,skip};Result result{};result.fraction=1;
        auto** table=*reinterpret_cast<void***>(engine);
        reinterpret_cast<TraceRay>(table[5])(engine,ray,0x201400bU,&filter,&result);
        out={result.fraction,result.end,result.plane.normal,result.allsolid,result.startsolid};
        return true;
    }
};
}
#endif

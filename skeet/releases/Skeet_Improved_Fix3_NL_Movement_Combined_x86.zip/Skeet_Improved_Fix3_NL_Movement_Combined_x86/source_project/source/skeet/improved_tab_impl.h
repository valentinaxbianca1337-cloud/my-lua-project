#pragma once
#include "native_menu_shape.h"
#include "native_layout_state.h"
#include "improved_tab_layout.h"
#include "improved_brush_icon.h"
#include "improved_status.h"

namespace improved_tab {
using namespace SkeetSDK;
using TabCtor=void*(__thiscall*)(void*,void*,const wchar_t*,int*);
using ChildCtor=void*(__thiscall*)(void*,void*,const wchar_t*,int,int,bool);
using AppendChild=void(__thiscall*)(void*,void*);
using Draw=void(__thiscall*)(CTab*,IRenderer*,const Vec2*);
using Hover=bool(__thiscall*)(CTab*,const Vec2&);
using Event=void(__thiscall*)(CTab*);
using ChildDraw=void(__thiscall*)(Child*,IRenderer*,const Vec2*);
struct Binding {CTab* tab=nullptr;unsigned slots=0;void* original[32]{};void* table[32]{};};
struct State {
    CMenu* menu=nullptr;CTab* custom=nullptr;Child* children[3]{};
    void* child_original[3][13]{};void* child_tables[3][13]{};
    Binding bindings[32]{};unsigned bindings_count=0;
    CTab* display_order[32]{};unsigned display_count=0;
    float left=0,top=0,width=75,base_min_height=0;
    int last_min_height=0;bool attempted=false,laying_out=false;
};
static State* histories[16]{};
static unsigned histories_count=0;
static State* current_state=nullptr;
static State empty_state{};
static State& state(){return current_state?*current_state:empty_state;}
static native_ui_proxy::Api api{};
static TabCtor tab_ctor=nullptr;
static ChildCtor child_ctor=nullptr;
static AppendChild append_child=nullptr;
static float dpi() {
    const float value=*reinterpret_cast<const float*>(0x4346d490);
    return value>=.5f&&value<=3.f?value:1.f;
}
static Binding* find(CTab* tab) {
    for(unsigned i=0;i<state().bindings_count;i++)if(state().bindings[i].tab==tab)return &state().bindings[i];
    return nullptr;
}
static unsigned table_slots(void** table) {
    // Full derived native tables, not just the fifteen common ITab methods.
    // Leave foreign object-local vtables untouched (e.g. afterglow Lua tabs).
    switch(reinterpret_cast<std::uintptr_t>(table)) {
        case 0x4346ed5c:case 0x4346f6dc:case 0x43470684:
        case 0x434706c8:case 0x43471fcc:return 15;
        case 0x4346f9c8:return 24;
        case 0x43470094:return 31;
        default:return 0;
    }
}
static bool live() {
    if(!native_menu_shape::tabbed(state().menu)||!state().custom)return false;
    unsigned index=0;
    while(index<state().menu->Tabs.size()&&state().menu->Tabs[index]!=state().custom)++index;
    if(index<9||index==state().menu->Tabs.size())return false;
    auto* b=find(state().custom);
    return b&&*reinterpret_cast<void***>(state().custom)==b->table&&state().custom->Header.Index==int(index);
}
static void capture_order() {
    auto* menu=state().menu;
    auto& n=state().display_count;unsigned kept=0;
    const bool initial=n==0;
    for(unsigned i=0;i<n;i++) {
        auto* tab=state().display_order[i];
        if(tab!=state().custom&&std::find(menu->Tabs.begin(),menu->Tabs.end(),tab)!=menu->Tabs.end())
            state().display_order[kept++]=tab;
    }
    n=kept;
    for(auto* tab:menu->Tabs)if(tab!=state().custom&&
       std::find(state().display_order,state().display_order+n,tab)==state().display_order+n)
        state().display_order[n++]=tab;
    if(initial)std::sort(state().display_order,state().display_order+n,[](CTab* a,CTab* b){
        return a->Pos.y!=b->Pos.y?a->Pos.y<b->Pos.y:a->Header.Index<b->Header.Index;
    });
    // Rage is a semantic lookup, not an assumption about the other ordinals.
    auto* rage=menu->TabsArr[0]?menu->TabsArr[0]:menu->Tabs[0];
    for(unsigned i=0;i<n;i++)if(state().display_order[i]==rage) {
        for(;i>0;--i)state().display_order[i]=state().display_order[i-1];
        state().display_order[0]=rage;break;
    }
}
static int child_index(Child* child) {
    for(int i=0;i<3;i++)if(state().children[i]==child)return i;
    return -1;
}
static improved_layout::Plan plan() {
    if(!live())return {};
    const float scale=dpi();int tallest=improved_layout::px(36*scale);
    for(auto* tab:state().menu->Tabs)if(tab&&tab!=state().custom&&tab->Icon.TextureId>=0)
        tallest=std::max(tallest,tab->Icon.Size.y);
    capture_order();int rows[32]{};
    for(unsigned i=0;i<state().menu->Tabs.size();i++) {
        auto* tab=state().menu->Tabs[i];
        if(tab==state().custom){rows[i]=1;continue;}
        unsigned j=0;while(j<state().display_count&&state().display_order[j]!=tab)++j;
        rows[i]=j==0?0:int(j+1);
    }
    return improved_layout::calculate(state().menu->Size.x,state().menu->Size.y,scale,
        int(state().menu->Tabs.size()),state().custom->Header.Index,
        improved_layout::px(state().left*scale),improved_layout::px(state().top*scale),
        improved_layout::px(state().width*scale),tallest,rows);
}
static void geometry(bool grow=false) {
    if(state().laying_out||!live())return;
    state().laying_out=true;
    auto p=plan();auto* menu=state().menu;const float scale=dpi();
    if(grow) {
        if(state().last_min_height&&menu->MinSize.y!=state().last_min_height)
            state().base_min_height=menu->MinSize.y/scale;
        menu->MinSize.y=std::max(improved_layout::px(state().base_min_height*scale),p.minimum_height);
        state().last_min_height=menu->MinSize.y;
        if(menu->Size.y<menu->MinSize.y) {
            menu->Size.y=menu->MinSize.y;
            // Notify every native child through its existing resize implementation.
            for(auto* tab:menu->Tabs)if(auto* b=find(tab))
                reinterpret_cast<Event>(b->original[9])(tab);
            p=plan();
        }
    }
    if(p.valid) {
        for(unsigned i=0;i<menu->Tabs.size();i++) {
            auto* tab=menu->Tabs[i];if(!tab)continue;
            const auto r=p.slots[i];tab->Pos={r.x,r.y};
            native_layout_state::size(tab,r.w,r.h,scale);
            // Pixel->DPI inversion is ambiguous at fractional scales. Keep the
            // canonical sidebar width rather than accumulating rounded pixels.
            tab->DefSize.x=improved_layout::px(state().width);
        }
        for(int i=0;i<3;i++)if(state().children[i]) {
            const auto r=p.panels[i];
            native_layout_state::fixed(state().children[i],r.x,r.y,r.w,r.h,scale);
        }
    }
    state().laying_out=false;
}
static bool __fastcall hovered(CTab* tab,void*,const Vec2& cursor) {
    auto* b=find(tab);if(!b)return false;geometry();
    return reinterpret_cast<Hover>(b->original[1])(tab,cursor);
}
static void __fastcall resized(CTab* tab,void*) {
    auto* b=find(tab);if(!b)return;
    reinterpret_cast<Event>(b->original[9])(tab);geometry();
}
static void __fastcall scaled(CTab* tab,void*) {
    auto* b=find(tab);if(!b)return;
    reinterpret_cast<Event>(b->original[10])(tab);geometry();
}
using ChildEvent=void(__thiscall*)(Child*);
static void __fastcall child_layout(Child* child,void*) {
    const int i=child_index(child);if(i<0)return;
    reinterpret_cast<ChildEvent>(state().child_original[i][8])(child);geometry();
}
static void __fastcall child_resize(Child* child,void*) {
    const int i=child_index(child);if(i<0)return;
    reinterpret_cast<ChildEvent>(state().child_original[i][9])(child);geometry();
}
static void __fastcall child_dpi(Child* child,void*) {
    const int i=child_index(child);if(i<0)return;
    reinterpret_cast<ChildEvent>(state().child_original[i][10])(child);geometry();
}
static void __fastcall child_draw(Child* child,void*,IRenderer* renderer,const Vec2* origin) {
    const int i=child_index(child);if(i<0)return;geometry();
    reinterpret_cast<ChildDraw>(state().child_original[i][4])(child,renderer,origin);
}
static void bind_child(int i) {
    auto* child=state().children[i];auto** original=*reinterpret_cast<void***>(child);
    std::memcpy(state().child_original[i],original,sizeof(state().child_original[i]));
    std::memcpy(state().child_tables[i],original,sizeof(state().child_tables[i]));
    auto** table=state().child_tables[i];table[4]=reinterpret_cast<void*>(&child_draw);
    table[8]=reinterpret_cast<void*>(&child_layout);table[9]=reinterpret_cast<void*>(&child_resize);
    table[10]=reinterpret_cast<void*>(&child_dpi);*reinterpret_cast<void***>(child)=table;
}
static void brush(IRenderer* renderer,const CTab* tab,const Vec2* origin) {
    if(!renderer||!origin)return;
    const int extent=std::max(1,std::min({improved_layout::px(38*dpi()),tab->Size.x-8,tab->Size.y-8}));
    const int left=origin->x+tab->Pos.x+(tab->Size.x-extent)/2;
    const int top=origin->y+tab->Pos.y+(tab->Size.y-extent)/2;
    const int shade=state().menu->CurrentTab==unsigned(tab->Header.Index)?208:(tab->Header.Flags.Hovered?170:115);
    for(int y=0;y<extent;y++) {
        int start=0,last=0;
        for(int x=0;x<=extent;x++) {
            const int value=x==extent?0:improved_brush_icon::coverage[(y*96/extent)*96+x*96/extent];
            if(x==extent||value!=last) {
                if(last)renderer->Rect(left+start,top+y,x-start,1,
                    VecCol(shade,shade,shade,(last*255+8)/16).pack());
                start=x;last=value;
            }
        }
    }
}
static void __fastcall draw(CTab* tab,void*,IRenderer* renderer,const Vec2* origin) {
    auto* b=find(tab);if(!b)return;geometry();
    if(tab!=state().custom) {reinterpret_cast<Draw>(b->original[4])(tab,renderer,origin);return;}
    brush(renderer,tab,origin);
    if(state().menu->CurrentTab==unsigned(tab->Header.Index)) {
        for(auto it=tab->Childs.rbegin();it!=tab->Childs.rend();++it) {
            auto* child=*it;if(!child||!child->Header.Flags.Visible)continue;
            auto** vt=*reinterpret_cast<void***>(child);
            reinterpret_cast<ChildDraw>(vt[4])(child,renderer,origin);
        }
    }
}
static void bind(CTab* tab) {
    if(!tab)return;
    auto** vt=*reinterpret_cast<void***>(tab);
    auto* existing=find(tab);
    // A later third-party vtable may retain or chain our callbacks. Do not
    // wrap it again: that could make our saved original point back to us.
    if(existing)return;
    const unsigned slots=table_slots(vt);if(!slots)return;
    if(state().bindings_count==32)return;
    auto& b=state().bindings[state().bindings_count++];b.tab=tab;b.slots=slots;
    std::memcpy(b.original,vt,slots*sizeof(void*));std::memcpy(b.table,vt,slots*sizeof(void*));
    b.table[1]=reinterpret_cast<void*>(&hovered);b.table[4]=reinterpret_cast<void*>(&draw);
    b.table[9]=reinterpret_cast<void*>(&resized);b.table[10]=reinterpret_cast<void*>(&scaled);
    *reinterpret_cast<void***>(tab)=b.table;
}
static bool initialize(CMenu* menu) {
    if(!tab_ctor||!child_ctor||!append_child||!api.allocate||!native_menu_shape::tabbed(menu)||menu->Tabs.size()>=32)return false;
    capture_order();
    auto* first=menu->Tabs[0];const float scale=dpi();
    state().left=first->Pos.x/scale;state().top=first->Pos.y/scale;
    state().width=first->DefSize.x>0?float(first->DefSize.x):first->Size.x/scale;
    state().base_min_height=menu->MinSize.y/scale;
    auto* tab=static_cast<CTab*>(api.allocate(sizeof(CTab)));if(!tab)return false;
    std::memset(tab,0,sizeof(CTab));int position[]={first->Pos.x,first->Pos.y};
    tab_ctor(tab,menu,L"Improved",position);
    struct PendingTab {
        CTab* tab;bool committed=false;
        ~PendingTab(){if(!committed&&tab) {
            auto** vt=*reinterpret_cast<void***>(tab);
            reinterpret_cast<void(__thiscall*)(CTab*,bool)>(vt[0])(tab,true);
        }}
    } pending{tab};
    tab->Header.Index=int(menu->Tabs.size());
    tab->Header.Flags.Visible=tab->Header.Flags.Editable=tab->Header.Flags.AllowMouseInput=true;
    const wchar_t* names[]={L"Backtrack",L"Lag records",L"Extrapolation"};
    for(int i=0;i<3;i++) {
        auto* child=static_cast<Child*>(api.allocate(sizeof(Child)));if(!child)return false;
        std::memset(child,0,sizeof(Child));
        child_ctor(child,tab,names[i],int(0xff000000U),0,false);
        child->Header.Flags.Visible=true;append_child(tab,child);state().children[i]=child;
    }
    // Appending preserves every native vector index and the fixed TabsArr[9].
    menu->Tabs.push_back(tab);state().custom=tab;pending.committed=true;
    for(int i=0;i<3;i++)bind_child(i);
    for(auto* item:menu->Tabs)bind(item);
    geometry(true);return true;
}
static void configure(const native_ui_proxy::Api& value,TabCtor ctor,ChildCtor child,AppendChild append) {
    api=value;tab_ctor=ctor;child_ctor=child;append_child=append;
}
static void frame(CMenu* menu) {
    const unsigned issue=native_menu_shape::issue(menu);
    if(issue) {
        // Auxiliary windows are expected here. Do not replace a valid/active
        // main-window status when the chain later draws another window.
        if(skeet_improved_status.stage<ImprovedCreating) {
            skeet_improved_status.menu=reinterpret_cast<DWORD>(menu);
            skeet_improved_status.tabs=menu?static_cast<DWORD>(menu->Tabs.size()):0;
            skeet_improved_status.custom_index=issue;
            const char* messages[]={"OK","Rejected: null window","Rejected: native tab count outside 9..32",
                "Rejected: active tab outside vector","Rejected: null native tab",
                "Rejected: native tab index differs from vector ordinal","Rejected: native tab has another parent",
                "Rejected: semantic lookup points outside native tabs or is duplicated"};
            improved_diagnostic::update(ImprovedMenuRejected,messages[issue]);
        }
        return;
    }
    if(menu->Size.x<300||menu->Size.x>8192||menu->Size.y<200||menu->Size.y>8192)return;
    skeet_improved_status.menu=reinterpret_cast<DWORD>(menu);
    skeet_improved_status.tabs=static_cast<DWORD>(menu->Tabs.size());
    if(state().menu!=menu) {
        current_state=nullptr;
        for(unsigned i=0;i<histories_count;i++)if(histories[i]->menu==menu)current_state=histories[i];
        if(!current_state) {
            if(histories_count==16)return;
            current_state=new(std::nothrow) State{};if(!current_state)return;
            current_state->menu=menu;histories[histories_count++]=current_state;
        }
    }
    if(!state().attempted&&(menu->MenuStatus&MenuOpened)) {
        state().attempted=true;
        improved_diagnostic::update(ImprovedCreating,"Creating Improved and its three native panels");
        try {if(!initialize(menu))improved_diagnostic::update(ImprovedFailed,"Improved allocation or native UI construction failed");}
        catch(...){improved_diagnostic::update(ImprovedFailed,"Improved construction raised a C++ exception");}
    }
    if(live()) {
        for(auto* tab:menu->Tabs)bind(tab);geometry(true);
        skeet_improved_status.tabs=static_cast<DWORD>(menu->Tabs.size());
        skeet_improved_status.custom_index=state().custom->Header.Index;
        improved_diagnostic::update(ImprovedActive,"Improved attached; brush placed visually below Rage");
    } else if(!state().attempted)improved_diagnostic::update(ImprovedMenuClosed,"Main menu found; press Insert to create Improved");
}
}

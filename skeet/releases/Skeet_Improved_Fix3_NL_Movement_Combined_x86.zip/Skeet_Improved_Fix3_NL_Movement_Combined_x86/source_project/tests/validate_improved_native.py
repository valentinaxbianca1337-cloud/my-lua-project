"""Closed x86 UI fixture. Native hover/select/icon render run from the supplied core.
Constructors, allocation, child layout and renderer are controlled boundaries.
No DLL entrypoint, injector or actual game is executed.
"""
from pathlib import Path
import struct,json,itertools,sys
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1]
core=(ROOT/'source/skeet/Binary/skeet.bin').read_bytes();CB=0x43310000
pe=pefile.PE(str(ROOT/'build/improved_probe.dll'));PB=pe.OPTIONAL_HEADER.ImageBase
symbols={s.name.decode():PB+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
MEM=0x70000000;API=0x70500000;SP=MEM+0x7f000;STOP=API+0xfff0
MENU=MEM+0x10000;TABS=MEM+0x20000;RENDERER=MEM+0x60000;RVT=RENDERER+0x100
ORIGIN=RENDERER+0x500;TVT=0x4346f9c8;CVT=MEM+0x2000
ALLOC=API+0x100;FREE=API+0x120;CTOR=API+0x140;CHILD=API+0x160;APPEND=API+0x180
DECAY=API+0x1a0;EVENT=API+0x1c0;RECT=API+0x1e0;TEXTURE=API+0x200;CHILDDRAW=API+0x220
def machine(dpi,capacity):
 u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(CB,len(core));u.mem_write(CB,core)
 u.mem_map(PB,(pe.OPTIONAL_HEADER.SizeOfImage+4095)&~4095);u.mem_write(PB,pe.get_memory_mapped_image())
 u.mem_map(MEM,0x400000);u.mem_map(API,0x10000)
 def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
 def put(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def floats(a,v):u.mem_write(a,struct.pack('<f',v))
 def finish(sp,result=0,args=0):
  ret=word(sp);u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+4+args);u.reg_write(UC_X86_REG_EIP,ret)
 imports={}
 for lib in pe.DIRECTORY_ENTRY_IMPORT:
  for item in lib.imports:
   at=API+0x1000+len(imports)*16;put(item.address,at)
   imports[at]=item.name.decode() if item.name else '#'+str(item.ordinal)
 u.mem_write(TVT,bytes(u.mem_read(0x4346f9c8,15*4)))
 for i in [6,13,14]:put(TVT+i*4,EVENT)
 put(TVT,DECAY)
 u.mem_write(CVT,bytes(u.mem_read(0x4347072c,13*4)))
 for i in [0,8,9,10]:put(CVT+i*4,EVENT)
 put(CVT+4*4,CHILDDRAW)
 put(RVT+4*4,RECT);put(RVT+23*4,TEXTURE);put(RENDERER,RVT)
 put(ORIGIN,20);put(ORIGIN+4,30)
 floats(0x4346d490,dpi)
 put(MENU+0x14,int(800*dpi));put(MENU+0x18,int(700*dpi))
 put(MENU+0x1c,int(400*dpi));put(MENU+0x20,int(300*dpi));put(MENU+0x34,1)
 put(MENU+0x54,TABS);put(MENU+0x58,TABS+36);put(MENU+0x5c,TABS+4*capacity)
 original=[]
 for i in range(9):
  tab=MEM+0x30000+i*0x1000;original.append(tab);put(TABS+4*i,tab);put(MENU+0xb4+4*i,tab)
  put(tab,TVT);put(tab+0xc,i);put(tab+0x10,MENU);put(tab+0x60,MENU)
  u.mem_write(tab+0x14,b'\1\1\0\1\0\1')
  for off,v in [(0x20,0),(0x24,int((5+64*i)*dpi)),(0x28,int(75*dpi)),(0x2c,int(64*dpi)),(0x30,75),(0x34,64),(0x80,100+i),(0x84,i*64),(0x8c,int(44*dpi)),(0x90,int(44*dpi))]:put(tab+off,v)
 state={'alloc':0,'next':MEM+0x90000,'fail':0,'destroyed':[],'textures':[],'rects':[],'children':[],'child_draws':[]}
 def hook(u,a,size,user):
  if a==STOP:u.emu_stop();return
  if a not in imports and a not in [ALLOC,FREE,CTOR,CHILD,APPEND,DECAY,EVENT,RECT,TEXTURE,CHILDDRAW,0x433ad23f]:return
  sp=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
  if a in imports:
   name=imports[a]
   if name in ['memset','memcpy','memmove']:
    dst,src,n=[word(sp+i)for i in [4,8,12]]
    data=bytes([src&255])*n if name=='memset' else bytes(u.mem_read(src,n))
    u.mem_write(dst,data);finish(sp,dst);return
   raise AssertionError(name)
  if a==ALLOC:
   state['alloc']+=1
   if state['fail']==state['alloc']:finish(sp,0);return
   result=state['next'];state['next']+=0x2000;finish(sp,result);return
  if a==FREE:finish(sp);return
  if a==CTOR:
   parent,name,pos=[word(sp+i)for i in [4,8,12]]
   assert parent==MENU and bytes(u.mem_read(name,18)).decode('utf-16-le')=='Improved\0'
   put(this,TVT);put(this+0x10,parent);put(this+0x60,parent)
   u.mem_write(this+0x14,b'\1\1\0\1\0\1')
   for off,v in [(0x20,word(pos)),(0x24,word(pos+4)),(0x28,75),(0x2c,64),(0x30,75),(0x34,64),(0x80,0xffffffff)]:put(this+off,v)
   put(this+0x70,this+0x400);put(this+0x74,this+0x400);put(this+0x78,this+0x480)
   finish(sp,this,12);return
  if a==CHILD:
   parent=word(sp+4);put(this,CVT);put(this+0x10,parent);u.mem_write(this+0x14,b'\1\1\0\1\0\7')
   for off in [0x28,0x2c,0x30,0x34]:put(this+off,200)
   state['children'].append(this);finish(sp,this,20);return
  if a==APPEND:
   child=word(sp+4);end=word(this+0x74);put(end,child);put(this+0x74,end+4);finish(sp,0,4);return
  if a==DECAY:state['destroyed'].append(this);finish(sp,0,4);return
  if a in [EVENT,0x433ad23f]:finish(sp);return
  if a==RECT:
   state['rects'].append(tuple(word(sp+i)for i in [4,8,12,16,20]));finish(sp,0,20);return
  if a==TEXTURE:
   values=tuple(word(sp+i)for i in [4,8,12,16,20,24,28,32])
   state['textures'].append((u.reg_read(UC_X86_REG_EDX),values));finish(sp,0,32);return
  if a==CHILDDRAW:state['child_draws'].append(this);finish(sp,0,8)
 u.hook_add(UC_HOOK_CODE,hook)
 def call(name,args=(),this=None,address=None):
  for i,v in enumerate([STOP,*args]):put(SP+i*4,v)
  u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_MXCSR,0x1f80)
  if this is not None:u.reg_write(UC_X86_REG_ECX,this)
  u.emu_start(symbols[name] if address is None else address,STOP,count=1000000)
  assert u.reg_read(UC_X86_REG_EIP)==STOP,hex(u.reg_read(UC_X86_REG_EIP))
  assert u.reg_read(UC_X86_REG_ESP)==SP+4+(4*len(args)if address is not None else 0)
  return u.reg_read(UC_X86_REG_EAX)
 return u,state,word,put,floats,call,original
def validate():
 cases=0;native_draws=0;native_hover_checks=0;failed_allocations=0;dpi_roundtrips=0
 
 for dpi,capacity in itertools.product([.75,1.,1.25,1.5,2.,3.],[9,32]):
  u,s,word,put,floats,call,original=machine(dpi,capacity)
  before=bytes(u.mem_read(MENU+0xb4,36))
  assert call('improved_construct',[MENU,ALLOC,FREE,CTOR,CHILD,APPEND])==1
  vector=word(MENU+0x54);custom=word(vector+36)
  assert word(MENU+0x58)-vector==40 and bytes(u.mem_read(MENU+0xb4,36))==before
  assert [word(vector+4*i)for i in range(9)]==original
  assert word(custom+0xc)==9 and call('improved_native_shape',[MENU])==1
  saved_icons=[bytes(u.mem_read(t+0x80,20))for t in original]
  for width,height in [(640,480),(800,700),(1200,900),(640,480),(800,700)]:
   put(MENU+0x14,int(width*dpi));put(MENU+0x18,int(height*dpi));call('improved_geometry')
   for tab in original+[custom]:
    for kind in [0,1]:call('improved_event',[tab,kind])
   for i,tab in enumerate(original+[custom]):
    x,y,w,h=[word(tab+o)for o in [0x20,0x24,0x28,0x2c]]
    assert y+h<word(MENU+0x18)
    hits=[call('improved_hover',[t,x+w//2,y+h//2])for t in original+[custom]]
    assert hits[i]==1 and sum(hits)==1,(dpi,i,hits)
    native_hover_checks+=len(hits)
   assert word(original[0]+0x24)<word(custom+0x24)<word(original[1]+0x24)
   assert [word(t+0xc)for t in original]==list(range(9))
   assert all(word(t+0x30)==75 for t in original+[custom])
   assert [bytes(u.mem_read(t+0x80,20))for t in original]==saved_icons
   # Execute the original CMenu selection function against the append-only vector.
   call('',[9],this=MENU,address=0x433b75d3);assert word(MENU+0x64)==9
   s['textures'].clear();s['rects'].clear();s['child_draws'].clear()
   for tab in original+[custom]:call('improved_draw',[tab,RENDERER,ORIGIN])
   assert [x[0]for x in s['textures']]==list(range(100,109))
   assert len(s['child_draws'])==3
   for i,(_,args)in enumerate(s['textures']):assert args[3]==i*64 and args[5]==int(44*dpi) and args[6]==int(44*dpi)
   left=20+word(custom+0x20);top=30+word(custom+0x24);right=left+word(custom+0x28);bottom=top+word(custom+0x2c)
   assert s['rects']
   for x,y,w,h,color in s['rects']:assert left<=x and top<=y and x+w<=right and y+h<=bottom
   call('',[1],this=MENU,address=0x433b75d3);assert word(MENU+0x64)==1
   assert bytes(u.mem_read(MENU+0xb4,36))==before
   native_draws+=9;cases+=1
  baseline=[tuple(word(t+o)for o in [0x20,0x24,0x28,0x2c])for t in original+[custom]]
  for changed in [.75,3.,1.,2.,1.25,1.5,dpi]:
   floats(0x4346d490,changed);put(MENU+0x14,int(800*changed));put(MENU+0x18,int(700*changed))
   put(MENU+0x20,int(300*changed))
   for tab in original:put(tab+0x8c,int(44*changed));put(tab+0x90,int(44*changed))
   call('improved_geometry')
   for tab in original+[custom]:
    call('improved_event',[tab,1])
    assert word(tab+0x30)==75
    assert abs(word(tab+0x28)-word(tab+0x30)*changed)<=2
    assert abs(word(tab+0x2c)-word(tab+0x34)*changed)<=2
    x,y,w,h=[word(tab+o)for o in [0x20,0x24,0x28,0x2c]]
    assert call('improved_hover',[tab,x+w//2,y+h//2])==1
   for child in s['children']:
    assert abs(word(child+0x28)-word(child+0x30)*changed)<=2
    assert abs(word(child+0x2c)-word(child+0x34)*changed)<=2
   assert bytes(u.mem_read(MENU+0xb4,36))==before
   dpi_roundtrips+=1
  assert [tuple(word(t+o)for o in [0x20,0x24,0x28,0x2c])for t in original+[custom]]==baseline
  # An external copy of a hooked native vtable must not get wrapped recursively.
  foreign=MEM+0x50000;u.mem_write(foreign,bytes(u.mem_read(word(original[0]),60)));put(original[0],foreign)
  call('improved_rebind');assert word(original[0])==foreign
  call('improved_draw',[original[0],RENDERER,ORIGIN])
 for fail in [1,2,3,4,5]:
  u,s,word,put,floats,call,original=machine(1.,9);s['fail']=fail
  before=bytes(u.mem_read(MENU+0xb4,36));vector=word(MENU+0x54)
  try:result=call('improved_construct',[MENU,ALLOC,FREE,CTOR,CHILD,APPEND])
  except Exception:
   # The C++ allocator turns a null vector growth into a Windows C++ exception;
   # that runtime is outside this fixture. Only explicit constructor failures run.
   if fail==5:continue
   raise
  assert result==0 and word(MENU+0x54)==vector and word(MENU+0x58)==vector+36
  assert bytes(u.mem_read(MENU+0xb4,36))==before
  if fail>1:assert s['destroyed']
  failed_allocations+=1
 print(json.dumps({'passed':True,'resize_dpi_sequences':cases,'native_hover_checks':native_hover_checks,
  'same_menu_dpi_changes':dpi_roundtrips,
  'native_icon_draws':native_draws,'allocation_failure_cases':failed_allocations,
  'native_select_tab_executed':True,'native_icon_render_executed':True,'native_hover_executed':True,
  'original_indices_and_tabsarr_preserved':True,'original_texture_ids_offsets_sizes_preserved':True,
  'brush_rectangles_inside_slot':True,'boundaries':['allocation and constructors','renderer/child drawing','child layout and tab open/reset callbacks'],
  'foreign_vtable_not_rewrapped':True,
  'dll_entry_executed':False,'game_tested':False},indent=2))

if __name__=="__main__":validate()

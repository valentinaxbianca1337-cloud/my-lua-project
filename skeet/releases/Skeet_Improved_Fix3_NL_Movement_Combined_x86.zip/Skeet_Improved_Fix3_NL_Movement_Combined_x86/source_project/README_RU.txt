Improved Fix3 + NL Movement 1 — combined

Рабочая UI-база: Improved Fix 3 (появление вкладки, остальные иконки,
изменение размера и DPI пользователь подтвердил на своём клиенте).
Файлы логики Improved и исходный skeet.bin сохранены без изменений.

Добавлены native v2 exports и Lua command bridge:
- Normal: NL steering относительно направления камеры;
- WASD: NL steering относительно нажатого направления;
- Directional: проверенный NL выбор поворотов + адаптированный Source predictor.

Это НЕ полный перенос protected Neverlose movement/prediction 1:1.
Directional candidate search совпал с исходными инструкциями в 924 случаях,
включая 19614 проверок кандидатов. Collision/simulation hooks в том сравнении
были контролируемыми границами. Новый predictor реализован под Source hull
traces; совпадение всего симулятора с NL не установлено. Surface friction=1;
при отсутствии свойств hull используются стандартные 16x16x72/54 размеры,
при отсутствии sv_air_max_wishspeed — стандартное ограничение 30.
Autopeek, автостоп перед выстрелом и прочие функции movement не переносились.

Запуск movement:
1. Загрузить matching DLL из этого комплекта через matching injector.
2. Загрузить lua/nl_movement_combined.lua в GameSense Lua.
3. MISC -> Movement -> Neverlose movement, затем выбрать NL strafe mode.
Штатный Air strafe отключается на время владения и восстанавливается при
выключении/выгрузке. Старый nl_movement.lua/v1 — только для совместимости;
одновременно включать оба адаптера или другой стрейфер не следует.
Без Lua bridge новые exports сами обработчик команд не регистрируют.

Source host использует named factories EngineTraceClient004 и
VClientEntityList003, CUserCmd/entity/ConVar memory не переписывает.
Максимум 1536 hull queries на расчёт. При недоступности interfaces, неверном
результате trace или исчерпании бюджета Directional возвращает WASD steering
и сообщает причину через Lua log. Углы прицеливания, атака, duck и packet
поля Lua не меняет. Работа на реальном сервере ещё не проверена.

Проверки этой версии: reports/combined_adapter.json (21 группа),
movement_v2_core.json (синтетические препятствия/пол/ошибки), trace_host.json
(x86 Ray_t/filter/TraceRay ABI с контролируемыми factories),
movement_v2_windows.json (18 вызовов новых exports собранной DLL),
windows_build_validation.json (300 вызовов legacy exports),
combined_source_merge.json (сохранность Fix 3 UI/core).
Ни DLL entry, ни injector, ни реальный движок эти тесты не запускают.

Skeet 8802 — Improved с кисточкой под Rage

Это обновление интерфейса. Вкладка содержит три панели: Backtrack, Lag records,
Extrapolation. Новые настройки и игровые патчи обработки записей пока не
подключены; подготовлено место для их последующего добавления. Movement и
Profiles в Improved отсутствуют.

Новая CTab добавляется в конец native Tabs, а визуально размещается сразу
под Rage. Штатные логические ID 0..8 и фиксированный TabsArr[9] сохранены.
Текстуры остальных иконок, atlas offsets и размеры не меняются.
При уменьшении окна сокращается интервал между строками, а не размер иконок.
Минимальная высота учитывает все строки и самую высокую штатную иконку.
Геометрия применяется до hit-test и отрисовки, после resize и DPI callbacks.
Канонические размеры отделены от пиксельных во избежание повторного DPI.
Маска кисточки встроена в DLL; PNG нужны только для просмотра исходного ресурса.

Проверки текущей версии:
- 784 portable варианта размеров/DPI/числа вкладок;
- 60 native x86 последовательностей изменения размеров;
- 6000 hit-test с исходной native IsHovered;
- 84 изменения DPI на одном меню и возврат исходной геометрии;
- штатная select-tab функция переключает Improved и AA;
- 540 native icon render вызовов сохранили texture ID/offset/size;
- кисточка остаётся внутри собственной области;
- отказы выделения объектов не меняют штатные ID/TabsArr;
- чужая копия vtable повторно не оборачивается.

Закрытый fixture использует контролируемые allocator/constructor/renderer
и child-layout границы. Это не проверка настоящей GPU-отрисовки в игре.
DLL entrypoint и injector при проверках не исполнялись. Игровой запуск и
визуальное совпадение на реальном клиенте не проверены. Отсутствие всех
возможных багов не заявляется.

В Native Visuals/Skins/Inventory обновлены проверки прежних 9 вкладок.
Первые девять логических ID должны оставаться штатными. Дополнительные
вкладки, добавляемые в конец, учитываются до 32. Сторонняя перестановка
штатных ID не поддерживается. Существующая чужая vtable не оборачивается снова.

База: исходный skeet.bin без удалённых ранее scan/precision/motion,
body-preference и DT-accuracy модулей. Прежние Normal/WASD C++ exports и
Lua-адаптер не изменялись; в новую вкладку они не добавлены. Полный movement
Neverlose 1:1 этим изменением не реализуется. Остальной интерфейс и загрузчик
совместимости сохранены.

Реализация:
source/skeet/improved_tab_impl.h
source/skeet/improved_tab_layout.h
source/skeet/native_menu_shape.h
source/skeet/improved_brush_icon.h

Ресурс: assets/brush.svg и прозрачные PNG.
Сборка Windows x86: python build_windows.py (ziglang==0.13.0).
Проверка исходников: python verify_source.py
Portable geometry: g++ -std=c++17 -O2 tests/improved_layout.cpp -o improved_layout
Native fixture: tests/validate_improved_native.py после отдельной сборки
improved_probe.cpp в build/improved_probe.dll с image base 0x40000000.
Результаты: reports/.

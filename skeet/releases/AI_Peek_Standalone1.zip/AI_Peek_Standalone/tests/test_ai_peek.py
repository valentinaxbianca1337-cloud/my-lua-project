from pathlib import Path
import json,math
from lupa.luajit21 import LuaRuntime
ROOT=Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'ai_peek.lua').read_text()

def machine():
 l=LuaRuntime(unpack_returned_tuples=True)
 l.execute('''
 clock=0;query_ms=0;cost_ms=0;frames=.005;pos={x=0,y=0,z=0};flags=1;duck=0
 enemy={x=500,y=100,z=0,flags=1,duck=0,alive=true,dormant=false};values={};callbacks={};buttons={}
 blocked=false;no_floor=false;damage=80;wrong_hit=false;crossfire=false;engine_error=false
 line_step=0;bullet_step=0;maximum_line=0;maximum_bullet=0
 ui={};client={};globals={};entity={};renderer={}
 function ui.reference(a,b,n)
  if n=="Enabled" then values.rage=true;values.ragekey=true;return "rage","ragekey" end
  if n=="Quick peek assist" then values.quick=false;values.quickkey=false;return "quick","quickkey" end
  if n=="Target hitbox" then values.boxes={"Head","Chest","Stomach"};return "boxes" end
  if n=="Minimum damage" then values.mindmg=20;return "mindmg" end
  if n=="Minimum damage override" then values.override=false;values.overkey=false;values.overvalue=100;return "override","overkey","overvalue" end
  error(n)
 end
 function ui.new_checkbox(a,b,n)values[n]=false;return n end
 function ui.new_hotkey(a,b,n)values[n]=false;return n end
 function ui.new_slider(a,b,n,lo,hi,v)values[n]=v;return n end
 function ui.new_button(a,b,n,f)buttons[n]=f;return n end
 function ui.get(n)return values[n]end
 function ui.set(n,v)assert(n:find("AI Peek"),"native setting write");values[n]=v end
 function client.timestamp()return clock*1000+query_ms end
 function client.latency()return .03 end
 function client.camera_angles()return 0,0 end
 function client.eye_position()return pos.x,pos.y,pos.z+64 end
 function client.set_event_callback(n,f)callbacks[n]=f end
 function client.trace_line(skip,ax,ay,az,bx,by,bz)
  line_step=line_step+1;query_ms=query_ms+cost_ms
  if engine_error then error("engine trace failed")end
  if ax==bx and ay==by and math.abs(az-bz-64)<.001 then return no_floor and 1 or .375,-1 end
  if blocked then return .3,-1 end
  if bx==enemy.x and by==enemy.y then return .8,2 end
  return 1,-1
 end
 function client.trace_bullet(i,ax,ay,az,bx,by,bz)
  bullet_step=bullet_step+1;query_ms=query_ms+cost_ms
  if engine_error then error("engine bullet failed")end
  if ay>=10 then return wrong_hit and 3 or 2,damage end
  return nil,0
 end
 function globals.curtime()return 5+clock end
 function globals.tickinterval()return 1/64 end
 function globals.absoluteframetime()return frames end
 function entity.get_local_player()return 1 end
 function entity.get_players(enemies)return crossfire and {2,3}or {2}end
 function entity.is_alive(i)return i==1 or enemy.alive end
 function entity.is_dormant(i)return i==2 and enemy.dormant end
 function entity.get_player_weapon(i)return 10 end
 function entity.get_classname(i)return "CWeaponSSG08" end
 function entity.get_prop(i,n)
  if n=="m_vecOrigin"then local p=i==1 and pos or enemy;return p.x,p.y,p.z end
  if n=="m_flSimulationTime"then return 5+math.floor(clock*32)/32-.03 end
  if n=="m_fFlags"then return i==1 and flags or enemy.flags end
  if n=="m_flDuckAmount"then return i==1 and duck or enemy.duck end
  if n=="m_iHealth"then return 100 end
  if n=="m_MoveType"then return 2 end
  if n=="m_flNextAttack"or n=="m_flNextPrimaryAttack"then return 0 end
  if n=="m_iClip1"then return 10 end
 end
 function entity.hitbox_position(i,b)return enemy.x,enemy.y,b==0 and 64 or b==5 and 48 or 36 end
 function renderer.indicator(...)end
 function writefile(...)end
 json={stringify=function()return "{}"end}
 ''')
 m=l.execute(SOURCE);g=l.globals()
 g["values"]['AI Peek']=True;g["values"]['AI Peek key']=True
 return l,m

def tick(l,m,number,simulate=True,buttons=None):
 g=l.globals();g.clock=number/64;g.query_ms=0;g.line_step=0;g.bullet_step=0
 cmd=l.table_from(buttons or {})
 g.callbacks['setup_command'](cmd)
 assert g.line_step<=6 and g.bullet_step<=2,(g.line_step,g.bullet_step)
 if simulate and cmd['move_yaw'] is not None:
  speed=cmd['forwardmove'] or 0;a=math.radians(cmd['move_yaw'])
  g.pos.x+=math.cos(a)*speed/64;g.pos.y+=math.sin(a)*speed/64
 return cmd,m['status']()

checks=0
l,m=machine();ever=False;shot=False;maxdist=0
for n in range(1,450):
 cmd,status=tick(l,m,n);maxdist=max(maxdist,math.hypot(l.globals().pos.x,l.globals().pos.y))
 if status=='Peeking':ever=True
 if status=='Holding'and not shot:l.globals().callbacks['aim_fire'](l.table());shot=True
 if status=='Returned':break
assert ever and shot and status=='Returned'and maxdist<=32 and math.hypot(l.globals().pos.x,l.globals().pos.y)<=3
assert m['counters']['confirmed']==1;checks+=1

for case in ['disabled','released','rage_off','rage_hotkey_off','native_quick','air','manual','low_fps','wall','drop','low_damage','wrong_entity','head_aircrouch','crossfire','trace_error','damage_override','crouch_change']:
 l,m=machine();g=l.globals()
 if case=='disabled':g["values"]['AI Peek']=False
 if case=='released':g["values"]['AI Peek key']=False
 if case=='rage_off':g["values"].rage=False
 if case=='rage_hotkey_off':g["values"].ragekey=False
 if case=='native_quick':g["values"].quick=True;g["values"].quickkey=True
 if case=='air':g.flags=0
 if case=='low_fps':g.frames=.04
 if case=='wall':g.blocked=True
 if case=='drop':g.no_floor=True
 if case=='low_damage':g.damage=10
 if case=='wrong_entity':g.wrong_hit=True
 if case=='head_aircrouch':g["values"].boxes=l.table_from(['Head']);g.enemy.flags=0;g.enemy.duck=1
 if case=='crossfire':g.crossfire=True
 if case=='trace_error':g.engine_error=True
 if case=='damage_override':g["values"].override=True;g["values"].overkey=True;g["values"].overvalue=110
 for n in range(1,250):
  if case=='crouch_change'and n==2:g.duck=.5
  cmd,status=tick(l,m,n,False,{'in_forward':1}if case=='manual'else None)
  assert not cmd['forwardmove'],(case,n,status,cmd['forwardmove'])
 if case in ['disabled','released','rage_off','rage_hotkey_off','native_quick','air','manual','low_fps','head_aircrouch']:
  assert m['counters']['bullet']==0,case
 checks+=1

for case in ['target_loss','shot','timeout','low_fps','manual','release','return_blocked','stuck']:
 l,m=machine();g=l.globals();armed=False;retreated=False
 for n in range(1,450):
  cmd,status=tick(l,m,n,case!='stuck')
  if not armed and status in ['Peeking','Holding']:
   armed=True
   if case=='target_loss':g.enemy.dormant=True
   if case in ['shot','return_blocked']:
    g.callbacks['aim_fire'](l.table())
    if case=='return_blocked':g.blocked=True
   if case=='low_fps':g.frames=.04
   if case=='release':g["values"]['AI Peek key']=False
   if case=='manual':
    cmd,status=tick(l,m,n+1,False,{'in_forward':1,'forwardmove':123})
    assert status=='Manual input'and cmd['forwardmove']==123;break
  if armed and status in ['Returning','Returned','Return blocked','Movement blocked','Idle']:retreated=True
  if armed and status in ['Returned','Return blocked','Movement blocked','Idle']:break
 assert armed,case
 if case!='manual':assert retreated,(case,status)
 checks+=1
# Work timer is best-effort: after three 0.25ms calls it yields, not spinning.
l,m=machine();l.globals().cost_ms=.25
for n in range(1,200):tick(l,m,n,False)
assert m['counters']['time_budget_yields']>0;checks+=1
for kind in ['actual_movetype','fixed_simulation','nonfinite_damage','weapon_cooldown','unsupported_weapon','menu_open']:
 l,m=machine();g=l.globals()
 if kind=='actual_movetype':
  l.execute('oldprop=entity.get_prop;entity.get_prop=function(i,n) if n=="movetype" then return 2 elseif n=="m_MoveType" then return nil end return oldprop(i,n) end')
 if kind=='fixed_simulation':
  l.execute('oldprop=entity.get_prop;entity.get_prop=function(i,n) if n=="m_flSimulationTime" then return 5 end return oldprop(i,n) end')
 if kind=='nonfinite_damage':g.damage=float('nan')
 if kind=='weapon_cooldown':
  l.execute('oldprop=entity.get_prop;entity.get_prop=function(i,n) if n=="m_flNextPrimaryAttack" then return 100 end return oldprop(i,n) end')
 if kind=='unsupported_weapon':l.execute('entity.get_classname=function() return "CFlashbang" end')
 if kind=='menu_open':l.execute('ui.is_menu_open=function()return true end')
 moved=False
 for n in range(1,250):
  cmd,status=tick(l,m,n,False)
  moved=moved or bool(cmd['forwardmove'])
  if moved:break
 assert moved==(kind=='actual_movetype'),(kind,status)
 checks+=1
for token in ['ffi.','VirtualProtect','client.exec(','cmd.in_attack','cmd.force_defensive','cmd.allow_send_packet']:
 assert token not in SOURCE,token
report={'passed':True,'scenario_cases':checks,'runtime':'LuaJIT2.1','max_queries_per_planning_step':{'line':6,'bullet':2},
 'planning_interval_ms':50,'callback_budget_ms_best_effort':.7,'movement_only':True,
 'mock_engine_only':True,'game_tested':False,'historical_matrices_validated':False,'fps_measured':False}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

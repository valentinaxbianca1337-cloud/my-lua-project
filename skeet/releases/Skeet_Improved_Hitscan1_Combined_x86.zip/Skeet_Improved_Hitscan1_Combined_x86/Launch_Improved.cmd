@echo off
cd /d "%~dp0"
injector.exe
echo.
echo UI diagnostic: improved-status.txt
echo Hitscan: Improved tab
echo Movement: load nl_movement_combined.lua in GameSense Lua
pause

-- Requires the wrapper built from the accompanying source project.
-- Normal/WASD steering only. Directional/circle prediction is not implemented.
local ffi = require("ffi")
local bit = require("bit")
if not pcall(ffi.typeof,"nl8802_input") then ffi.cdef[[
void* __stdcall GetModuleHandleA(const char*);
void* __stdcall GetProcAddress(void*, const char*);
typedef struct {
 uint32_t version, bytes, phase, flags, move_type, water_level, buttons;
 float vx, vy, vz, pitch, yaw, forward, side, smoothing, side_speed;
} nl8802_input;
typedef struct {
 uint32_t bytes, handled;
 float forward, side, move_yaw, ideal, correction;
} nl8802_output;
]] end
local enabled = ui.new_checkbox("MISC", "Movement", "Neverlose WASD strafe")
local smooth = ui.new_slider("MISC", "Movement", "NL strafe smoothing", 0, 100, 50, true, "%")
local native = ui.reference("MISC", "Movement", "Air strafe")
local abi, calculate
local held, saved, warned = false, nil, false
local records, queue, next_phase, last_player, last_command = {}, {}, 0, nil, nil
local input, output = ffi.new("nl8802_input[1]"), ffi.new("nl8802_output[1]")
local function finite(v)
 return type(v)=="number" and v==v and v>-math.huge and v<math.huge
end
local function reset()
 records, queue, next_phase, last_command = {}, {}, 0, nil
end
local function release()
 if held and ui.get(native)==false then ui.set(native, saved) end
 held, saved = false, nil
 reset()
end
local function resolve()
 if calculate then return true end
 -- Resolve exports only from an already loaded module; do not load a DLL here.
 local module=ffi.C.GetModuleHandleA("skeet.dll")
 if module==nil then return false end
 local function symbol(name)
  local p=ffi.C.GetProcAddress(module,name)
  if p==nil then p=ffi.C.GetProcAddress(module,"_"..name) end
  return p
 end
 local v,ins,outs,run=symbol("nl_movement_api_version"),symbol("nl_movement_input_size"),
   symbol("nl_movement_output_size"),symbol("nl_movement_calculate")
 if v==nil or ins==nil or outs==nil or run==nil then return false end
 local version=ffi.cast("unsigned (__cdecl*)(void)",v)
 if version()~=1 or ffi.cast("unsigned (__cdecl*)(void)",ins)()~=ffi.sizeof(input[0])
  or ffi.cast("unsigned (__cdecl*)(void)",outs)()~=ffi.sizeof(output[0]) then return false end
 abi=version
 calculate=ffi.cast("int (__cdecl*)(const nl8802_input*, nl8802_output*)",run)
 return true
end
local function synchronize()
 local on=ui.get(enabled)
 ui.set_visible(smooth,on)
 if not on then release(); return false end
 if not resolve() then
  release()
  ui.set(enabled,false)
  if not warned then
   warned=true
   client.error_log("NL WASD strafe: this loaded skeet.dll has no matching movement exports; build the supplied sources first")
  end
  return false
 end
 if not held then saved=ui.get(native); held=true end
 -- Keep exactly one strafe owner active while this feature is enabled.
 if ui.get(native)~=false then ui.set(native,false) end
 if ui.get(native)~=false then release();ui.set(enabled,false);return false end
 return true
end
local function snapshot(cmd,number)
 local cached=records[number]
 if cached then return cached end
 if last_command and number<last_command then reset() end
 local pitch,yaw=cmd.pitch,cmd.yaw
 if not finite(pitch) or not finite(yaw) then pitch,yaw=client.camera_angles() end
 local forward,side=cmd.forwardmove,cmd.sidemove
 if not finite(pitch) or not finite(yaw) or not finite(forward) or not finite(side) then return nil end
 if math.abs(pitch)>89 or math.abs(forward)>450 or math.abs(side)>450 then return nil end
 cached={pitch=pitch,yaw=yaw,forward=forward,side=side,phase=next_phase}
 records[number]=cached;queue[#queue+1]=number
 if #queue>128 then records[table.remove(queue,1)]=nil end
 next_phase=1-next_phase;last_command=number
 return cached
end
local function command(cmd)
 if not synchronize() then return end
 local player=entity.get_local_player()
 if not player or not entity.is_alive(player) or globals.mapname()==nil then
  reset();last_player=nil;return
 end
 if player~=last_player then reset();last_player=player end
 local flags=entity.get_prop(player,"m_fFlags")
 local move_type=entity.get_prop(player,"m_MoveType")
 local water=entity.get_prop(player,"m_nWaterLevel")
 local vx,vy,vz=entity.get_prop(player,"m_vecVelocity")
 local walk=cmd.in_speed==1 or cmd.in_speed==true
 if not finite(flags) or not finite(move_type) or not finite(water)
  or not finite(vx) or not finite(vy) or not finite(vz) then reset();return end
 if bit.band(flags,1)~=0 or move_type~=2 or water>=2 or walk then reset();return end
 if math.abs(vx)>10000 or math.abs(vy)>10000 or math.abs(vz)>10000
  or (vx==0 and vy==0 and vz==0) then return end
 local number=cmd.command_number
 if not finite(number) or number<=0 or number%1~=0 then return end
 local state=snapshot(cmd,number)
 if not state then return end
 local side_speed=math.abs(cvar.cl_sidespeed:get_float())
 if not finite(side_speed) then return end
 side_speed=math.min(side_speed,450)
 local a=input[0]
 a.version=1;a.bytes=ffi.sizeof(a);a.phase=state.phase
 a.flags=flags;a.move_type=move_type;a.water_level=water;a.buttons=0
 a.vx=vx;a.vy=vy;a.vz=vz;a.pitch=state.pitch;a.yaw=state.yaw
 a.forward=state.forward;a.side=state.side;a.smoothing=ui.get(smooth);a.side_speed=side_speed
 output[0].bytes=ffi.sizeof(output[0])
 if calculate(input,output)~=1 or output[0].handled~=1 then return end
 local out=output[0]
 -- Public GameSense movement frame. Aim angles, attack, tickbase and packet flags
 -- are not written. The host remains responsible for the final command transform.
 cmd.forwardmove=tonumber(out.forward);cmd.sidemove=tonumber(out.side)
 cmd.move_yaw=tonumber(out.move_yaw)
 cmd.in_forward=0;cmd.in_back=0
 cmd.in_moveleft=out.side<0 and 1 or 0
 cmd.in_moveright=out.side>0 and 1 or 0
end
ui.set_callback(enabled,synchronize)
client.set_event_callback("setup_command",command)
client.set_event_callback("paint_ui",function()
 if held and not ui.get(enabled) then release() end
end)
client.set_event_callback("shutdown",release)
client.set_event_callback("level_init",reset)
client.set_event_callback("round_start",reset)
ui.set(enabled,false)
ui.set_visible(smooth,false)

"""Closed x86 execution: original selector/getter/apply prefix + new callbacks.
Native math, TLS and engine sweep are controlled boundaries. No game executed.
"""
from pathlib import Path
import struct,json,math,subprocess
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
from record_fixture import *

r=ROOT;p=pefile.PE(str(r/'build/records_probe.dll'));pb=p.OPTIONAL_HEADER.ImageBase
symbols={x.name.decode().lstrip('_@').split('@')[0]:pb+x.address for x in p.DIRECTORY_ENTRY_EXPORT.symbols if x.name}
scratch=symbols['records_fixture'];sweep=STOP+0x500
def call(u,name,args=(),ecx=0,edx=0):
 for i,v in enumerate([STOP,*args]):store(u,SP+4*i,v)
 u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,ecx);u.reg_write(UC_X86_REG_EDX,edx&0xffffffff)
 run_until(u,symbols[name],STOP,1000000);return u.reg_read(UC_X86_REG_EAX)
def full_record(u,ptr,t,x,y=0,z=0,flags=4,yaw=0):
 store(u,ptr+0x4c,t);store(u,ptr+0x5c,flags);floats(u,ptr+0x28,yaw);floats(u,ptr+0x30,x,y,z)
 for s in range(4):
  floats(u,ptr+0x220+s*0x3a0,yaw,11,22,33)
  for b in range(19):floats(u,ptr+0x230+s*0x3a0+b*48,1,0,0,x+b*.1,0,1,0,y,0,0,1,z+b)
plans={}
def plan(location):
 if location not in plans:
  out=r/'build'/f'records_plan_{location:x}.bin'
  subprocess.run([str(r/'build/records_plan'),str(r/'source/skeet/Binary/skeet.bin'),str(out),hex(location),
   hex(symbols['begin_records_probe']),hex(symbols['apply_records_probe']),hex(symbols['getter_records_probe']),
   hex(symbols['reset_records_probe']),hex(symbols['rejected_records_probe'])],check=True,capture_output=True)
  plans[location]=out.read_bytes()
 return plans[location]
def policy(backtrack=0,age=200,limit=0,count=16,consistent=1,gap=8,extrapolate=0,horizon=1):
 return backtrack|(limit<<1)|(consistent<<2)|(extrapolate<<3)|(age<<4)|(count<<12)|(gap<<18)|(horizon<<23)
class Case:
 def __init__(self,location=0x50000000,records=((100,100,0,0),(94,94,0,0)),now=102,dt=1/64,flags=4):
  self.u=u=fixture();self.location=location;self.wall=None;self.sweeps=[];self.solid=False
  u.mem_map(pb,p.OPTIONAL_HEADER.SizeOfImage);u.mem_write(pb,p.get_memory_mapped_image())
  data=plan(location);u.mem_map(location,8192);u.mem_write(location,data[:8192]);off=8192
  for _ in range(5):
   site,n=struct.unpack_from('<II',data,off);off+=8;u.mem_write(BASE+site,data[off:off+n]);off+=n
  self.return_address=struct.unpack_from('<I',data,off)[0];assert off+4==len(data)
  self.imports={}
  for lib in p.DIRECTORY_ENTRY_IMPORT:
   for item in lib.imports:
    a=STOP+0x600+len(self.imports)*16;store(u,item.address,a);self.imports[a]=item.name.decode()if item.name else '#'+str(item.ordinal)
  def boundary(u,a,size,user):
   if a not in self.imports and a!=sweep:return
   stack=u.reg_read(UC_X86_REG_ESP);ret=word(u,stack);cleanup=4;result=0
   if a==sweep:
    assert word(u,stack+4)==ACTOR
    start=struct.unpack('<3f',u.mem_read(stack+8,12));end=struct.unpack('<3f',u.mem_read(stack+20,12))
    assert word(u,stack+32)==records[0][0]
    self.sweeps.append((start,end));result=int(not self.solid and(self.wall is None or end[0]<self.wall))
   elif self.imports[a]=='TlsGetValue':assert word(u,stack+4)==7;result=scratch;cleanup=8
   elif self.imports[a]in ['memcpy','memmove','memset']:
    dst,src,n=[word(u,stack+i)for i in [4,8,12]]
    u.mem_write(dst,bytes([src&255])*n if self.imports[a]=='memset'else bytes(u.mem_read(src,n)));result=dst
   elif self.imports[a]=='fmod':
    aa,bb=struct.unpack('<dd',u.mem_read(stack+4,16));u.mem_write(MEM+0x7000,struct.pack('<d',math.fmod(aa,bb)))
    u.mem_write(a,b'\xdd\x05'+struct.pack('<I',MEM+0x7000)+b'\xc3');return
   else:raise AssertionError(('unexpected import',self.imports[a],hex(a)))
   u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,stack+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
  u.hook_add(UC_HOOK_CODE,boundary)
  for i,(t,x,y,z)in enumerate(records):
   ptr=NEW+i*0x2000;store(u,HISTORY+0x5dc+4*i,ptr);full_record(u,ptr,t,x,y,z,flags)
  store(u,HISTORY+0x5d8,len(records));store(u,HISTORY+0x5d4,0);floats(u,HISTORY+0x13c,*records[0][1:])
  floats(u,MEM+0x2000,dt);floats(u,MEM+0x2004,now*dt);floats(u,CONTEXT+0x198,0);floats(u,0x43476928,0);store(u,0x43468230,200)
  call(u,'initialize_records_probe',[location+0x800,sweep,self.return_address]);self.policy()
 def policy(self,**kw):call(self.u,'records_policy_probe',[policy(**kw)])
 def begin(self,low=94,high=100,upper=102,first=True):
  args=MEM+0x6000
  for i,v in enumerate([0x4332ff6b if first else 0x4332ff97,ACTOR,HISTORY,0,low,high,0,0]):store(self.u,args+4*i,v)
  call(self.u,'begin_records_probe',[CONTEXT,args,upper]);return word(self.u,args+16),word(self.u,args+20)
 def point(self,t,bone=0):
  result=call(self.u,'getter_records_probe',[bone,MEM+0x3000,MEM+0x3100],HISTORY,t)
  return result,bytes(self.u.mem_read(MEM+0x3000,12)),bytes(self.u.mem_read(MEM+0x3100,48))
 def applied(self,t):
  u=self.u;seen=[]
  def stop(u,a,size,user):
   # Unicorn may report an untruncated TB address after a rel32 wrap in
   # 32-bit mode. Architectural EIP and target memory are still 32-bit.
   if (a&0xffffffff)==0x43345b83:seen.append(True);u.emu_stop()
   if (a&0xffffffff)==0x433300c8:
    assert u.reg_read(UC_X86_REG_ESP)==SP+16
    seen.append(False);u.emu_stop()
  h=u.hook_add(UC_HOOK_CODE,stop)
  for i,v in enumerate([STOP,CONTEXT,t,0]):store(u,SP+i*4,v)
  u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,SCOPE)
  try:u.emu_start(self.location+0x400,STOP,count=1000000)
  except Exception as e:raise RuntimeError((hex(self.location),hex(u.reg_read(UC_X86_REG_EIP)),bytes(u.mem_read(SCOPE,16)).hex()))from e
  u.hook_del(h)
  assert seen,'did not reach native application or rejection cleanup'
  return bytes(u.mem_read(SCOPE+16,0x10a0))if seen==[True]else None
 def finish_native(self,success):
  # Controlled live-entity boundary: resume the genuine Apply epilogue with
  # its documented AL result, then execute our real wrapper/callbacks.
  u=self.u;rejected=[]
  def stop(u,a,size,user):
   if (a&0xffffffff)==0x433300c8:rejected.append(True);u.emu_stop()
  h=u.hook_add(UC_HOOK_CODE,stop);u.reg_write(UC_X86_REG_EAX,success)
  u.emu_start(0x43345eb0,STOP,count=1000000);u.hook_del(h)
  assert u.reg_read(UC_X86_REG_ESP)==SP+16
  assert rejected or u.reg_read(UC_X86_REG_EIP)==STOP
  return bool(rejected)
 def dispatcher(self,low=94,high=100,upper=102,first=True):
  u=self.u;setup_selector_model(u);direction,source=MEM+0x4000,MEM+0x4100
  length=math.sqrt(98**2+10**2);floats(u,direction,98/length,-10/length,0);floats(u,source,0,10,0)
  best,score=MEM+0x4200,MEM+0x4204;store(u,best,-1);floats(u,score,-1)
  stop=0x4332ff6b if first else 0x4332ff97
  for i,v in enumerate([stop,ACTOR,HISTORY,0,low,high,best,score]):store(u,SP+4*i,v)
  u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,source);u.reg_write(UC_X86_REG_EDX,direction)
  u.reg_write(UC_X86_REG_XMM0,fbits(10000));u.reg_write(UC_X86_REG_XMM1,fbits(float(upper)+.5))
  u.reg_write(UC_X86_REG_EBP,SP+0x1000);store(u,SP+0x1008,CONTEXT)
  run_until(u,self.location,stop,1000000);assert u.reg_read(UC_X86_REG_ESP)==SP+32
  return word(u,best)
def equal(c,t,bone=0):
 result,origin,matrix=c.point(t,bone);assert result==t,(t,hex(result))
 applied=c.applied(t);assert applied is not None
 assert struct.unpack_from('<I',applied,0x4c)[0]==t
 assert applied[0x30:0x3c]==origin and applied[0x230+bone*48:0x230+(bone+1)*48]==matrix
 return struct.unpack('<3f',origin)

checks={'coherent':0,'native_rotation_reference':0,'native_disabled':0,'bounds':0,'forecast':0,'rejections':0,'selector':0,'snapshots':0}
for address in [0x50000000,0x60000000,0xf0000000]:
 for flags in [4,0x84]:
  c=Case(address,flags=flags);c.begin()
  for t in [94,95,97,98,99,100]:
   for bone in [0,3,18]:assert equal(c,t,bone)==(float(t),0.,0.);checks['coherent']+=1
  assert c.dispatcher()==98;checks['selector']+=1
 c=Case(address);c.policy(consistent=0);c.begin();assert c.dispatcher()==98
 result,origin,matrix=c.point(98);native=c.applied(98)
 assert result==98 and struct.unpack('<3f',origin)==(98,0,0)and struct.unpack_from('<I',native,0x4c)[0]==94
 checks['native_disabled']+=1
 c=Case(address,records=((100,100,0,0),(98,98,0,0),(96,96,0,0)))
 c.policy(extrapolate=1,horizon=2);assert c.begin()==(94,102)
 assert equal(c,101)==(101,0,0)and equal(c,102)==(102,0,0);checks['forecast']+=2
 assert c.point(103)[0]==0xffffffff;checks['rejections']+=1
 c=Case(address,records=((100,96,0,0),(98,94,0,0),(96,92,0,0)))
 c.policy(extrapolate=1,horizon=2);assert c.dispatcher()==102;equal(c,102);checks['selector']+=1
for upper in [98,99,100,101,102,103]:
 c=Case(records=((100,100,0,0),(98,98,0,0),(96,96,0,0)));c.policy(extrapolate=1,horizon=2)
 low,high=c.begin(94,min(100,upper),upper);assert high<=min(upper,102)
 for t in [101,102]:assert(c.point(t)[0]==t)==(t<=high)
 checks['bounds']+=1
c=Case();c.policy(backtrack=1,age=32,consistent=0);assert c.begin(50,100)==(98,100);checks['bounds']+=1
c=Case();c.policy(limit=1,count=1,consistent=0);assert c.begin()==(100,100);checks['bounds']+=1
c=Case();c.begin();equal(c,98);c.policy(consistent=0)
c.begin(first=False);equal(c,98);c.begin(first=True);assert struct.unpack_from('<I',c.applied(98),0x4c)[0]==94;checks['snapshots']+=1
for mutation in ['wall','solid','turn','reversed','stamp','clock']:
 c=Case(records=((100,100,0,0),(98,98,0,0),(96,96,0,0)));c.policy(extrapolate=1,horizon=2);c.begin()
 if mutation=='wall':c.wall=100.5
 if mutation=='solid':c.solid=True
 if mutation=='turn':floats(c.u,NEW+0x28,20)
 if mutation=='reversed':floats(c.u,NEW+0x4000+0x30,102,0,0)
 if mutation=='stamp':store(c.u,NEW+0x4c,101)
 if mutation=='clock':floats(c.u,MEM+0x2004,103/64)
 if mutation=='clock':assert c.applied(101)is None
 else:assert c.point(101)[0]==0xffffffff,mutation
 checks['rejections']+=1
c=Case();c.begin();equal(c,98);c.begin(low=99,first=False)
assert c.point(98)[0]==0xffffffff and c.applied(98)is None;checks['rejections']+=1
for mutation in ['ring','nan_bone','teleport','gap','stop_marker']:
 c=Case(records=((100,100,0,0),(80 if mutation=='gap'else 94,94,0,0)));c.begin()
 if mutation=='ring':store(c.u,HISTORY+0x5d8,1)
 if mutation=='nan_bone':floats(c.u,NEW+0x230,float('nan'))
 if mutation=='teleport':floats(c.u,NEW+0x2000+0x30,35,0,0)
 if mutation=='stop_marker':store(c.u,NEW+0x5c,4|0x200)
 assert c.point(98)[0]==0xffffffff,mutation
 assert c.applied(98)is None,mutation
 checks['rejections']+=1
for enabled,success in [(1,1),(1,0),(0,1),(0,0)]:
 c=Case();c.policy(consistent=enabled);c.begin();assert c.applied(98)is not None
 assert c.finish_native(success)==bool(enabled and not success)
 checks['rejections']+=1
for flags in [4,0x84]:
 c=Case(flags=flags)
 for ptr,angle in [(NEW,30),(OLD,-30)]:
  cs,ss=math.cos(math.radians(angle)),math.sin(math.radians(angle))
  for k in range(4):
   for bone in range(19):
    a=ptr+0x230+k*0x3a0+bone*48;v=struct.unpack('<12f',c.u.mem_read(a,48))
    floats(c.u,a,cs,-ss,0,v[3],ss,cs,0,v[7],0,0,1,v[11])
 for t in [95,98,99]:
  get_pose(c.u,t);native=bytes(c.u.mem_read(MEM+0x3100,48));c.begin()
  actual=c.point(t)[2]
  # The original single-bone getter and full-record blend are separate
  # instruction sequences. Tiny near-zero residuals need not be bit-identical.
  assert max(abs(a-b)for a,b in zip(struct.unpack('<12f',actual),struct.unpack('<12f',native)))<=1e-6
  equal(c,t)
  checks['native_rotation_reference']+=1
report={'passed':True,'checks':checks,'clone_relative_calls':34,'timing':'capture native root XMM1 time cap; no custom tolerance',
        'native_rotation_reference_absolute_tolerance':1e-6,
        'forecast_horizon_max':2,'maximum_shift_units':16,'game_tested':False,
        'boundaries':['native helper math and entity index','TLS','engine sweep','stop before live entity application']}
(r/'reports/records_native.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

#include "../source/skeet/nl_movement.h"
#include <cassert>
#include <iomanip>
#include <iostream>
#include <limits>
#include <cstring>
using namespace nl_movement;
extern "C" unsigned nl_movement_api_version();
extern "C" unsigned nl_movement_input_size();
extern "C" unsigned nl_movement_output_size();
extern "C" int nl_movement_calculate(const Input*,Output*);
int main(int argc,char** argv) {
    assert(nl_movement_api_version()==1&&nl_movement_input_size()==sizeof(Input)&&
           nl_movement_output_size()==sizeof(Output));
    if(argc==2&&std::strcmp(argv[1],"--calculate")==0) {
        Input a{1,sizeof(Input),0,0,2,0,0,0,0,-10,0,0,0,0,50,450};
        std::cout<<std::setprecision(10);
        while(std::cin>>a.vx>>a.vy>>a.yaw>>a.pitch>>a.forward>>a.side>>a.smoothing>>a.side_speed>>a.phase) {
            Output b{};b.bytes=sizeof(b);
            const int result=nl_movement_calculate(&a,&b);
            std::cout<<result<<' '<<b.move_yaw<<' '<<b.side<<' '<<b.ideal<<' '<<b.correction<<'\n';
        }
        return 0;
    }
    if(argc==2&&std::strcmp(argv[1],"--steer")==0) {
        float vx,vy,yaw,smooth,side;int phase,wasd;
        std::cout<<std::setprecision(10);
        while(std::cin>>vx>>vy>>yaw>>smooth>>side>>phase>>wasd) {
            const auto s=steer(vx,vy,yaw,smooth,side,phase!=0,wasd!=0);
            std::cout<<s.yaw<<' '<<s.side<<' '<<s.ideal<<' '<<s.correction<<'\n';
        }
        return 0;
    }
    Input a{1,sizeof(Input),0,0,2,0,0,300,0,-10,0,0,0,0,50,450};
    Output b{};b.bytes=sizeof(b);
    assert(nl_movement_calculate(&a,&b)==1&&b.handled&&b.forward==0&&b.side==450);
    const auto original=a;unsigned cases=1;
    for(int phase=0;phase<2;phase++)for(int smooth:{0,50,100})
      for(float speed:{0.f,1.f,80.f,80.001f,300.f,2000.f})
        for(float yaw:{-180.f,-90.f,0.f,90.f,180.f}) {
            a=original;a.phase=phase;a.smoothing=float(smooth);a.vx=speed;a.yaw=yaw;
            assert(calculate(&a,&b)==1&&finite(b.move_yaw)&&b.move_yaw>=-180&&b.move_yaw<=180);
            assert(std::fabs(b.side)==450);++cases;
        }
    for(int guard=0;guard<5;guard++) {
        a=original;
        if(guard==0)a.flags=1;
        if(guard==1)a.move_type=9;
        if(guard==2)a.water_level=2;
        if(guard==3)a.buttons=1u<<17;
        if(guard==4)a.vx=a.vy=a.vz=0;
        assert(calculate(&a,&b)==0&&!b.handled);++cases;
    }
    a=original;a.flags=2;assert(calculate(&a,&b)==1);++cases;
    for(int invalid=0;invalid<5;invalid++) {
        a=original;
        if(invalid==0)a.vx=std::numeric_limits<float>::quiet_NaN();
        if(invalid==1)a.side_speed=451;
        if(invalid==2)a.smoothing=-1;
        if(invalid==3)a.phase=2;
        if(invalid==4)a.pitch=90;
        std::memset(&b,0x5a,sizeof(b));b.bytes=sizeof(b);auto saved=b;
        assert(calculate(&a,&b)<0&&std::memcmp(&saved,&b,sizeof(b))==0);++cases;
    }
    a=original;a.version=2;assert(calculate(&a,&b)==-2);++cases;
    std::cout<<cases<<" native core boundary and host guard cases passed\n";
}

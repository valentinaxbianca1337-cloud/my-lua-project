"""Exercise the production frame entry when the render receiver is not chain head.
The native constructor/allocator boundaries match validate_improved_native.py.
No loader or game process is executed.
"""
from pathlib import Path
import importlib.util,json,struct
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_ECX,UC_X86_REG_EAX,UC_X86_REG_EIP,UC_X86_REG_ESP

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fixture',root/'tests/validate_improved_native.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
pe=pefile.PE(str(root/'build/improved_frame_probe.dll'))
f.pe=pe;f.PB=pe.OPTIONAL_HEADER.ImageBase
f.symbols={s.name.decode():f.PB+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
frames=[]
core=(root/'source/skeet/Binary/skeet.bin').read_bytes()
stores=[0x43487f92,0x43488852,0x43489360,0x4348b030,0x4348bf60,
        0x4348cb5f,0x4348cf3f,0x4348d31b,0x4348d35f]
native_mapping=[]
for address in stores:
 ins=core[address-0x43310000:address-0x43310000+6]
 assert ins[0]==0x89 and ins[1]&0xc0==0x80
 native_mapping.append((struct.unpack('<I',ins[2:6])[0]-0xb4)//4)
assert native_mapping==[0,6,1,2,3,4,5,7,8]
for different_head,extra_lua_tab,semantic_permutation in __import__('itertools').product([False,True],repeat=3):
  u,s,word,put,floats,call,original=f.machine(1.25,32)
  chain=f.MEM+0x8000;head=f.MEM+0x9000
  put(chain,f.RENDERER);put(chain+0x10,head if different_head else f.MENU)
  if semantic_permutation:
   # Native constructor insertion ordinals are stored in these semantic slots.
   mapping=native_mapping
   for ordinal,semantic in enumerate(mapping):
    put(f.MENU+0xb4+4*semantic,original[ordinal])
    put(original[ordinal]+0x24,int((5+64*semantic)*1.25))
  original_order=sorted(original,key=lambda t:word(t+0x24))
  lookup=bytes(u.mem_read(f.MENU+0xb4,36))
  # Deliberately no Visuals/Lua children: the tab must not depend on them.
  if extra_lua_tab:
   foreign=f.MEM+0x7000;foreign_vt=f.MEM+0x6000
   u.mem_write(foreign,bytes(u.mem_read(original[0],0x100)))
   u.mem_write(foreign_vt,bytes(u.mem_read(f.TVT,24*4)))
   put(foreign,foreign_vt);put(foreign+0xc,9)
   put(f.TABS+36,foreign);put(f.MENU+0x58,f.TABS+40)
  # Original frame is controlled here; native icon rendering is tested separately.
  native_draw=f.API+0x240;u.mem_write(native_draw,b'\xc2\x04\x00')
  args=[f.MENU,chain,native_draw,f.ALLOC,f.FREE,f.CTOR,f.CHILD,f.APPEND]
  value=call('improved_production_frame',args)
  assert value==5,(different_head,extra_lua_tab,value)  # legacy ready false, now Active
  n=10+int(extra_lua_tab)
  assert word(f.MENU+0x58)-word(f.MENU+0x54)==4*n
  if extra_lua_tab:assert word(foreign)==foreign_vt
  custom=word(word(f.MENU+0x54)+4*(n-1))
  assert word(original_order[0]+0x24)<word(custom+0x24)<word(original_order[1]+0x24)
  assert sorted(original,key=lambda t:word(t+0x24))==original_order
  assert bytes(u.mem_read(f.MENU+0xb4,36))==lookup
  assert [word(t+0xc)for t in original]==list(range(9))
  for changed in [.75,2.,1.25]:
   floats(0x4346d490,changed)
   put(f.MENU+0x14,int(800*changed));put(f.MENU+0x18,int(700*changed))
   for t in original:put(t+0x8c,int(44*changed));put(t+0x90,int(44*changed))
   call('improved_frame_geometry')
   assert sorted(original,key=lambda t:word(t+0x24))==original_order
   assert word(original_order[0]+0x24)<word(custom+0x24)<word(original_order[1]+0x24)
   assert bytes(u.mem_read(f.MENU+0xb4,36))==lookup
  frames.append({'different_chain_head':different_head,'foreign_lua_tab':extra_lua_tab,
                 'native_semantic_permutation':semantic_permutation,
                 'visual_order_preserved':True,'legacy_ready':False,'improved_active':True})

rejections=[]
for bad in ['parent','index','lookup','count']:
 u,s,word,put,floats,call,original=f.machine(1.,32)
 chain=f.MEM+0x8000;put(chain,f.RENDERER);put(chain+0x10,f.MEM+0x9000)
 if bad=='parent':put(original[1]+0x60,0)
 if bad=='index':put(original[1]+0xc,42)
 if bad=='lookup':put(f.MENU+0xb4,0x12345678)
 if bad=='count':put(f.MENU+0x58,f.TABS+32)
 native_draw=f.API+0x240;u.mem_write(native_draw,b'\xc2\x04\x00')
 assert call('improved_production_frame',[f.MENU,chain,native_draw,f.ALLOC,f.FREE,f.CTOR,f.CHILD,f.APPEND])==2
 assert s['alloc']==0
 rejections.append(bad)

# Full derived vtables must preserve every method outside four overrides.
# Swap the baseline fixture tab between native classes with 15,24,31 entries.
spec2=importlib.util.spec_from_file_location('native_fixture',root/'tests/validate_improved_native.py')
g=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(g)
for table,count in [(0x4346ed5c,15),(0x4346f9c8,24),(0x43470094,31)]:
 u,s,word,put,floats,call,original=g.machine(1.,32)
 put(original[0],table)
 before=[word(table+4*i)for i in range(count)]
 assert call('improved_construct',[g.MENU,g.ALLOC,g.FREE,g.CTOR,g.CHILD,g.APPEND])==1
 clone=word(original[0]);assert clone!=table
 for i in range(count):
  if i not in [1,4,9,10]:assert word(clone+4*i)==before[i],(count,i)

result={'passed':True,'production_frame_cases':frames,'full_vtable_lengths_preserved':[15,24,31],
        'native_creation_semantic_slots':native_mapping,'production_frame_dpi_changes':len(frames)*3,
        'invalid_native_windows_rejected_without_allocation':rejections,
        'foreign_lua_vtable_untouched':True,'game_tested':False,
        'boundaries':['allocation/constructors','original frame draw','child callbacks']}
(root/'reports/improved_frame.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

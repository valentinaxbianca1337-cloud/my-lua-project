"""Adversarial x86 callback ABI check: caller state, FP state, stack alignment.
Executes emitted machine code with deliberately clobbering callback boundaries.
"""
import json,struct,subprocess
from pathlib import Path
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(__file__).resolve().parents[1];core=(r/'source/skeet/Binary/skeet.bin').read_bytes();base=0x43310000
mem=0x200000;cb=0x600000;sp=mem+0x9000;stop=cb+0x1000
regs=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]
xmms=[UC_X86_REG_XMM0+i for i in range(8)]
checks=0
for location in [0x50000000,0xf0000000]:
 out=r/'build'/f'bridge_{location:x}.bin'
 subprocess.run([str(r/'build/records_plan'),str(r/'source/skeet/Binary/skeet.bin'),str(out),hex(location),*[hex(cb+i*0x100)for i in range(5)]],check=True,capture_output=True)
 data=out.read_bytes()
 for mode,result in [('dispatch',0),('apply',0),('apply',1),('apply',0xffffffff)]:
  for alignment in [0,4,8,12]:
   u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(base,len(core));u.mem_write(base,core)
   u.mem_map(mem,0x10000);u.mem_map(cb,0x2000);u.mem_map(location,8192);u.mem_write(location,data[:8192])
   put=lambda a,v:u.mem_write(a,struct.pack('<I',v&0xffffffff))
   word=lambda a:struct.unpack('<I',u.mem_read(a,4))[0]
   stack=sp+alignment;frame=mem+0x2000
   u.mem_write(cb+0x1800,b'\xdb\xe3\xd9\xe8\xd9\xeb') # initialize x87; 1; pi
   u.emu_start(cb+0x1800,cb+0x1806,count=3)
   for i,reg in enumerate(regs):u.reg_write(reg,frame if reg==UC_X86_REG_EBP else(0x11223300+i))
   for i,reg in enumerate(xmms):u.reg_write(reg,(0x123456789abcdef00123456789abcdef+i)&((1<<128)-1))
   u.reg_write(UC_X86_REG_XMM1,struct.unpack('<I',struct.pack('<f',123.5))[0])
   u.reg_write(UC_X86_REG_MXCSR,0x3f80);u.reg_write(UC_X86_REG_EFLAGS,0x246)
   u.reg_write(UC_X86_REG_ESP,stack);put(frame+8,mem+0x1000)
   for i in range(10):put(stack+4*i,0xabc000+i)
   # Legacy apply comparison and saved locals consumed by enhanced success.
   if mode=='apply':
    u.reg_write(UC_X86_REG_ESI,mem+0x3000);put(mem+0x304c,u.reg_read(UC_X86_REG_ECX));put(stack+0x50,0x11111);put(stack+0x58,0x22222)
   expected={reg:u.reg_read(reg)for reg in regs+xmms+[UC_X86_REG_MXCSR,UC_X86_REG_EFLAGS,UC_X86_REG_FPCW,UC_X86_REG_FPSW,UC_X86_REG_FPTAG,UC_X86_REG_ST0,UC_X86_REG_ST1]}
   target=0x433983bb if mode=='dispatch'else(0x43344d57 if result==0 else(0x43345b83 if result==1 else 0x43345eae))
   observed=[]
   def hook(u,a,size,user):
    a&=0xffffffff
    if a==target:observed.append(True);u.emu_stop();return
    if a not in [cb,cb+0x100]:return
    esp=u.reg_read(UC_X86_REG_ESP);assert esp%16==12
    if mode=='dispatch':assert [word(esp+i)for i in [4,8,12]]==[mem+0x1000,stack,123]
    else:assert [word(esp+i)for i in [4,8]]==[stack,frame]
    for reg in regs+xmms:u.reg_write(reg,0xdeadbeef)
    u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_MXCSR,0x1f80);u.reg_write(UC_X86_REG_EFLAGS,0x202)
    # Native instructions clear the x87 stack before returning to the bridge.
   u.hook_add(UC_HOOK_CODE,hook)
   u.mem_write(cb,b'\xdb\xe3\xc3');u.mem_write(cb+0x100,b'\xdb\xe3\xc3')
   u.emu_start(location+(0 if mode=='dispatch'else 0x200),stop,count=10000)
   assert observed and u.reg_read(UC_X86_REG_ESP)==stack
   if mode=='apply'and result==1:expected[UC_X86_REG_ESI]=0x11111;expected[UC_X86_REG_EDI]=0x22222
   # The replayed native CMP changes flags in the legacy branch.
   if mode=='apply'and result==0:expected.pop(UC_X86_REG_EFLAGS)
   for reg,value in expected.items():assert u.reg_read(reg)==value,(hex(location),mode,result,alignment,reg,hex(u.reg_read(reg)),hex(value))
   checks+=1
report={'passed':True,'callback_state_cases':checks,'stack_alignments':[0,4,8,12],'checks':['GPR','XMM0-7','MXCSR','x87 control/status/tag/ST0/ST1','EFLAGS except replayed CMP','callback stack alignment','native continuations'],'game_executed':False}
(r/'reports/record_bridges.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

#include "../source/skeet/hitscan_hook.h"
#include <fstream>
#include <vector>
#include <iterator>
#include <cassert>
int main(int argc,char**argv){
 if(argc!=5)return 2;std::ifstream f(argv[1],std::ios::binary);std::vector<unsigned char>image((std::istreambuf_iterator<char>(f)),{});
 hitscan_hook::Plan p{};unsigned location=std::stoul(argv[3],nullptr,0),cb=std::stoul(argv[4],nullptr,0);
 if(!hitscan_hook::make_plan(image.data(),image.size(),location,cb,p))return 3;
 for(unsigned site:{0x4eef6,0x4cd37,0x55490,0x86e24}){
  image[site]^=1;hitscan_hook::Plan bad{};assert(!hitscan_hook::make_plan(image.data(),image.size(),location,cb,bad));image[site]^=1;
 }
 std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<char*>(p.code),256);out.write(reinterpret_cast<char*>(p.jump),7);
}

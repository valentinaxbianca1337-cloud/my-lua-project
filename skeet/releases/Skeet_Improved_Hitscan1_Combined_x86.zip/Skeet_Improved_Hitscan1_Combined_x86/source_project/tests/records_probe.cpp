#include <windows.h>
#include "../source/skeet/record_runtime.h"
extern "C" {
__declspec(dllexport) record_runtime::Local records_fixture{};
__declspec(dllexport) void initialize_records_probe(unsigned blend,unsigned sweep,unsigned return_address) {
    record_runtime::tls_slot=7;record_runtime::application_return=return_address;
    record_runtime::api={reinterpret_cast<record_session::Blend>(blend),reinterpret_cast<record_session::Sweep>(sweep)};
}
__declspec(dllexport) void records_policy_probe(unsigned policy) {record_options::policy.store(policy);}
__declspec(dllexport) void begin_records_probe(void* context,unsigned* args,int upper){record_runtime::begin(context,args,upper);}
__declspec(dllexport) int __fastcall getter_records_probe(const void* h,int t,int b,void* o,void* m){return record_runtime::getter(h,t,b,o,m);}
__declspec(dllexport) int apply_records_probe(void* a,void* b){return record_runtime::apply_prepared(a,b);}
__declspec(dllexport) void reset_records_probe(void* context){record_runtime::reset_apply(context);}
__declspec(dllexport) int rejected_records_probe(unsigned result){return record_runtime::rejected_apply(result);}
__declspec(dllexport) unsigned rejected_offset_probe(){return offsetof(record_runtime::Local,rejected_apply);}
}

#include "../source/skeet/nl_movement_v2.h"
#include <cassert>
#include <cstring>
#include <iostream>
#include <limits>
using namespace nl_movement_v2;
using namespace nl_prediction;
Input input() {
    return {2,sizeof(Input),WASD,0,1,0,2,0,0,300,0,-10,0,0,450,0,50,450,
        {0,0,100},{-16,-16,0},{16,16,72},1.f/64,800,12,30,320,301.99338f,1,0};
}
int main() {
    unsigned cases=0;
    auto open=[](Vec a,Vec b,Vec,Vec,Trace& out){out={1,b,{},false,false};return true;};
    auto missing=[](Vec,Vec,Vec,Vec,Trace&){return false;};
    Input a=input();Output b{};b.bytes=sizeof(b);
    for(unsigned mode:{Normal,WASD,Directional})for(float tick:{1.f/64,1.f/128}) {
        a=input();a.mode=mode;a.interval=tick;
        assert(calculate(&a,&b,open)==1&&b.handled&&b.mode==mode&&b.status==0);
        if(mode==Directional)assert(b.traces>0&&b.traces<=1536&&b.horizon>0);
        else assert(b.traces==0);
        assert(std::fabs(b.side)==450);++cases;
    }
    a=input();a.mode=Directional;
    assert(calculate(&a,&b,missing)==1&&b.handled&&b.mode==WASD&&b.status==1&&std::fabs(b.side)==450);++cases;
    auto bad=[](Vec,Vec,Vec,Vec,Trace& out){out.fraction=std::numeric_limits<float>::quiet_NaN();return true;};
    assert(calculate(&a,&b,bad)==1&&b.mode==WASD&&b.status==3);++cases;
    a.interval=1.f/256;
    assert(calculate(&a,&b,open)==1&&b.mode==WASD&&b.status==2&&b.traces<=1536);++cases;
    // Plane clipping and floor contacts in a deterministic host geometry.
    unsigned contacts=0;
    auto floor=[&](Vec start,Vec end,Vec mins,Vec maxs,Trace& out){
        out={1,end,{},false,false};
        if(end.z<0&&start.z>=0) {
            out.fraction=start.z/(start.z-end.z);out.end=start+(end-start)*out.fraction;
            out.normal={0,0,1};++contacts;
        }
        return true;
    };
    a=input();a.mode=Directional;a.origin={0,0,1};a.vz=-50;
    assert(calculate(&a,&b,floor)==1&&b.status==0&&contacts>0);++cases;
    unsigned hits=0;
    auto wall=[&](Vec start,Vec end,Vec mins,Vec maxs,Trace& out){
        out={1,end,{},false,false};const float plane=65-maxs.x;
        if(end.x>plane&&start.x<=plane){out.fraction=(plane-start.x)/(end.x-start.x);out.end=start+(end-start)*out.fraction;out.normal={-1,0,0};++hits;}
        return true;
    };
    a=input();a.mode=Directional;
    assert(calculate(&a,&b,wall)==1&&b.handled&&hits>0&&b.probes>1&&b.traces<=1536);++cases;
    // Unsupported host states do not trace or produce command output.
    for(int state=0;state<4;state++) {
        a=input();a.mode=Directional;
        if(state==0)a.flags=1;if(state==1)a.move_type=9;if(state==2)a.water_level=2;if(state==3)a.buttons=1u<<17;
        unsigned called=0;auto trace=[&](Vec,Vec,Vec,Vec,Trace&){++called;return false;};
        assert(calculate(&a,&b,trace)==0&&!b.handled&&called==0);++cases;
    }
    for(int guard=0;guard<7;guard++) {
        a=input();a.mode=Directional;
        if(guard==0)a.origin.x=std::numeric_limits<float>::infinity();
        if(guard==1)a.interval=0;if(guard==2)a.entity_index=65;if(guard==3)a.mins.x=1000;
        if(guard==4)a.mode=3;if(guard==5)a.version=1;if(guard==6)a.side_speed=451;
        const auto old=b;assert(calculate(&a,&b,open)<0&&std::memcmp(&b,&old,sizeof(b))==0);++cases;
    }
    std::cout<<"{\"passed\":true,\"cases\":"<<cases<<",\"scope\":\"adapted host prediction and v2 bridge\",\"game_tested\":false}\n";
}

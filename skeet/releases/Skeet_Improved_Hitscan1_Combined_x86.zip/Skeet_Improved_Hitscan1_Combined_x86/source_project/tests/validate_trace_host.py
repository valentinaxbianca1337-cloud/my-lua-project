"""Actual x86 Source TraceRay calling convention with controlled interface factories.
Validates Ray_t/filter ABI; does not call the real game engine.
"""
from pathlib import Path
import struct,json
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(__file__).resolve().parents[1];p=pefile.PE(str(r/'build/trace_host_probe.dll'))
base=p.OPTIONAL_HEADER.ImageBase;u=Uc(UC_ARCH_X86,UC_MODE_32)
u.mem_map(base,(p.OPTIONAL_HEADER.SizeOfImage+4095)&~4095);u.mem_write(base,p.get_memory_mapped_image())
mem=0x70000000;api=0x70100000;stop=api+0xfff0;sp=mem+0xf000
u.mem_map(mem,0x100000);u.mem_map(api,0x10000)
engine=mem+0x1000;elist=mem+0x2000;entity=mem+0x3000
evt=mem+0x1100;cvt=mem+0x2100;put=lambda a,v:u.mem_write(a,struct.pack('<I',v))
word=lambda a:struct.unpack('<I',u.mem_read(a,4))[0]
vec=lambda a:struct.unpack('<3f',u.mem_read(a,12))
put(engine,evt);put(elist,cvt)
ef,cf,getent,trace=api+0x100,api+0x120,api+0x140,api+0x160
put(evt+5*4,trace);put(cvt+3*4,getent)
def string(a):return bytes(u.mem_read(a,80)).split(b'\0')[0].decode()
def wide(a):return bytes(u.mem_read(a,80)).decode('utf-16-le').split('\0')[0]
def ret(stack,result=0,args=0):
 target=word(stack);u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,stack+4+args);u.reg_write(UC_X86_REG_EIP,target)
imports={}
for lib in p.DIRECTORY_ENTRY_IMPORT:
 for item in lib.imports:
  a=api+0x1000+len(imports)*16;put(item.address,a);imports[a]=item.name.decode()if item.name else '#'+str(item.ordinal)
observed={};available=True
def hook(machine,address,size,user):
 global observed
 if address==stop:u.emu_stop();return
 if address not in imports and address not in [ef,cf,getent,trace]:return
 stack=u.reg_read(UC_X86_REG_ESP);this=u.reg_read(UC_X86_REG_ECX)
 if address in imports:
  name=imports[address]
  if name=='GetModuleHandleW':
   module=wide(word(stack+4));assert module in ['engine.dll','client.dll'];ret(stack,0xe001 if module=='engine.dll'else 0xc001,4);return
  if name=='GetProcAddress':
   assert string(word(stack+8))=='CreateInterface';ret(stack,ef if word(stack+4)==0xe001 else cf,8);return
  if name in ['memset','memcpy','memmove']:
   dst,src,n=[word(stack+i)for i in [4,8,12]];u.mem_write(dst,bytes([src&255])*n if name=='memset'else bytes(u.mem_read(src,n)));ret(stack,dst);return
  raise AssertionError(name)
 if address==ef:assert string(word(stack+4))=='EngineTraceClient004';ret(stack,engine if available else 0);return
 if address==cf:assert string(word(stack+4))=='VClientEntityList003';ret(stack,elist);return
 if address==getent:assert this==elist and word(stack+4)==1;ret(stack,entity,4);return
 assert address==trace and this==engine
 ray,mask,filter_,output=[word(stack+i)for i in [4,8,12,16]]
 assert ray%16==0 and mask==0x201400b
 observed={'start':vec(ray),'delta':vec(ray+16),'offset':vec(ray+32),'extents':vec(ray+48),
           'filter':filter_,'filter_table':word(filter_),'skip':word(filter_+4),
           'is_ray':bytes(u.mem_read(ray+68,1))[0],'swept':bytes(u.mem_read(ray+69,1))[0]}
 assert observed['skip']==entity and word(ray+64)==0
 end=tuple(observed['start'][i]+observed['offset'][i]+observed['delta'][i]for i in range(3))
 u.mem_write(output+12,struct.pack('<3f',*end));u.mem_write(output+24,struct.pack('<3f',0,0,1));u.mem_write(output+44,struct.pack('<f',.5))
 ret(stack,0,16)
u.hook_add(UC_HOOK_CODE,hook)
symbols={s.name.decode():base+s.address for s in p.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def call(address,args,this=None,clean=0,stack=sp):
 for i,v in enumerate([stop,*args]):put(stack+4*i,v)
 u.reg_write(UC_X86_REG_ESP,stack)
 if this is not None:u.reg_write(UC_X86_REG_ECX,this)
 u.emu_start(address,stop,count=20000)
 assert u.reg_read(UC_X86_REG_EIP)==stop and u.reg_read(UC_X86_REG_ESP)==stack+4+clean
 return u.reg_read(UC_X86_REG_EAX)
params=mem+0x4000
for i,v in enumerate([(10,20,30),(110,70,20),(-16,-16,0),(16,16,72)]):u.mem_write(params+i*16,struct.pack('<3f',*v))
args=[1,params,params+16,params+32,params+48,params+80]
assert call(symbols['trace_host_probe'],args)==1
assert observed['start']==(10,20,66)and observed['delta']==(100,50,-10)
assert observed['offset']==(0,0,-36)and observed['extents']==(16,16,36)
assert observed['is_ray']==0 and observed['swept']==1
filter_=observed['filter'];table=observed['filter_table']
assert call(word(table),[entity,0],this=filter_,clean=8,stack=mem+0xd000)&255==0
assert call(word(table),[entity+100,0],this=filter_,clean=8,stack=mem+0xd000)&255==1
assert call(word(table+4),[],this=filter_,stack=mem+0xd000)==0
assert struct.unpack('<f',u.mem_read(params+80,4))[0]==.5
assert vec(params+84)==(110,70,20)and vec(params+96)==(0,0,1)
available=False;assert call(symbols['trace_host_probe'],args)==0xffffffff
result={'passed':True,'native_x86_trace_ray_and_filter_abi':True,'ray_layout_bytes':80,'trace_layout_bytes':84,
        'trace_mask':'0x201400b','missing_interface_fails':True,'game_engine_executed':False}
(r/'reports/trace_host.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

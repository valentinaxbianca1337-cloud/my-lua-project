#include "../source/skeet/hitscan_points.h"
#include <iostream>
#include <iomanip>
#include <cassert>
using namespace hitscan_points;
int main(int argc,char**argv){
 std::cout<<std::setprecision(10);
 Capsule s{};Vec eye{};float scale;
 while(std::cin>>s.a.x>>s.a.y>>s.a.z>>s.b.x>>s.b.y>>s.b.z>>s.radius>>s.index>>eye.x>>eye.y>>eye.z>>scale){
  s.group=3;Vec p[3];const unsigned n=nl_pattern(s,eye,scale,p);std::cout<<n;for(unsigned i=0;i<n;i++)std::cout<<' '<<p[i].x<<' '<<p[i].y<<' '<<p[i].z;std::cout<<'\n';
 }
}

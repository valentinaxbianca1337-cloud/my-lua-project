"""Compare the generic NL capsule point-pattern instructions with the portable port.
Usage: python tests/compare_nl_hitscan.py /path/to/nl.image.bin
Auto-scale and the external client clipping routine are controlled boundaries.
The clipping oracle uses bisection; the port uses analytic intersection.
"""
from pathlib import Path
import struct,math,json,hashlib,subprocess,sys,random
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(__file__).resolve().parents[1];data=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(data).hexdigest()=='f8b25eacb0a7269a1ce82a8816c8f84bf0c1fb1cfb58a75583973e01f503d4e3'
base=0x412a0000;mem=0x200000;sp=mem+0xf000;stop=mem+0xff00
u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(base,len(data));u.mem_write(base,data);u.mem_map(mem,0x200000)
shape=mem+0x1000;context=mem+0x2000;state=mem+0x2100;out=mem+0x3000;points=mem+0x4000;eye=mem+0x7000;local=mem+0x10000;weapon=mem+0x20000
put=lambda a,v:u.mem_write(a,struct.pack('<I',v&0xffffffff))
word=lambda a:struct.unpack('<I',u.mem_read(a,4))[0]
floats=lambda a,*v:u.mem_write(a,struct.pack('<'+'f'*len(v),*v))
vec=lambda a:struct.unpack('<3f',u.mem_read(a,12))
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
floats(shape,1,0,0,0,0,1,0,0,0,0,1,0);put(context+4,state);put(state+0x80,1)
put(0x424f639c,local);put(local+0x5d64,weapon);put(weapon+0x2cc,0);put(local+0x605c,0x3f)
u.mem_write(0x4149ed20,b'\xd9\x05'+struct.pack('<I',mem+0x8000)+b'\xc3')
u.mem_write(0x41da7c5c,b'\xc3');u.mem_write(mem+0xa000,b'\xc3')
clip_calls=0;external_targets=set()
def clip(start,delta,a,b,radius):
 def position(t):return tuple(start[k]+delta[k]*t for k in range(3))
 def distance(v):
  ba=tuple(b[k]-a[k]for k in range(3));den=sum(x*x for x in ba)
  t=max(0.,min(1.,sum((v[k]-a[k])*ba[k]for k in range(3))/den))if den else 0
  return sum((v[k]-a[k]-ba[k]*t)**2 for k in range(3))
 if distance(start)<=radius*radius:return 0.,start
 lo,hi=0.,1.
 assert distance(position(1))<=radius*radius+1e-3
 for _ in range(65):
  t=(lo+hi)/2
  if distance(position(t))>radius*radius:lo=t
  else:hi=t
 return hi,position(hi)
def hook(u,a,size,user):
 global clip_calls
 if a==stop:u.emu_stop();return
 if a==mem+0xa000:
  stack=u.reg_read(UC_X86_REG_ESP);result=u.reg_read(UC_X86_REG_ECX);start=u.reg_read(UC_X86_REG_EDX)
  delta,cap,radius=word(stack+4),word(stack+8),struct.unpack('<f',u.mem_read(stack+12,4))[0]
  t,p=clip(vec(start),vec(delta),vec(cap),vec(cap+12),radius);floats(result,t,*p);u.reg_write(UC_X86_REG_EAX,1);clip_calls+=1;return
 if a in [0x41491380,0x4149141e,0x4149150e]:external_targets.add(hex(u.reg_read(UC_X86_REG_EAX)));u.reg_write(UC_X86_REG_EAX,mem+0xa000)
u.hook_add(UC_HOOK_CODE,hook)
def original(case):
 ax,ay,az,bx,by,bz,radius,index,ex,ey,ez,scale=case
 floats(shape+0x30,ax,ay,az,bx,by,bz,radius);put(shape+0x4c,int(index));floats(eye,ex,ey,ez);floats(mem+0x8000,scale)
 put(out,points);put(out+4,points);put(out+8,points+80*16)
 for i,v in enumerate([stop,shape,context,out,eye]):put(sp+4*i,v)
 u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_MXCSR,0x1f80);u.reg_write(UC_X86_REG_FPCW,0x37f)
 u.emu_start(0x41490fa0,stop,count=1000000)
 assert u.reg_read(UC_X86_REG_EIP)==stop and u.reg_read(UC_X86_REG_ESP)==sp+4
 return [vec(a)for a in range(points+80,word(out+4),80)] # center retained by GS
cases=[];rng=random.Random(880224)
for index in range(19):
 for e in [(100,0,10),(0,100,20),(0,0,100),(0,0,-100),(-80,-40,0)]:cases.append((0,0,-10,0,0,10,5,index,*e,.5))
for n in range(240):
 a=tuple(rng.uniform(-128,128)for _ in range(3));b=tuple(a[k]+rng.uniform(-20,20)for k in range(3));e=tuple(a[k]+rng.uniform(40,160)for k in range(3))
 cases.append((*a,*b,rng.uniform(1,8),rng.choice([0,3,4,5,6,7,8,9,10,11,12,15,16,17,18]),*e,rng.uniform(.1,.95)))
cases=[tuple(int(v)if i==7 else f32(v)for i,v in enumerate(c))for c in cases]
payload=''.join(' '.join(map(str,c))+'\n'for c in cases)
p=subprocess.run([str(r/'build/hitscan_points_probe')],input=payload,text=True,capture_output=True,check=True)
worst=0.
for c,line in zip(cases,p.stdout.splitlines(),strict=True):
 values=line.split();n=int(values[0]);actual=list(map(float,values[1:]));expect=original(c)
 assert len(expect)==n,(c,n,expect)
 error=max([abs(a-b)for a,b in zip(actual,[x for p in expect for x in p],strict=True)]+[0]);worst=max(worst,error)
 assert error<.0004,(c,error,actual,expect)
report={'passed':True,'cases':len(cases),'max_absolute_coordinate_error':worst,'tolerance':.0004,'kernel':'NL41490FA0 generic capsule pattern','clipping_calls':clip_calls,'external_client_targets':sorted(external_targets),'boundaries':['NL weapon/spread scale replaced by a supplied scale','missing external Source capsule clipping replaced by independent bisection','stack-cookie helper'],'complete_neverlose_hitscan':False,'game_tested':False}
(r/'reports/hitscan_nl_pattern.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

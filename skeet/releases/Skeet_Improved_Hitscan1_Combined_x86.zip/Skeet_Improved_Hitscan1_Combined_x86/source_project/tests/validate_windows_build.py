"""Inspect built Windows artifacts and execute only pure movement exports in Unicorn.
Never executes DLL entry, injector, loader, game callbacks or networking.
"""
from pathlib import Path
import hashlib,json,math,random,struct,subprocess,sys
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
PROJECT=Path(__file__).resolve().parents[1];BUILD=PROJECT/'build'
pe=pefile.PE(str(BUILD/'skeet.dll'));injector=pefile.PE(str(BUILD/'injector.exe'))
assert pe.FILE_HEADER.Machine==injector.FILE_HEADER.Machine==0x14c
assert pe.FILE_HEADER.Characteristics&0x2000 and not injector.FILE_HEADER.Characteristics&0x2000
symbols={s.name.decode():s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
for name in ['nl_movement_api_version','nl_movement_input_size','nl_movement_output_size','nl_movement_calculate','skeet_loader_status']:assert name in symbols,name
base=pe.OPTIONAL_HEADER.ImageBase;u=Uc(UC_ARCH_X86,UC_MODE_32)
u.mem_map(base,(pe.OPTIONAL_HEADER.SizeOfImage+4095)&~4095);u.mem_write(base,pe.get_memory_mapped_image())
MEM=0x70000000;STOP=MEM+0x1000;INPUT=MEM+0x2000;OUTPUT=MEM+0x3000;DOUBLE=MEM+0x4000;SP=MEM+0xf000
u.mem_map(MEM,0x30000)
imports={}
for library in pe.DIRECTORY_ENTRY_IMPORT:
 for item in library.imports:
  target=MEM+0x10000+len(imports)*16
  u.mem_write(item.address,struct.pack('<I',target))
  name=item.name.decode() if item.name else '#'+str(item.ordinal)
  imports[target]=library.dll.decode()+'!'+name
  u.mem_write(target,bytes.fromhex('dd05')+struct.pack('<I',DOUBLE)+b'\xc3')
math_calls=0
def hook(machine,address,size,user):
 global math_calls
 if address==STOP:u.emu_stop();return
 if address in imports:
  assert imports[address].endswith('!atan2'),imports[address]
  sp=u.reg_read(UC_X86_REG_ESP);a,b=struct.unpack('<dd',u.mem_read(sp+4,16))
  u.mem_write(DOUBLE,struct.pack('<d',math.atan2(a,b)));math_calls+=1
u.hook_add(UC_HOOK_CODE,hook)
def call(name,args=()):
 u.mem_write(SP,struct.pack('<'+'I'*(len(args)+1),STOP,*args))
 u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_MXCSR,0x1f80)
 u.reg_write(UC_X86_REG_FPCW,0x37f)
 u.emu_start(base+symbols[name],STOP,count=30000)
 assert u.reg_read(UC_X86_REG_EIP)==STOP
 assert u.reg_read(UC_X86_REG_ESP)==SP+4 # cdecl leaves argument cleanup to caller
 return u.reg_read(UC_X86_REG_EAX)
assert call('nl_movement_api_version')==1
assert call('nl_movement_input_size')==64
assert call('nl_movement_output_size')==28
rng=random.Random(880223)
cases=[]
for _ in range(300):
 speed=rng.uniform(.01,2200);heading=rng.uniform(-math.pi,math.pi)
 cases.append((speed*math.cos(heading),speed*math.sin(heading),rng.uniform(-180,180),
               rng.choice([-89.,0.,89.]),rng.choice([-450.,0.,450.]),rng.choice([-450.,0.,450.]),rng.randrange(101),450.,rng.randrange(2)))
# Match the exact float input conversion used by the native ABI and portable C++ parser.
cases=[tuple(struct.unpack('<f',struct.pack('<f',x))[0] if i<8 else x for i,x in enumerate(c)) for c in cases]
payload=''.join(' '.join(map(str,c))+'\n' for c in cases)
p=subprocess.run([str(BUILD/'nl_movement_probe'),'--calculate'],input=payload,text=True,capture_output=True,check=True)
rows=p.stdout.splitlines();assert len(rows)==len(cases)
exact=0;worst=0.
for values,line in zip(cases,rows):
 vx,vy,yaw,pitch,forward,side,smooth,sidespeed,phase=values
 u.mem_write(INPUT,struct.pack('<7I9f',1,64,phase,0,2,0,0,vx,vy,-10,pitch,yaw,forward,side,smooth,sidespeed))
 u.mem_write(OUTPUT,struct.pack('<I',28)+bytes(24));assert call('nl_movement_calculate',(INPUT,OUTPUT))==1
 actual=struct.unpack('<II5f',u.mem_read(OUTPUT,28));expected=tuple(map(float,line.split()))
 assert actual[1]==1 and actual[2]==0 and actual[3]==expected[2]
 error=abs(actual[4]-expected[1]);worst=max(worst,error)
 assert error<.0001,(values,actual,expected)
 exact+=struct.pack('<f',actual[4])==struct.pack('<f',expected[1])
original=(PROJECT/'source/skeet/Binary/skeet.bin').read_bytes();found=[]
for t in pe.DIRECTORY_ENTRY_RESOURCE.entries:
 for r in t.directory.entries:
  for lang in r.directory.entries:
   d=lang.data.struct;data=pe.get_data(d.OffsetToData,d.Size)
   if len(data)==len(original):found.append(data==original)
assert found==[True]
files={name:{'bytes':(BUILD/name).stat().st_size,'sha256':hashlib.sha256((BUILD/name).read_bytes()).hexdigest()}for name in ['skeet.dll','injector.exe']}
result={'passed':True,'machine':'Windows x86 (0x14c)','files':files,
 'exports':{n:hex(symbols[n])for n in symbols if n.startswith('nl_movement') or n=='skeet_loader_status'},
 'original_core_embedded':True,'cdecl_export_queries_passed':3,
 'compiled_dll_calculate_cases':len(cases),'yaw_float32_equal_to_portable_cases':exact,'max_yaw_serialization_error':worst,
 'controlled_math_import_calls':math_calls,'boundary':'Only atan2 uses controlled host-libm return; DLL entry and Windows APIs not executed.',
 'injector_executed':False,'dll_entry_executed':False,'game_tested':False,
 'full_neverlose_movement_1to1':False}
(PROJECT/'reports/windows_build_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

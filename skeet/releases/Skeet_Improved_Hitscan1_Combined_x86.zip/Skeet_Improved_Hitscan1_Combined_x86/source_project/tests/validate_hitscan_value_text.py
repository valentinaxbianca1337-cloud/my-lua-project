"""Run the original GS slider value renderer and capture its text draw arguments.
Only the renderer surface is controlled; no GPU or game process is used.
"""
from pathlib import Path
import importlib.util,struct,json
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ui',r/'tests/validate_improved_native.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
u,s,word,put,floats,call,original=f.machine(1.,32)
assert call('improved_construct',[f.MENU,f.ALLOC,f.FREE,f.CTOR,f.CHILD,f.APPEND])==1
slider=s['widgets'][8][0];u.mem_write(slider+0x69,b'\1') # constructor tooltip=true boundary
text_api=f.API+0x280;put(f.RVT+15*4,text_api);draws=[]
def hook(u,a,size,user):
 if a!=text_api:return
 sp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==f.RENDERER
 x,y,color,clip,ptr,n=[word(sp+i)for i in [4,8,12,16,20,24]]
 draws.append(bytes(u.mem_read(ptr,n*2)).decode('utf-16-le'))
 u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_ESP,sp+28);u.reg_write(UC_X86_REG_EIP,word(sp))
u.hook_add(UC_HOOK_CODE,hook)
for value,expected in [(8,'GS'),(9,'NL'),(10,'10'),(64,'64'),(112,'112')]:
 assert call('hitscan_controls_frame',[1,value,1])==(1|(value<<1))
 call('',[f.RENDERER,10,20,30,0],this=slider,address=0x43416fbd)
 assert draws[-1]==expected,(value,draws)
report={'passed':True,'native_value_renderer':'0x43416fbd','native_wide_string_view':'0x433c9584','rendered_text_arguments':draws,'boundary':'IRenderer text call captured; no GPU/game executed','game_tested':False}
(r/'reports/hitscan_value_text.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

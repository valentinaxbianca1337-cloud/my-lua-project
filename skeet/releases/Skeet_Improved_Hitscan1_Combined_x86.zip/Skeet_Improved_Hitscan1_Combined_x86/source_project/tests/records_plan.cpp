#include "../source/skeet/record_hooks.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
int main(int argc,char** argv) {
    if(argc!=9)return 2;
    std::ifstream f(argv[1],std::ios::binary);std::vector<unsigned char> b((std::istreambuf_iterator<char>(f)),{});
    record_hooks::Plan p{};
    const auto num=[&](int i){return unsigned(std::stoul(argv[i],nullptr,0));};
    if(!record_hooks::make_plan(b.data(),b.size(),num(3),num(4),num(5),num(6),num(7),num(8),p))return 3;
    for(auto e:p.edits){b[e.offset]^=1;record_hooks::Plan bad{};
        if(record_hooks::make_plan(b.data(),b.size(),num(3),num(4),num(5),num(6),num(7),num(8),bad))return 4;
        b[e.offset]^=1;}
    std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(p.code),sizeof(p.code));
    for(const auto& e:p.edits){out.write(reinterpret_cast<const char*>(&e.offset),4);out.write(reinterpret_cast<const char*>(&e.length),4);out.write(reinterpret_cast<const char*>(e.after),e.length);}
    out.write(reinterpret_cast<const char*>(&p.application_return),4);
    std::cout<<"Record hooks and five incompatible-site rejections passed\n";
}

#include "../source/skeet/nl_trace_host.h"
extern "C" __declspec(dllexport) int trace_host_probe(unsigned index,
    const nl_prediction::Vec* start,const nl_prediction::Vec* end,
    const nl_prediction::Vec* mins,const nl_prediction::Vec* maxs,nl_prediction::Trace* result) {
    nl_trace_host::Host host;
    if(!host.initialize(index))return -1;
    return host(*start,*end,*mins,*maxs,*result)?1:0;
}

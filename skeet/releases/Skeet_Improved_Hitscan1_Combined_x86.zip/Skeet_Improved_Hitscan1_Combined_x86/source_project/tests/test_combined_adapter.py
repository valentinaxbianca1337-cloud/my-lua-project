"""Host-policy tests with mocked GameSense/FFI boundaries, not a Windows ABI test."""
from pathlib import Path
import json
from lupa.luajit21 import LuaRuntime
source=(Path(__file__).resolve().parents[1]/'lua/nl_movement_combined.lua').read_text()
l=LuaRuntime(unpack_returned_tuples=True)
assert l.execute('local f,e=loadstring(...);return f~=nil,e',source)==(True,None)
l.execute('''
real_require=require
function prepare(source,initial,module)
 state={module=module,errors={},calls={},writes={},native={value=initial},
   flags=0,move_type=2,water=0,vx=300,vy=0,vz=-10,pitch=0,yaw=0,player=1,alive=true,map='test'}
 controls={};events={}
 local function control(value) return {value=value} end
 ui={
  new_checkbox=function()controls.enable=control(false);return controls.enable end,
  new_combobox=function()controls.mode=control("WASD");return controls.mode end,
  new_slider=function()controls.smooth=control(50);return controls.smooth end,
  reference=function(tab,group,label)assert(label=='Air strafe');return state.native end,
  get=function(c)return c.value end,
  set=function(c,v)c.value=v;if c==state.native then state.writes[#state.writes+1]=v end;if c.callback then c.callback()end end,
  set_callback=function(c,fn)c.callback=fn end,set_visible=function(c,v)c.visible=v end}
 client={error_log=function(x)state.errors[#state.errors+1]=x end,
  camera_angles=function()return state.pitch,state.yaw end,
  set_event_callback=function(name,fn)events[name]=fn end}
 entity={get_local_player=function()return state.player end,is_alive=function()return state.alive end,
  get_prop=function(_,name)
   if name=='m_fFlags'then return state.flags elseif name=='m_MoveType'then return state.move_type
   elseif name=='m_nWaterLevel'then return state.water elseif name=='m_vecVelocity'then return state.vx,state.vy,state.vz
   elseif name=='m_vecOrigin'and not state.no_origin then return 0,0,100 end
  end}
 globals={mapname=function()return state.map end,tickinterval=function()return 1/64 end}
 cvar={cl_sidespeed={get_float=function()return 450 end}}
 local exports={
  nl_movement_api_version=function()return 1 end,
  nl_movement_v2_input_size=function()return 140 end,nl_movement_v2_output_size=function()return 40 end,
  nl_movement_v2_calculate=function(input,output)
   if state.calc_result and state.calc_result<0 then return state.calc_result end
   local a=input[0];local copy={};for k,v in pairs(a)do copy[k]=v end
   state.calls[#state.calls+1]=copy
   output[0].mode=a.mode;output[0].status=state.calc_status or 0;output[0].handled=1;output[0].forward=0;output[0].side=a.phase==0 and 450 or -450
   output[0].move_yaw=a.mode==2 and a.saved_yaw+3 or a.yaw+a.vy*.01;return 1
  end}
 local fake={
  cdef=function()end,new=function(name)return {[0]={_size=name:find('input')and 140 or 40,origin={},mins={},maxs={}}}end,
  sizeof=function(a)return a._size end,cast=function(_,p)return p end,
  C={GetModuleHandleA=function()return state.module and 1 or nil end,
     GetProcAddress=function(_,name)return exports[name]end}}
 local env=setmetatable({require=function(name)if name=='ffi'then return fake end;return real_require(name)end},{__index=_G})
 setfenv(assert(loadstring(source)),env)()
end
function cmd(number)
 return {command_number=number,forwardmove=450,sidemove=0,pitch=89,yaw=-140,
  in_attack=1,in_duck=1,in_speed=0,allow_send_packet=false,chokedcommands=3}
end
function untouched(c)
 local before={};for k,v in pairs(c)do before[k]=v end
 events.setup_command(c)
 for k,v in pairs(before)do assert(c[k]==v,k)end
 assert(c.move_yaw==nil)
end
''')
cases=[]
def test(name,body):
    l.globals().prepare(source,True,True)
    l.execute(body);cases.append(name)
test('disabled keeps command and native setting',"untouched(cmd(1));assert(state.native.value and #state.calls==0 and #state.writes==0)")
test('missing exports reject enable before native setting change',"state.module=false;ui.set(controls.enable,true);assert(not ui.get(controls.enable)and state.native.value and #state.calls==0 and #state.writes==0 and #state.errors==1)")
test('on/off owns and restores original native strafe',"ui.set(controls.enable,true);assert(not state.native.value);ui.set(controls.enable,false);assert(state.native.value and #state.writes==2)")
l.globals().prepare(source,False,True)
l.execute('ui.set(controls.enable,true);ui.set(controls.enable,false);assert(not state.native.value)')
cases.append('original native false stays false')
test('aim/attack/duck/packet fields stay intact',"ui.set(controls.enable,true);local c=cmd(10);events.setup_command(c);assert(c.pitch==89 and c.yaw==-140 and c.in_attack==1 and c.in_duck==1 and c.allow_send_packet==false and c.chokedcommands==3)")
test('duplicate command preserves phase and original WASD',"ui.set(controls.enable,true);local c=cmd(10);events.setup_command(c);state.yaw=90;state.vy=200;events.setup_command(c);local a,b=state.calls[1],state.calls[2];assert(a.phase==b.phase and a.forward==b.forward and b.forward==450 and b.side==0 and b.yaw==a.yaw and b.vy==200)")
test('new command alternates once; replay uses its recorded phase',"ui.set(controls.enable,true);events.setup_command(cmd(10));events.setup_command(cmd(11));events.setup_command(cmd(10));assert(state.calls[1].phase~=state.calls[2].phase and state.calls[1].phase==state.calls[3].phase)")
test('zero command number does not cache stale movement',"ui.set(controls.enable,true);untouched(cmd(0));assert(#state.calls==0)")
test('ground/ladder/water/walk do not alter commands',"ui.set(controls.enable,true);state.flags=1;untouched(cmd(10));state.flags=0;state.move_type=9;untouched(cmd(11));state.move_type=2;state.water=2;untouched(cmd(12));state.water=0;local c=cmd(13);c.in_speed=1;untouched(c);assert(#state.calls==0)")
test('crouch air is supported',"ui.set(controls.enable,true);state.flags=2;local c=cmd(10);events.setup_command(c);assert(#state.calls==1 and c.in_duck==1)")
test('death/map exit/round reset drop phase cache',"ui.set(controls.enable,true);events.setup_command(cmd(10));state.alive=false;untouched(cmd(11));state.alive=true;events.setup_command(cmd(12));assert(state.calls[1].phase==state.calls[2].phase);events.round_start();events.setup_command(cmd(13));assert(state.calls[3].phase==0);state.map=nil;untouched(cmd(14))")
test('foreign native true is preserved when disabling',"ui.set(controls.enable,true);state.native.value=true;local n=#state.writes;ui.set(controls.enable,false);assert(state.native.value and #state.writes==n)")
test('shutdown releases native setting',"ui.set(controls.enable,true);events.shutdown();assert(state.native.value)")
test('finite/zero velocity guards reject bad host values',"ui.set(controls.enable,true);state.vx=0/0;untouched(cmd(10));state.vx=0;state.vy=0;state.vz=0;untouched(cmd(11));assert(#state.calls==0)")

test('missing origin uses WASD instead of tracing the world origin',"ui.set(controls.mode,'Directional');ui.set(controls.enable,true);state.no_origin=true;events.setup_command(cmd(10));assert(state.calls[1].mode==1 and #state.errors==1)")
test('Normal mode dispatches separately',"ui.set(controls.mode,'Normal');ui.set(controls.enable,true);events.setup_command(cmd(10));assert(state.calls[1].mode==0)")
test('Directional keeps accumulated yaw across new commands and original yaw on replay',"ui.set(controls.mode,'Directional');ui.set(controls.enable,true);events.setup_command(cmd(10));events.setup_command(cmd(11));events.setup_command(cmd(10));events.setup_command(cmd(12));assert(state.calls[1].saved_yaw==0 and state.calls[2].saved_yaw==3 and state.calls[3].saved_yaw==0 and state.calls[4].saved_yaw==6)")
test('native failure leaves all command fields unchanged',"ui.set(controls.enable,true);state.calc_result=-3;untouched(cmd(10))")
test('prediction failure uses returned steering and logs once',"ui.set(controls.mode,'Directional');ui.set(controls.enable,true);state.calc_status=1;local a=cmd(10);events.setup_command(a);events.setup_command(cmd(11));assert(#state.errors==1 and math.abs(a.sidemove)==450)")
test('duck hull and replicated-cvar defaults passed to native bridge',"ui.set(controls.enable,true);state.flags=2;events.setup_command(cmd(10));local a=state.calls[1];assert(a.maxs.z==54 and a.mins.x==-16 and a.gravity==800 and a.max_wishspeed==30 and a.interval==1/64)")

r=LuaRuntime(unpack_returned_tuples=True)
r.execute('''
ui={new_checkbox=function()return {value=false}end,new_slider=function()return {value=50}end,new_combobox=function()return {value="WASD"}end,
 reference=function()return {value=true}end,get=function(c)return c.value end,
 set=function(c,v)c.value=v;if c.callback then c.callback()end end,
 set_callback=function(c,fn)c.callback=fn end,set_visible=function()end}
client={set_event_callback=function()end}
''')
r.execute(source)
r.execute(source)
assert r.execute('local f=require("ffi");return f.sizeof("nl8802_v2_input"),f.sizeof("nl8802_v2_output")')==(140,40)
cases.append('real LuaJIT FFI structure sizes and script reload; no Windows export executed')
print(json.dumps({'passed':True,'groups':len(cases),'cases':cases,
                 'boundary':'GameSense and Windows exports mocked; C++ math tested separately',
                 'game_tested':False},indent=2))

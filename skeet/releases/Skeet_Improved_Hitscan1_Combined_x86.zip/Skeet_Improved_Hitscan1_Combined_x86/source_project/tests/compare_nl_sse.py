"""Execute the original NL scalar-SSE steering block in Unicorn, never its DLL.
Usage: python compare_nl_sse.py nl.image.bin compiled_portable_probe
Requires unicorn==2.1.4. Output is JSON; caller may save it as a report.
"""
from pathlib import Path
import hashlib,json,math,random,struct,subprocess,sys
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *

image=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(image).hexdigest()=='f8b25eacb0a7269a1ce82a8816c8f84bf0c1fb1cfb58a75583973e01f503d4e3'
BASE=0x412a0000;BP=0x71008000;SP=BP-0x200;CFG=0x72000000;ANGLE=CFG+0x1000;CMD=CFG+0x2000
u=Uc(UC_ARCH_X86,UC_MODE_32)
u.mem_map(BASE,(len(image)+4095)&~4095);u.mem_write(BASE,image)
u.mem_map(0x71000000,0x10000);u.mem_map(CFG,0x10000)
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def putf(a,x):u.mem_write(a,struct.pack('<f',x))
def getf(a):return struct.unpack('<f',u.mem_read(a,4))[0]
def xmm(reg,x):u.reg_write(reg,struct.unpack('<I',struct.pack('<f',x))[0])
case=None;math_calls=0;side_boundaries=0
def hook(machine,address,size,user):
    global math_calls,side_boundaries
    if address==0x414297b0:
        u.emu_stop();return
    if address==0x414291cc:
        # The WASD atan2 result was already stored by its controlled boundary.
        u.reg_write(UC_X86_REG_EIP,address+3);return
    if address in {0x414293ab,0x414294a1,0x4142957c,0x4142964b}:
        # Boundary replaces only protected ConVar retrieval/anti-tamper code.
        # The native steering branch has already chosen the output sign.
        value=-case[4] if address in {0x414293ab,0x4142957c} else case[4]
        xmm(UC_X86_REG_XMM0,value);u.reg_write(UC_X86_REG_EDI,BP-0x2c)
        u.reg_write(UC_X86_REG_EIP,0x414296fc);side_boundaries+=1;return
    if address not in {0x4202f7d0,0x42031040,0x42026d1b,0x420338d0,0x42030390}:return
    sp=u.reg_read(UC_X86_REG_ESP)
    ret=struct.unpack('<I',u.mem_read(sp,4))[0]
    if address==0x42026d1b:
        u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_ESP,sp+4)
        u.reg_write(UC_X86_REG_EIP,ret);return
    a,b=struct.unpack('<dd',u.mem_read(sp+4,16))
    if address==0x4202f7d0:value=math.atan2(a,b)
    elif address==0x42031040:value=math.fmod(a,b)
    elif address==0x420338d0:value=math.sin(a)
    else:value=math.cos(a)
    if ret==0x414291bb:
        putf(BP-0x64,value)
        u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
        math_calls+=1;return
    # Original caller immediately stores the x87 result as a float local.
    op=bytes(u.mem_read(ret,4))
    if op[:2]==bytes.fromhex('d95d'):
        offset=struct.unpack('<b',op[2:3])[0];putf(BP+offset,value);size=3
    else:
        assert op[:3]==bytes.fromhex('d95c24'),(hex(ret),op.hex())
        putf(sp+4+op[3],value);size=4
    u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret+size);math_calls+=1
u.hook_add(UC_HOOK_CODE,hook)
def original(values,wasd_input=None):
    global case
    case=values;vx,vy,yaw,smooth,side,phase,wasd=values
    u.mem_write(BP-0x100,bytes(0x100));u.mem_write(CFG,bytes(0x3000))
    u.mem_write(BP+12,struct.pack('<I',CMD));u.mem_write(BP+16,struct.pack('<I',ANGLE))
    putf(BP-0x44,f32(math.sqrt(f32(f32(vy*vy)+f32(vx*vx)))))
    u.mem_write(CFG+0x184,struct.pack('<I',int(smooth)));u.mem_write(CFG+0x18c,b'\0')
    u.mem_write(0x42502be0,bytes([phase]));putf(ANGLE+4,yaw)
    start=0x41429234
    if wasd_input is not None:
        pitch,forward,side=wasd_input
        putf(ANGLE,pitch);putf(CMD+0x24,forward);putf(CMD+0x28,side)
        if forward!=0 or side!=0:start=0x4142911a
    u.reg_write(UC_X86_REG_EBP,BP);u.reg_write(UC_X86_REG_ESP,SP)
    u.reg_write(UC_X86_REG_ESI,ANGLE);u.reg_write(UC_X86_REG_EDI,CFG)
    u.reg_write(UC_X86_REG_EAX,CMD);u.reg_write(UC_X86_REG_EBX,int(wasd))
    u.reg_write(UC_X86_REG_MXCSR,0x1f80)
    xmm(UC_X86_REG_XMM1,getf(BP-0x44));xmm(UC_X86_REG_XMM2,vx);xmm(UC_X86_REG_XMM3,vy)
    u.emu_start(start,0x414297b0,count=2000)
    assert u.reg_read(UC_X86_REG_EIP)==0x414297b0
    return getf(ANGLE+4),getf(CMD+0x28),getf(BP-0x30)
rng=random.Random(880211)
cases=[]
for speed in [0.,1.,80.,80.0001,100.,300.,2000.]:
 for yaw in [-180.,-170.,-90.,0.,90.,170.,180.]:
  for smooth in [0,50,100]:
   for phase in [0,1]:cases.append((speed,0.,yaw,smooth,450.,phase,1))
for _ in range(3000):
 speed=rng.uniform(.01,2500);heading=rng.uniform(-math.pi,math.pi)
 cases.append((f32(speed*math.cos(heading)),f32(speed*math.sin(heading)),
               f32(rng.uniform(-180,180)),rng.randrange(101),rng.choice([100.,250.,450.]),rng.randrange(2),rng.randrange(2)))
payload=''.join(' '.join(map(str,c))+'\n' for c in cases)
process=subprocess.run([sys.argv[2],'--steer'],input=payload,text=True,capture_output=True,check=True)
rows=process.stdout.splitlines();assert len(rows)==len(cases)
worst=0.;bit_exact=0
for i,(values,line) in enumerate(zip(cases,rows)):
    a=tuple(map(float,line.split()));b=original(values)
    error=abs(a[0]-b[0]);worst=max(worst,error)
    assert error<=.0001 and a[1]==b[1] and abs(a[2]-b[2])<=.00001,(i,values,a,b)
    if struct.pack('<f',a[0])==struct.pack('<f',b[0]):bit_exact+=1
wasd=[]
for _ in range(1200):
    speed=rng.uniform(.01,2500);heading=rng.uniform(-math.pi,math.pi)
    wasd.append((f32(speed*math.cos(heading)),f32(speed*math.sin(heading)),
      f32(rng.uniform(-180,180)),rng.choice([-89.,-45.,0.,45.,89.]),
      rng.choice([-450.,0.,450.]),rng.choice([-450.,0.,450.]),rng.randrange(101),450.,rng.randrange(2)))
payload=''.join(' '.join(map(str,c))+'\n' for c in wasd)
process=subprocess.run([sys.argv[2],'--calculate'],input=payload,text=True,capture_output=True,check=True)
rows=process.stdout.splitlines();assert len(rows)==len(wasd)
wasd_exact=0;wasd_worst=0.
for i,(v,line) in enumerate(zip(wasd,rows)):
    vx,vy,yaw,pitch,fwd,side,smooth,sidespeed,phase=v
    a=tuple(map(float,line.split()));assert a[0]==1
    b=original((vx,vy,yaw,smooth,sidespeed,phase,int(fwd!=0 or side!=0)),(pitch,fwd,side))
    error=abs(a[1]-b[0]);wasd_worst=max(wasd_worst,error)
    assert error<=.0001 and a[2]==b[1],(i,v,a,b)
    if struct.pack('<f',a[1])==struct.pack('<f',b[0]):wasd_exact+=1
print(json.dumps({'passed':True,'cases':len(cases),'yaw_bit_exact_cases':bit_exact,
 'wasd_prefix_cases':len(wasd),'wasd_yaw_bit_exact_cases':wasd_exact,'wasd_max_yaw_error_degrees':wasd_worst,
 'max_yaw_error_degrees':worst,'block':'41429234..414297B0','original_sse_executed':True,
 'boundaries':['protected ConVar lookup/guard returns supplied cl_sidespeed',
               'sin/cos/atan2/fmod use host libm, results stored with original float precision',
               'float classification reports normal finite input'],
 'excluded':['native eligibility/feature settings prefix','Directional collision predictor','host GameSense command pipeline','live server'],
 'game_tested':False,'math_calls':math_calls,'side_boundaries':side_boundaries},indent=2))

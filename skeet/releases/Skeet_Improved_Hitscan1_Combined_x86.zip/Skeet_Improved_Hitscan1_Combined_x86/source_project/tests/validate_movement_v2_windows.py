"""Execute new compiled x86 movement exports, never DLL entry or the game.
Engine modules are deliberately unavailable to exercise the fallback contract.
"""
from pathlib import Path
import struct,math,json
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(__file__).resolve().parents[1];p=pefile.PE(str(r/'build/skeet.dll'))
base=p.OPTIONAL_HEADER.ImageBase;u=Uc(UC_ARCH_X86,UC_MODE_32)
u.mem_map(base,(p.OPTIONAL_HEADER.SizeOfImage+4095)&~4095);u.mem_write(base,p.get_memory_mapped_image())
mem=0x70000000;u.mem_map(mem,0x30000);stop=mem+0x1000;inp=mem+0x2000;out=mem+0x3000;value=mem+0x4000;sp=mem+0xf000
put=lambda a,v:u.mem_write(a,struct.pack('<I',v))
word=lambda a:struct.unpack('<I',u.mem_read(a,4))[0]
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
imports={};host_calls=0
for lib in p.DIRECTORY_ENTRY_IMPORT:
 for item in lib.imports:
  target=mem+0x10000+len(imports)*16;put(item.address,target)
  imports[target]=item.name.decode()if item.name else '#'+str(item.ordinal)
  u.mem_write(target,b'\xdd\x05'+struct.pack('<I',value)+b'\xc3')
def hook(machine,address,size,user):
 global host_calls
 if address==stop:u.emu_stop();return
 if address not in imports:return
 name=imports[address];stack=u.reg_read(UC_X86_REG_ESP)
 if name=='GetModuleHandleW':
  host_calls+=1;u.reg_write(UC_X86_REG_EAX,0);u.reg_write(UC_X86_REG_EIP,word(stack));u.reg_write(UC_X86_REG_ESP,stack+8);return
 if name in ['memset','memcpy','memmove']:
  dst,src,n=[word(stack+i)for i in [4,8,12]];u.mem_write(dst,bytes([src&255])*n if name=='memset'else bytes(u.mem_read(src,n)))
  u.reg_write(UC_X86_REG_EAX,dst);u.reg_write(UC_X86_REG_EIP,word(stack));u.reg_write(UC_X86_REG_ESP,stack+4);return
 assert name in ['atan2','asin','fmod','sin','cos','sinf','cosf'],name
 if name in ['sinf','cosf']:
  x=struct.unpack('<f',u.mem_read(stack+4,4))[0];v=f32(math.sin(x)if name=='sinf'else math.cos(x))
 else:
  a,b=struct.unpack('<dd',u.mem_read(stack+4,16))
  if name=='atan2':v=math.atan2(a,b)
  elif name=='asin':v=math.asin(a)if -1<=a<=1 else float('nan')
  elif name=='fmod':v=math.fmod(a,b)
  elif name=='sin':v=math.sin(a)
  else:v=math.cos(a)
 u.mem_write(value,struct.pack('<d',v))
u.hook_add(UC_HOOK_CODE,hook)
symbols={s.name.decode():base+s.address for s in p.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def call(name,args=()):
 for i,v in enumerate([stop,*args]):put(sp+4*i,v)
 u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_MXCSR,0x1f80)
 u.reg_write(UC_X86_REG_FPCW,0x37f);u.emu_start(symbols[name],stop,count=1000000)
 assert u.reg_read(UC_X86_REG_EIP)==stop and u.reg_read(UC_X86_REG_ESP)==sp+4
 return u.reg_read(UC_X86_REG_EAX)
assert call('nl_movement_v2_input_size')==140 and call('nl_movement_v2_output_size')==40
cases=0
for mode in [0,1,2]:
 for tick in [1/64,1/128]:
  for vx,vy,yaw in [(300.,0.,0.),(150.,250.,-179.),(1000.,100.,179.)]:
   floats=[vx,vy,-10.,0.,yaw,450.,0.,50.,450.,0.,0.,100.,-16.,-16.,0.,16.,16.,72.,tick,800.,12.,30.,320.,301.99338,1.,yaw]
   data=struct.pack('<9I26f',2,140,mode,0,1,0,2,0,0,*floats)
   u.mem_write(inp,data);u.mem_write(out,struct.pack('<I',40)+bytes(36))
   assert call('nl_movement_v2_calculate',[inp,out])==1
   v=struct.unpack('<6I4f',u.mem_read(out,40))
   assert v[0]==40 and v[1]==1 and abs(v[7])==450 and math.isfinite(v[8])
   if mode==2:assert v[2]==1 and v[3]==1 and v[5]==1
   else:assert v[2]==mode and v[3]==0 and v[5]==0
   cases+=1
# The v2 bridge rejects a wrong layout without partially overwriting the caller.
put(inp,1);u.mem_write(out,struct.pack('<I',40)+b'\x5a'*36);before=bytes(u.mem_read(out,40))
assert call('nl_movement_v2_calculate',[inp,out])==0xfffffffe and bytes(u.mem_read(out,40))==before
report={'passed':True,'new_compiled_export_cases':cases,'new_input_bytes':140,'new_output_bytes':40,
        'stdcall_host_queries_controlled':host_calls,'missing_engine_falls_back_to_wasd':True,
        'bad_abi_leaves_output_intact':True,'dll_entry_executed':False,'game_tested':False}
(r/'reports/movement_v2_windows.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

"""Compare reconstructed Directional selection with the original NL instructions.
The collision oracle and plane query are controlled, NOT physics implementations.
No DLL entry, game process, injector, network, or protected helpers are executed.
"""
from pathlib import Path
import struct,math,hashlib,json,random,subprocess
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *

root=Path(__file__).resolve().parent
image=Path('/workspace/work/neverlose/nl.image.bin').read_bytes()
assert hashlib.sha256(image).hexdigest()=='f8b25eacb0a7269a1ce82a8816c8f84bf0c1fb1cfb58a75583973e01f503d4e3'
base=0x412a0000;local=0x71001000;bp=0x71008000;cmd=0x7100a000
u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(base,(len(image)+4095)&~4095);u.mem_write(base,image)
u.mem_map(0x71000000,0x10000)
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
def put(a,x):u.mem_write(a,struct.pack('<I',x))
def putf(a,x):u.mem_write(a,struct.pack('<f',x))
def getf(a):return struct.unpack('<f',u.mem_read(a,4))[0]
case=None;probes=[];horizons=[];plane_called=False
def finish(sp,result=0):
 ret=word(sp);u.reg_write(UC_X86_REG_EAX,result)
 u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
def hook(machine,address,size,user):
 global plane_called
 if address==0x4142c537:u.emu_stop();return
 if address==0x4142c459:
  # Only side-speed ConVar retrieval/protected code; native selects turn/sign.
  value=math.copysign(case[3],-getf(local+0x50))
  u.reg_write(UC_X86_REG_XMM0,bits(value));u.reg_write(UC_X86_REG_EIP,0x4142c526);return
 if address not in [0x414283a0,0x4142d570,0x4202f780,0x4202f7d0,0x42031040,0x42026d1b]:return
 sp=u.reg_read(UC_X86_REG_ESP)
 if address==0x414283a0:
  horizons.append(getf(sp+4));probes.append(getf(sp+8))
  finish(sp,int(len(probes)-1!=case[4]));return
 if address==0x4142d570:
  plane_called=True;p=word(sp+4)
  putf(p,case[6]);putf(p+4,case[7]);u.mem_write(p+12,bytes([case[5]]))
  finish(sp);return
 if address==0x42026d1b:finish(sp);return
 a=struct.unpack('<d',u.mem_read(sp+4,8))[0]
 if address==0x4202f780:
  value=math.asin(a)if -1<=a<=1 else float('nan')
 else:
  b=struct.unpack('<d',u.mem_read(sp+12,8))[0]
  value=math.atan2(a,b)if address==0x4202f7d0 else math.fmod(a,b)
 ret=word(sp);op=bytes(u.mem_read(ret,6));assert op[:2]==b'\xd9\x9e',(hex(ret),op.hex())
 displacement=struct.unpack('<i',op[2:6])[0];putf(local+displacement,value)
 u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret+6)
u.hook_add(UC_HOOK_CODE,hook)
def original(values):
 global case,probes,horizons,plane_called
 case=values;probes=[];horizons=[];plane_called=False
 u.mem_write(local,bytes(0x200));putf(local+0x94,case[1]);putf(bp+8,case[0]);putf(0x42502be4,case[2])
 put(0x424b03cc,cmd);u.mem_write(cmd,bytes(0x60))
 u.reg_write(UC_X86_REG_ESI,local);u.reg_write(UC_X86_REG_EBP,bp);u.reg_write(UC_X86_REG_ESP,local)
 u.reg_write(UC_X86_REG_MXCSR,0x1f80)
 u.emu_start(0x4142c238,0x4142c537,count=50000)
 assert u.reg_read(UC_X86_REG_EIP)==0x4142c537
 assert getf(cmd+0x24)==0
 return (getf(0x42502be4),getf(cmd+0x28),getf(local+0x50),getf(local+0x4c),len(probes),plane_called),probes[:],horizons[:]

rng=random.Random(880231)
cases=[]
for speed in [0.,1.,30.,80.,100.,300.,763.79,1000.,3000.]:
 for clear in [-1,0,1,10,25,60]:
  for plane in [0,1]:
   for yaw in [-179.,0.,179.]:cases.append((speed,30.,yaw,450.,clear,plane,.7,-.2))
for _ in range(600):cases.append((rng.uniform(.001,4500),rng.choice([15.,30.,60.]),rng.uniform(-180,180),rng.choice([0.,320.,450.]),rng.choice([-1,0,1,5,10,20,35,60]),rng.randrange(2),rng.uniform(-1,1),rng.uniform(-1,1)))
cases=[tuple(f32(x)if i not in [4,5]else x for i,x in enumerate(c))for c in cases]
payload=''.join(' '.join(map(str,c))+'\n'for c in cases)
p=subprocess.run([str(root/'directional_probe')],input=payload,text=True,capture_output=True,check=True)
rows=p.stdout.splitlines();assert len(rows)==len(cases)
count=0;total_probes=0;fallbacks=0
for c,row in zip(cases,rows):
 a,steps,horizons=original(c);values=row.split();b=list(map(float,values[:4]))
 if [bits(v)for v in a[:4]]!=[bits(v)for v in b]:raise AssertionError((c,a,b))
 assert int(values[4])==a[4]and bool(int(values[5]))==a[5],(c,a,values)
 assert list(map(lambda x:int(x,16),values[6:]))==[bits(v)for v in steps],c
 assert all(bits(v)==bits(a[3])for v in horizons)
 count+=1;total_probes+=len(steps);fallbacks+=a[5]
report={'passed':True,'scope':'Directional candidate search only','cases':count,'bitwise_float32_results_and_probe_sequences_equal':True,
        'collision_probes':total_probes,'plane_fallback_cases':fallbacks,'decoded_convar':'sv_air_max_wishspeed',
        'controlled_boundaries':['collision prediction 414283A0','plane query 4142D570','libm/classification','side speed ConVar/protected retrieval'],
        'physics_reconstructed':False,'host_command_integration':False,'full_neverlose_movement_1to1':False,'game_tested':False}
(root/'directional_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

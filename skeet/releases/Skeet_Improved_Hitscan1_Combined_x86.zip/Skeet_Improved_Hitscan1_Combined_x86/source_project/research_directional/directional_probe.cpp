#include "directional_search.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstring>
#include <cassert>
int main() {
    using namespace nl_directional;
    Input in{};int clear_at,plane_valid;float nx,ny;
    std::cout<<std::setprecision(10);
    while(std::cin>>in.speed>>in.max_wishspeed>>in.saved_yaw>>in.side_speed>>clear_at>>plane_valid>>nx>>ny) {
        Output out{};unsigned i=0;std::vector<float> probes;
        const bool ok=calculate(in,[&](float horizon,float turn){
            probes.push_back(turn);return int(i++)!=clear_at;
        },[&](){return Plane{nx,ny,plane_valid!=0};},out);
        if(!ok){std::cout<<"invalid\n";continue;}
        std::cout<<out.yaw<<' '<<out.side<<' '<<out.turn<<' '<<out.horizon<<' '<<out.probes<<' '<<out.plane_queried;
        for(float p:probes){std::uint32_t bits;std::memcpy(&bits,&p,4);std::cout<<' '<<std::hex<<bits<<std::dec;}
        std::cout<<'\n';
    }
}

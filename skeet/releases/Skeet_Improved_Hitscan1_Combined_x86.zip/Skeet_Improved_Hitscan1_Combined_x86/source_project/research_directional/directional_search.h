#pragma once
#include <cmath>
#include <cstdint>

// Reconstructed NL Directional selection, 4142C238..4142C66E.
// Requires the original collision-prediction and plane-query contracts.
// This is NOT a complete movement simulator or a live GameSense integration.
namespace nl_directional {
inline constexpr float degrees=57.2957763671875f;
inline float normalized(float angle) {
    if(!std::isfinite(angle))angle=0;
    float v=static_cast<float>(std::fmod(static_cast<double>(angle),360.0));
    if(v>180.f)v-=360.f;
    if(v< -180.f)v+=360.f;
    return v;
}
struct Input {float speed,max_wishspeed,saved_yaw,side_speed;};
struct Plane {float x=0,y=0;bool valid=false;};
struct Output {
    float yaw=0,side=0,turn=0,horizon=0;
    unsigned probes=0;bool plane_queried=false;
};
template<class Collision,class PlaneQuery>
bool calculate(const Input& in,Collision collision,PlaneQuery plane_query,Output& out) {
    if(!std::isfinite(in.speed)||!std::isfinite(in.max_wishspeed)||
       !std::isfinite(in.saved_yaw)||!std::isfinite(in.side_speed)||
       in.speed<0||in.max_wishspeed<0||in.side_speed<0)return false;
    const float reciprocal=1.f/in.speed;
    const float ratio=in.max_wishspeed*reciprocal;
    const float arc=static_cast<float>(std::asin(static_cast<double>(ratio)));
    float initial=arc*degrees;
    // Native MAXSS/MINSS map the invalid asin range to the upper clamp.
    if(!std::isfinite(initial))initial=5.f;
    if(initial<0.f)initial=0.f;
    if(initial>90.f)initial=90.f;
    if(initial<2.25f)initial=2.25f;
    if(initial>5.f)initial=5.f;
    float horizon=320.f*reciprocal;
    if(horizon<.35f)horizon=.35f;
    if(horizon>1.f)horizon=1.f;
    unsigned count=0;
    const auto hit=[&](float angle){++count;return collision(horizon,angle);};
    float positive=initial;
    while(positive<=5.f) {
        if(!hit(positive))break;
        positive=positive+.20000000298023224f;
    }
    float turn;
    bool plane_used=false;
    if(positive<5.f)turn=positive+.20000000298023224f;
    else {
        float negative=initial;
        bool clear=false;
        while(negative>=-2.25f) {
            if(!hit(negative)){clear=true;break;}
            negative=negative+(-.20000000298023224f);
        }
        if(clear&&negative> -2.25f)turn=negative+(-.20000000298023224f);
        else {
            turn=negative;
            plane_used=true;
            const auto plane=plane_query();
            if(plane.valid) {
                const float normal_arc=static_cast<float>(std::atan2(
                    static_cast<double>(plane.y),static_cast<double>(plane.x)));
                const float away=normal_arc*(-degrees);
                const float delta=normalized(in.saved_yaw+away);
                turn=delta*(-.10000000149011612f);
            }
        }
    }
    Output result{};result.yaw=normalized(in.saved_yaw+turn);
    result.side=std::copysign(in.side_speed,-turn);result.turn=turn;
    result.horizon=horizon;result.probes=count;result.plane_queried=plane_used;
    out=result;return true;
}
}

#pragma once
#include "record_hooks.h"
namespace hitscan_hook {
struct Plan {unsigned char code[256]{},jump[7]{};};
inline bool make_plan(const unsigned char* image,std::size_t size,unsigned location,unsigned callback,Plan& out){
 constexpr unsigned char site[]={0x8d,0x8c,0x24,0xe0,0x47,0,0};
 constexpr unsigned char prologue[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0xa8,0x80,0,0,0x56,0x57};
 constexpr unsigned char input[]={0x8d,0x41,0x10,0x89,0x41,4,0x89,1,0x05,0x80,0x0a,0,0,0x89,0x41,8};
 constexpr unsigned char output[]={0x8d,0x41,0x10,0x89,0x41,4,0x89,1,0x05,0x80,0x18,0,0,0x89,0x41,8};
 if(!image||size!=core_image::image_size||std::memcmp(image+0x4eef6,site,sizeof(site))||std::memcmp(image+0x4cd37,prologue,sizeof(prologue))||std::memcmp(image+0x55490,input,sizeof(input))||std::memcmp(image+0x86e24,output,sizeof(output)))return false;
 out=Plan{};record_hooks::Emit e{out.code,location};e.save();e.args();e.frame();
 e.bytes({0x89,4,0x24,0x89,0x6c,0x24,4});e.call(callback);e.unargs();e.restore();
 e.bytes({0x8d,0x8c,0x24,0xe0,0x47,0,0});e.jump(0x4335eefd);
 if(e.pos>sizeof(out.code))return false;
 std::memset(out.jump,0x90,7);out.jump[0]=0xe9;record_hooks::word(out.jump+1,location-0x4335eefb);return true;
}
}

#pragma once
#include <cstddef>
#include <cstdint>
namespace cs2_visuals {bool install(std::uint8_t*,std::size_t);bool install_hitscan(unsigned char* image,std::size_t size);
    bool install_records(std::uint8_t*,std::size_t);}

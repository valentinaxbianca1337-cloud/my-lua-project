#pragma once
#include <cstdint>
#include <cstring>

namespace record_layout {
inline std::uint32_t u32(const void* p,std::size_t offset) {
    std::uint32_t v;std::memcpy(&v,static_cast<const unsigned char*>(p)+offset,4);return v;
}
inline float f32(const void* p,std::size_t offset) {
    float v;std::memcpy(&v,static_cast<const unsigned char*>(p)+offset,4);return v;
}
inline bool finite(float v) {
    std::uint32_t bits;std::memcpy(&bits,&v,4);return (bits&0x7f800000U)!=0x7f800000U;
}
struct Position {float x,y,z;};
inline Position position(const void* p,std::size_t offset) {
    return {f32(p,offset),f32(p,offset+4),f32(p,offset+8)};
}
inline bool finite(Position p) {return finite(p.x)&&finite(p.y)&&finite(p.z);}
inline bool continuous(Position a,Position b) {
    const float dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;
    volatile float squared=dy*dy;
    squared=squared+dx*dx;squared=squared+dz*dz;
    return finite(squared)&&squared<=4096.f;
}
}

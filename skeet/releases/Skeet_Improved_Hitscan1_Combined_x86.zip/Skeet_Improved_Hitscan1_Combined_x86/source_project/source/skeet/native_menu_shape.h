#pragma once
// Keep the first nine native logical IDs stable; custom tabs only append.
namespace native_menu_shape {
// Tabs is insertion/selection order. TabsArr is a separate semantic lookup:
// native construction stores insertion ordinal 1 at semantic slot 6 (Players).
// Requiring TabsArr[i] == Tabs[i] rejects this original unmodified menu.
template<class Menu> inline unsigned issue(const Menu* menu) {
    if(!menu)return 1;
    if(menu->Tabs.size()<9||menu->Tabs.size()>32)return 2;
    if(menu->CurrentTab>=menu->Tabs.size())return 3;
    for(unsigned i=0;i<9;i++) {
        auto* tab=menu->Tabs[i];
        if(!tab)return 4;
        if(tab->Header.Index!=int(i))return 5;
        if(tab->Menu!=menu)return 6;
    }
    bool seen[9]{};
    for(unsigned i=0;i<9;i++)if(menu->TabsArr[i]) {
        unsigned j=0;while(j<9&&menu->Tabs[j]!=menu->TabsArr[i])++j;
        if(j==9||seen[j])return 7;
        seen[j]=true;
    }
    return 0;
}
template<class Menu> inline bool tabbed(const Menu* menu){return issue(menu)==0;}
template<class Menu> inline bool valid(const Menu* menu) {
    // Legacy Visuals/Skins modules index Tabs using semantic enum constants.
    // Keep their existing conservative gate; Improved uses tabbed() instead.
    if(!tabbed(menu))return false;
    for(unsigned i=0;i<9;i++) {
        auto* tab=menu->Tabs[i];
        if(menu->TabsArr[i]&&menu->TabsArr[i]!=tab)return false;
    }
    return true;
}
}

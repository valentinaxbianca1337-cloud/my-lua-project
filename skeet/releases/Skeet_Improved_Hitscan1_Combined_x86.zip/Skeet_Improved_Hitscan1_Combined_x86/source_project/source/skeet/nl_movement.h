#pragma once
#include <cmath>
#include <cstdint>
#include <cstddef>

// A reconstructed Normal/WASD steering path, not the complete NL movement system.
// Evidence: NL image 412A0000, original block 41429234..414296FC.
namespace nl_movement {
inline constexpr std::uint32_t abi_version=1;
inline constexpr float degrees=57.2957763671875f;
inline constexpr float radians=0.01745329238474369f;
struct Input {
    std::uint32_t version,bytes,phase,flags,move_type,water_level,buttons;
    float vx,vy,vz,pitch,yaw,forward,side,smoothing,side_speed;
};
struct Output {
    std::uint32_t bytes,handled;
    float forward,side,move_yaw,ideal,correction;
};
static_assert(sizeof(Input)==64&&sizeof(Output)==28);
inline bool finite(float v){return std::isfinite(v);}
inline float normalize(float a) {
    float v=static_cast<float>(std::fmod(static_cast<double>(a),360.0));
    if(v>180.f)v-=360.f;
    if(v< -180.f)v+=360.f;
    return v;
}
struct Steering {float yaw,side,ideal,correction;};
// All intermediate arithmetic remains float, matching scalar SSE instruction order.
inline Steering steer(float vx,float vy,float desired,float smoothing,float side_speed,
                      bool phase,bool has_input) {
    const float x2=vx*vx,y2=vy*vy;
    const float speed=std::sqrt(y2+x2);
    const float ideal=(std::fmin)(845.5f/speed,90.f);
    const float velocity=static_cast<float>(std::atan2(static_cast<double>(vy),
                                                     static_cast<double>(vx)))*degrees;
    const float delta=normalize(desired-velocity);
    const float scale=0.03999999910593033f*ideal;
    const float correction=scale*(100.f-smoothing);
    float yaw,side;
    if(speed>80.f&&((has_input&&std::fabs(delta)>170.f)||delta>correction)) {
        yaw=velocity+correction;side=-side_speed;
    }else if(speed>80.f&&delta< -correction) {
        yaw=velocity-correction;side=side_speed;
    }else if(phase) {
        yaw=desired-ideal;side=-side_speed;
    }else {
        yaw=desired+ideal;side=side_speed;
    }
    return {normalize(yaw),side,ideal,correction};
}
inline float input_yaw(const Input& in) {
    if(in.forward==0.f&&in.side==0.f)return normalize(in.yaw);
    // NL AngleVectors produces float vectors, followed by float products/sums,
    // double atan2, a float store and a float degrees conversion.
    const float y=in.yaw*radians,p=in.pitch*radians;
    const float sy=static_cast<float>(std::sin(static_cast<double>(y)));
    const float cy=static_cast<float>(std::cos(static_cast<double>(y)));
    const float cp=static_cast<float>(std::cos(static_cast<double>(p)));
    const float fx=cp*cy,fy=cp*sy;
    const float ax=fx*in.forward,bx=sy*in.side;
    const float ay=fy*in.forward,by=(-cy)*in.side;
    const float wx=bx+ax,wy=by+ay;
    return normalize(static_cast<float>(std::atan2(static_cast<double>(wy),
                                                  static_cast<double>(wx)))*degrees);
}
inline int calculate(const Input* in,Output* out) {
    if(!in||!out)return -1;
    if(in->version!=abi_version||in->bytes!=sizeof(Input)||out->bytes!=sizeof(Output))return -2;
    Output result{};result.bytes=sizeof(Output);
    const float values[]={in->vx,in->vy,in->vz,in->pitch,in->yaw,in->forward,in->side,
                          in->smoothing,in->side_speed};
    for(float v:values)if(!finite(v))return -3;
    if(in->phase>1||in->smoothing<0||in->smoothing>100||in->side_speed<0||in->side_speed>450||
       std::fabs(in->vx)>10000||std::fabs(in->vy)>10000||std::fabs(in->vz)>10000||
       std::fabs(in->forward)>450||std::fabs(in->side)>450||
       std::fabs(in->pitch)>89||std::fabs(in->yaw)>36000)return -3;
    // Adapter policy: leave unsupported host states entirely to the original input.
    if((in->flags&1)||in->move_type!=2||in->water_level>=2||
       (in->buttons&(1u<<17))||(in->vx==0&&in->vy==0&&in->vz==0)) {
        *out=result;return 0;
    }
    const auto s=steer(in->vx,in->vy,input_yaw(*in),in->smoothing,in->side_speed,
                       in->phase!=0,in->forward!=0||in->side!=0);
    if(!finite(s.yaw)||!finite(s.side)||!finite(s.ideal)||!finite(s.correction))return -3;
    result.handled=1;result.forward=0;result.side=s.side;result.move_yaw=s.yaw;
    result.ideal=s.ideal;result.correction=s.correction;*out=result;return 1;
}
}

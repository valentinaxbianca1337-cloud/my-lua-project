#pragma once
#include "nl_movement.h"
#include "nl_directional.h"
#include "nl_prediction.h"

namespace nl_movement_v2 {
enum Mode:unsigned {Normal=0,WASD=1,Directional=2};
struct Input {
    unsigned version,bytes,mode,phase,entity_index,flags,move_type,water_level,buttons;
    float vx,vy,vz,pitch,yaw,forward,side,smoothing,side_speed;
    nl_prediction::Vec origin,mins,maxs;
    float interval,gravity,air_accelerate,max_wishspeed,max_speed,jump_impulse,surface_friction,saved_yaw;
};
struct Output {
    unsigned bytes,handled,mode,status,probes,traces;
    float forward,side,move_yaw,horizon;
};
static_assert(sizeof(Input)==140&&sizeof(Output)==40);
inline bool valid(const Input& a) {
    const float values[]={a.vx,a.vy,a.vz,a.pitch,a.yaw,a.forward,a.side,a.smoothing,a.side_speed,
        a.origin.x,a.origin.y,a.origin.z,a.mins.x,a.mins.y,a.mins.z,a.maxs.x,a.maxs.y,a.maxs.z,
        a.interval,a.gravity,a.air_accelerate,a.max_wishspeed,a.max_speed,a.jump_impulse,a.surface_friction,a.saved_yaw};
    for(float v:values)if(!std::isfinite(v))return false;
    if(a.mode>Directional||a.entity_index<1||a.entity_index>64)return false;
    if(a.mode==Directional) {
        if(a.interval<1.f/256||a.interval>1.f/16||a.gravity<0||a.gravity>4000||
           a.air_accelerate<0||a.air_accelerate>10000||a.max_wishspeed<0||a.max_wishspeed>450||
           a.max_speed<=0||a.max_speed>450||a.jump_impulse<0||a.jump_impulse>2000||
           a.surface_friction<0||a.surface_friction>2||std::fabs(a.saved_yaw)>36000)return false;
        if(std::fabs(a.origin.x)>1.e7f||std::fabs(a.origin.y)>1.e7f||std::fabs(a.origin.z)>1.e7f)return false;
        const float mn[]={a.mins.x,a.mins.y,a.mins.z},mx[]={a.maxs.x,a.maxs.y,a.maxs.z};
        for(int i=0;i<3;i++)if(mn[i]>mx[i]||std::fabs(mn[i])>128||std::fabs(mx[i])>128)return false;
    }
    return true;
}
template<class TraceHull> int calculate(const Input* a,Output* b,TraceHull& trace) {
    if(!a||!b)return -1;
    if(a->version!=2||a->bytes!=sizeof(Input)||b->bytes!=sizeof(Output))return -2;
    if(!valid(*a))return -3;
    nl_movement::Input base{1,sizeof(nl_movement::Input),a->phase,a->flags,a->move_type,a->water_level,a->buttons,
        a->vx,a->vy,a->vz,a->pitch,a->yaw,a->forward,a->side,a->smoothing,a->side_speed};
    if(a->mode==Normal)base.forward=base.side=0;
    nl_movement::Output normal{};normal.bytes=sizeof(normal);
    const int result=nl_movement::calculate(&base,&normal);
    if(result<0)return result;
    Output out{};out.bytes=sizeof(Output);out.mode=a->mode;
    if(!normal.handled){*b=out;return 0;}
    out.handled=1;out.forward=normal.forward;out.side=normal.side;out.move_yaw=normal.move_yaw;
    if(a->mode==Directional) {
        nl_prediction::Settings settings{a->origin,{a->vx,a->vy,a->vz},a->mins,a->maxs,
            a->interval,a->gravity,a->air_accelerate,a->max_wishspeed,a->max_speed,
            a->jump_impulse,a->surface_friction,a->side_speed,a->flags};
        nl_prediction::Predictor<TraceHull> predictor(settings,trace);
        nl_directional::Output direction{};
        nl_directional::Input input{std::sqrt(a->vy*a->vy+a->vx*a->vx),a->max_wishspeed,a->saved_yaw,a->side_speed};
        const bool ok=nl_directional::calculate(input,[&](float horizon,float angle){
            return predictor.collision(horizon,angle,a->saved_yaw);
        },[&](){const auto p=predictor.plane();return nl_directional::Plane{p.x,p.y,p.valid};},direction);
        out.probes=direction.probes;out.traces=predictor.traces;
        if(ok&&!predictor.failed.unavailable&&!predictor.failed.budget&&!predictor.failed.invalid) {
            out.side=direction.side;out.move_yaw=direction.yaw;out.horizon=direction.horizon;
        } else {
            // Host prediction failure leaves a usable steering output, never
            // turns an unavailable trace into an all-clear path or zero movement.
            out.mode=WASD;out.status=predictor.failed.budget?2:(predictor.failed.invalid?3:1);
        }
    }
    *b=out;return 1;
}
}

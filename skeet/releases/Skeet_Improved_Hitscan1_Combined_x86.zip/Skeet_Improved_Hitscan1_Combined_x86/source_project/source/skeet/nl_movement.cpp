#include "nl_movement.h"
#include "nl_movement_v2.h"
#include "nl_trace_host.h"
#if defined(_WIN32)
#define NL_MOVEMENT_EXPORT extern "C" __declspec(dllexport)
#define NL_MOVEMENT_CALL __cdecl
#else
#define NL_MOVEMENT_EXPORT extern "C"
#define NL_MOVEMENT_CALL
#endif

// A stateless ABI: no entity writes, hooks, ConVar changes or packet manipulation.
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_api_version() {
    return nl_movement::abi_version;
}
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_input_size() {
    return sizeof(nl_movement::Input);
}
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_output_size() {
    return sizeof(nl_movement::Output);
}
NL_MOVEMENT_EXPORT int NL_MOVEMENT_CALL nl_movement_calculate(
    const nl_movement::Input* input,nl_movement::Output* output) {
    return nl_movement::calculate(input,output);
}
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_v2_input_size(){return sizeof(nl_movement_v2::Input);}
NL_MOVEMENT_EXPORT unsigned NL_MOVEMENT_CALL nl_movement_v2_output_size(){return sizeof(nl_movement_v2::Output);}
NL_MOVEMENT_EXPORT int NL_MOVEMENT_CALL nl_movement_v2_calculate(
    const nl_movement_v2::Input* input,nl_movement_v2::Output* output) {
#if defined(_WIN32)
    // Interfaces are resolved through their named factories on the command
    // thread. No offsets, code detours, entity writes or ConVar writes here.
    nl_trace_host::Host host;
    bool attempted=false,available=false;
    auto trace=[&](nl_prediction::Vec a,nl_prediction::Vec b,nl_prediction::Vec mins,
                  nl_prediction::Vec maxs,nl_prediction::Trace& result) {
        if(!attempted){attempted=true;available=host.initialize(input->entity_index);}
        return available&&host(a,b,mins,maxs,result);
    };
#else
    auto trace=[](nl_prediction::Vec,nl_prediction::Vec,nl_prediction::Vec,nl_prediction::Vec,nl_prediction::Trace&){return false;};
#endif
    return nl_movement_v2::calculate(input,output,trace);
}

#pragma once
#include <windows.h>
#include "hitscan_points.h"
#include "hitscan_options.h"
#include "hitscan_hook.h"
#include "record_layout.h"
namespace hitscan_runtime {
inline bool readable(const void* p,std::size_t length){
 if(!p||!length)return false;const auto at=reinterpret_cast<std::uintptr_t>(p);if(at+length<at)return false;
 MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 const auto lo=reinterpret_cast<std::uintptr_t>(m.BaseAddress);return at>=lo&&at+length<=lo+m.RegionSize;
}
inline void __cdecl enrich(void* original_stack,void* caller_frame){
 const unsigned state=hitscan_options::policy.load(std::memory_order_acquire),setting=state>>1;
 if(!(state&1)||setting<=8||setting>112||!original_stack||!caller_frame)return;
 auto* bytes=static_cast<unsigned char*>(original_stack);using record_layout::u32;
 // Both original point arrays are inline and have exactly 112 slots. No
 // pointer redirection, allocation or expansion of the native frame is used.
 auto* header=bytes+0x1250;auto* begin=header+16;
 if(u32(header,0)!=reinterpret_cast<unsigned>(begin)||u32(header,8)!=reinterpret_cast<unsigned>(begin+112*24))return;
 const unsigned end=u32(header,4),start=reinterpret_cast<unsigned>(begin);
 if(end<start||end>u32(header,8)||(end-start)%24)return;
 const unsigned count=(end-start)/24,shape_count=u32(bytes,0x1ce0);
 if(!count||count>=112||!shape_count||shape_count>19)return;
 auto* shooter=reinterpret_cast<const unsigned char*>(u32(caller_frame,8));
 auto* job=reinterpret_cast<const unsigned char*>(u32(bytes,0x5c));
 if(!readable(shooter,0xe8)||!readable(job,0xd0))return;
 const auto eye=record_layout::position(shooter,0xdc);
 hitscan_points::Point candidates[112]{};hitscan_points::Capsule shapes[19]{};
 std::memcpy(candidates,begin,count*24);
 for(unsigned i=0;i<shape_count;i++){
  const auto* s=bytes+0x1cf0+i*0x90;
  // group44, endpoints48/54 and radius70 are the transformed studio shape.
  // Boxes (negative radius) are left to the existing native generator.
  shapes[i]={};if(u32(s,0)!=i)continue;
  const auto a=record_layout::position(s,0x48),b=record_layout::position(s,0x54);
  shapes[i]={{a.x,a.y,a.z},{b.x,b.y,b.z},record_layout::f32(s,0x70),i,u32(s,0x44)};
 }
 const unsigned result=hitscan_points::enrich(candidates,count,112,shapes,shape_count,{eye.x,eye.y,eye.z},u32(job,0xc0),u32(job,0xcc),setting);
 if(result>count){
  // Preserve every pre-existing point and its order, including private flags.
  std::memcpy(begin+count*24,candidates+count,(result-count)*24);
  const unsigned next=start+result*24;std::memcpy(header+4,&next,4);
  hitscan_options::added.fetch_add(result-count,std::memory_order_relaxed);
 }
 hitscan_options::scans.fetch_add(1,std::memory_order_relaxed);
}
using hitscan_hook::Plan;using hitscan_hook::make_plan;
inline bool install(unsigned char* image,std::size_t size){
 if(reinterpret_cast<unsigned>(image)!=core_image::image_base)return false;
 auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;
 Plan p{};if(!make_plan(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&enrich),p)){VirtualFree(code,0,MEM_RELEASE);return false;}
 std::memcpy(code,p.code,sizeof(p.code));DWORD old=0;
 if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(p.code))){VirtualFree(code,0,MEM_RELEASE);return false;}
 unsigned char before[7];std::memcpy(before,image+0x4eef6,7);std::memcpy(image+0x4eef6,p.jump,7);
 if(!FlushInstructionCache(GetCurrentProcess(),image+0x4eef6,7)){std::memcpy(image+0x4eef6,before,7);FlushInstructionCache(GetCurrentProcess(),image+0x4eef6,7);VirtualFree(code,0,MEM_RELEASE);return false;}
 hitscan_options::installed=true;return true;
}
}

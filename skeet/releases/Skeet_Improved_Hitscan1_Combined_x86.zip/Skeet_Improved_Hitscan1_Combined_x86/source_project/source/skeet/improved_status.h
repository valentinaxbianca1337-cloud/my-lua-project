#pragma once
#include "../improved_protocol.h"
#include <cstring>
extern "C" __declspec(dllexport) ImprovedStatus skeet_improved_status;


namespace improved_diagnostic {
inline void update(ImprovedStage stage,const char* message) {
    if(skeet_improved_status.stage==stage&&std::strcmp(skeet_improved_status.message,message)==0)return;
    unsigned i=0;
    for(;i+1<sizeof(skeet_improved_status.message)&&message[i];++i)
        skeet_improved_status.message[i]=message[i];
    skeet_improved_status.message[i]=0;
    InterlockedExchange(&skeet_improved_status.stage,stage);
}
}

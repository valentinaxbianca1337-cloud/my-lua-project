#pragma once
#include "core_image.h"
#include "record_blend_sites.h"
#include <cstring>
#include <initializer_list>
namespace record_hooks {
inline void word(unsigned char* dst,unsigned v){std::memcpy(dst,&v,4);}
struct Edit {unsigned offset,length;unsigned char before[9]{},after[9]{};};
struct Plan {unsigned char code[8192]{};Edit edits[5]{};unsigned application_return=0;};
struct Emit {
    unsigned char* p;unsigned address,pos=0;
    void bytes(std::initializer_list<unsigned char> v){for(auto b:v)p[pos++]=b;}
    void value(unsigned v){word(p+pos,v);pos+=4;}
    void jump(unsigned target){bytes({0xe9});value(target-(address+pos+4));}
    void call(unsigned target){bytes({0xe8});value(target-(address+pos+4));}
    unsigned branch(unsigned op){bytes({0x0f,static_cast<unsigned char>(op)});auto at=pos;value(0);return at;}
    void fix(unsigned at,unsigned target){word(p+at,target-(address+at+4));}
    void save(){
        // Full x87/SSE/MXCSR, GPR and flags. FXSAVE destination is aligned even
        // when the original caller's stack has only four-byte alignment.
        bytes({0x9c,0x60,0x81,0xec,0x20,2,0,0,0x8d,0x44,0x24,0x0f,0x83,0xe0,0xf0,
            0x0f,0xae,0,0x89,0x84,0x24,0x10,2,0,0});
    }
    void restore(){bytes({0x8b,0x84,0x24,0x10,2,0,0,0x0f,0xae,8,
        0x81,0xc4,0x20,2,0,0,0x61,0x9d});}
    void args(){bytes({0x8b,0xd4,0x83,0xe4,0xf0,0x83,0xec,16,0x89,0x54,0x24,12});}
    void unargs(){bytes({0x8b,0x64,0x24,12});}
    void frame(){bytes({0x8d,0x82,0x44,2,0,0});}
};
inline bool make_plan(const unsigned char* image,std::size_t size,unsigned address,
    unsigned begin_cb,unsigned apply_cb,unsigned getter_cb,unsigned reset_cb,unsigned rejected_cb,Plan& out) {
    if(!image||size!=core_image::image_size)return false;
    constexpr unsigned sites[]={0x4332ff66,0x4332ff92,0x43398505,0x43344d4e,0x4332ffb1};
    constexpr unsigned lengths[]={5,5,5,9,5};
    constexpr unsigned char original[5][9]={
        {0xe8,0x50,0x84,6,0},{0xe8,0x24,0x84,6,0},{0xe8,0xf5,0x68,5,0},
        {0x3b,0x4e,0x4c,0x0f,0x85,0x2c,0x0e,0,0},{0xe8,0x56,0x4c,1,0}};
    for(unsigned i=0;i<5;i++)if(std::memcmp(image+sites[i]-core_image::image_base,original[i],lengths[i]))return false;
    unsigned signature=2166136261u;
    for(unsigned off=0x1fec3;off<0x1ff66;off++)signature=(signature^image[off])*16777619u;
    if(signature!=0x516d3da1u)return false;
    constexpr unsigned char prefix[]={0x8b,0x0d,0x38,0xa3,0x46,0x43,0x0f,0x57,0xd2};
    if(std::memcmp(image+blend_begin-core_image::image_base,prefix,sizeof(prefix)))return false;
    for(unsigned off:blend_calls)if(image[blend_begin-core_image::image_base+off]!=0xe8)return false;
    out=Plan{};
    Emit dispatch{out.code,address};dispatch.save();dispatch.args();dispatch.frame();
    dispatch.bytes({0x89,0x44,0x24,4,0x8b,0x45,8,0x89,4,0x24,
        0x8b,0x82,0x10,2,0,0,0xf3,0x0f,0x2c,0x80,0xb0,0,0,0,0x89,0x44,0x24,8});
    dispatch.call(begin_cb);dispatch.unargs();dispatch.restore();dispatch.jump(0x433983bb);
    if(dispatch.pos>=0x200)return false;
    Emit apply{out.code+0x200,address+0x200};apply.save();apply.args();apply.frame();
    apply.bytes({0x89,4,0x24,0x89,0x6c,0x24,4});apply.call(apply_cb);apply.unargs();
    apply.bytes({0x85,0xc0});const auto legacy=apply.branch(0x84),failure=apply.branch(0x88);
    apply.restore();apply.bytes({0x8b,0x74,0x24,0x50,0x8b,0x7c,0x24,0x58});apply.jump(0x43345b83);
    apply.fix(legacy,apply.address+apply.pos);apply.restore();apply.bytes({0x3b,0x4e,0x4c});
    const auto unequal=apply.branch(0x85);apply.jump(0x43344d57);apply.fix(unequal,0x43345b83);
    apply.fix(failure,apply.address+apply.pos);apply.restore();apply.jump(0x43345eae);
    if(apply.pos>=0x200)return false;
    Emit wrapper{out.code+0x400,address+0x400};wrapper.save();wrapper.args();wrapper.frame();
    wrapper.bytes({0x8b,0x40,4,0x89,4,0x24});wrapper.call(reset_cb);
    wrapper.unargs();wrapper.restore();
    wrapper.bytes({0xff,0x74,0x24,12,0xff,0x74,0x24,12,0xff,0x74,0x24,12});
    wrapper.call(0x43344c0c);out.application_return=wrapper.address+wrapper.pos;
    wrapper.save();wrapper.args();
    wrapper.bytes({0x8b,0x82,0x3c,2,0,0,0x89,4,0x24});wrapper.call(rejected_cb);wrapper.unargs();wrapper.bytes({0x85,0xc0});
    const auto accepted=wrapper.branch(0x84);
    wrapper.restore();wrapper.bytes({0x83,0xc4,16});wrapper.jump(0x433300c8);
    wrapper.fix(accepted,wrapper.address+wrapper.pos);wrapper.restore();wrapper.bytes({0xc2,12,0});
    if(wrapper.pos>=0x400)return false;
    Emit blend{out.code+0x800,address+0x800};
    blend.bytes({0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0x78,1,0,0,0x56,0x57,
        0x8b,0x75,8,0x8b,0x55,12,0x8b,0x45,16,0x8b,0x7d,20,
        0x89,0x7c,0x24,0x58,0x83,0xc7,16,0x89,0x7c,0x24,0x50,
        0x89,0x74,0x24,0x5c,0x89,0x54,0x24,0x78,0x0f,0x57,0xe4});
    blend.jump(address+0x1000);
    constexpr auto length=blend_end-blend_begin;static_assert(0x1000+length+7<sizeof(out.code));
    std::memcpy(out.code+0x1000,image+blend_begin-core_image::image_base,length);
    for(unsigned off:blend_calls){unsigned delta;std::memcpy(&delta,image+blend_begin-core_image::image_base+off+1,4);
        word(out.code+0x1000+off+1,blend_begin+off+5+delta-(address+0x1000+off+5));}
    Emit tail{out.code+0x1000+length,address+0x1000+length};tail.bytes({0x5f,0x5e,0x8b,0xe5,0x5d,0xc3});
    for(unsigned i=0;i<5;i++) {
        auto& e=out.edits[i];e.offset=sites[i]-core_image::image_base;e.length=lengths[i];
        std::memcpy(e.before,original[i],e.length);std::memset(e.after,0x90,e.length);e.after[0]=i==3?0xe9:0xe8;
        const unsigned target=i==3?address+0x200:(i==4?address+0x400:(i==2?getter_cb:address));
        word(e.after+1,target-(sites[i]+5));
    }
    return true;
}
}

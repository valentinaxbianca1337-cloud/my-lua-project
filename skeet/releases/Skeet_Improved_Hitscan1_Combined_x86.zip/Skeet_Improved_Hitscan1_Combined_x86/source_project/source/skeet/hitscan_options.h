#pragma once
#include <atomic>
namespace hitscan_options {
inline int enabled=0,units=8; // 8=GS, 9=generic NL pattern, 10..112=custom budget.
inline bool installed=false;
inline std::atomic<unsigned> policy{0},added{0},scans{0};
inline void publish(){const unsigned n=unsigned(units<8?8:(units>112?112:units));policy.store(installed&&enabled?(1u|(n<<1)):0u,std::memory_order_release);}
}

#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

// Source hull-trace host adaptation. This is not an exact reconstruction of
// the protected NL 41468BA0/4146B2E0 movement simulator.
namespace nl_prediction {
struct Vec {float x=0,y=0,z=0;
    Vec operator+(Vec b)const{return{x+b.x,y+b.y,z+b.z};}
    Vec operator-(Vec b)const{return{x-b.x,y-b.y,z-b.z};}
    Vec operator*(float v)const{return{x*v,y*v,z*v};}
};
inline bool finite(Vec v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);}
struct Trace {float fraction=1;Vec end{},normal{};bool allsolid=false,startsolid=false;};
struct Settings {
    Vec origin,velocity,mins,maxs;
    float interval,gravity,air_accelerate,max_wishspeed,max_speed,jump_impulse,surface_friction,wish_move_speed;
    unsigned flags;
};
struct Failure {bool unavailable=false,budget=false,invalid=false;};
template<class TraceHull> class Predictor {
    const Settings& in;TraceHull& trace_hull;
    unsigned budget=1536;
    bool trace(Vec a,Vec b,Vec mins,Vec maxs,Trace& out) {
        if(failed.unavailable||failed.budget||failed.invalid)return false;
        if(!budget){failed.budget=true;return false;}
        --budget;++traces;
        if(!trace_hull(a,b,mins,maxs,out)){failed.unavailable=true;return false;}
        if(!std::isfinite(out.fraction)||out.fraction<0||out.fraction>1||!finite(out.end)||!finite(out.normal)) {
            failed.invalid=true;return false;
        }
        return true;
    }
public:
    Failure failed{};unsigned traces=0;
    Predictor(const Settings& settings,TraceHull& hull):in(settings),trace_hull(hull){}
    bool collision(float horizon,float turn,float saved_yaw) {
        auto pos=in.origin,velocity=in.velocity;
        auto mins=in.mins,maxs=in.maxs;
        // The original collision helper expands horizontal hull coordinates.
        mins.x*=1.25f;mins.y*=1.25f;maxs.x*=1.25f;maxs.y*=1.25f;
        bool ground=(in.flags&1)!=0;float yaw=saved_yaw;
        float remaining=horizon;
        for(unsigned step=0;remaining>0&&step<192;step++,remaining-=in.interval) {
            yaw+=turn;
            const float angle=yaw*.01745329238474369f;
            const float sign=std::signbit(-turn)?-1.f:1.f;
            const Vec wish{std::sin(angle)*sign,-std::cos(angle)*sign,0};
            if(ground){velocity.z=in.jump_impulse;ground=false;}
            velocity.z-=in.gravity*in.interval*.5f;
            const float speed=std::min(in.wish_move_speed,in.max_speed);
            const float capped=std::min(speed,in.max_wishspeed);
            const float current=velocity.x*wish.x+velocity.y*wish.y;
            const float add=capped-current;
            if(add>0) {
                const float accel=std::min(add,in.air_accelerate*speed*in.interval*in.surface_friction);
                velocity.x+=wish.x*accel;velocity.y+=wish.y*accel;
            }
            Trace move{};
            if(!trace(pos,pos+velocity*in.interval,mins,maxs,move))return true;
            if(move.allsolid||move.startsolid)return true;
            pos=move.end;
            if(move.fraction<1) {
                if(move.normal.z<.7f)return true;
                const float into=velocity.x*move.normal.x+velocity.y*move.normal.y+velocity.z*move.normal.z;
                velocity=velocity-move.normal*into;
                if(move.normal.z>.7f&&velocity.z<0)velocity.z=0;
                const float left=in.interval*(1.f-move.fraction);
                if(left>0) {
                    Trace slide{};
                    if(!trace(pos,pos+velocity*left,mins,maxs,slide))return true;
                    if(slide.startsolid||slide.allsolid||(slide.fraction<1&&slide.normal.z<.7f))return true;
                    pos=slide.end;
                }
            }
            velocity.z-=in.gravity*in.interval*.5f;
            Trace floor{};
            if(!trace(pos,pos+Vec{0,0,-2},mins,maxs,floor))return true;
            ground=velocity.z<=0&&floor.fraction<1&&floor.normal.z>=.7f;
            if(ground)velocity.z=0;
        }
        if(remaining>0){failed.budget=true;return true;}
        return false;
    }
    struct Plane {float x=0,y=0;bool valid=false;};
    Plane plane() {
        Vec sum{};unsigned count=0;
        // NL plane search: 64-unit radial hull sweeps, 0.314159274-radian steps.
        for(float angle=0;angle<6.2831854820251465f;angle+=.3141592741012573f) {
            Trace result{};
            const Vec delta{std::cos(angle)*64.f,std::sin(angle)*64.f,0};
            if(!trace(in.origin,in.origin+delta,in.mins,in.maxs,result))return {};
            if(result.fraction<1){sum=sum+result.normal;++count;}
        }
        if(!count)return {};
        const float average_z=sum.z/float(count);
        if(average_z>=.10000000149011612f)return {};
        const float reciprocal=1.f/float(count);
        return {sum.x*reciprocal,sum.y*reciprocal,true};
    }
};
}

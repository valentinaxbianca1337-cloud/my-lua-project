#pragma once
#include "hitscan_options.h"
namespace hitscan_controls {
using namespace SkeetSDK;
struct Widgets {PElement slider=nullptr,enabled=nullptr,warning=nullptr;};
inline void __fastcall display(void* context,void*){
 auto* slider=static_cast<Slider*>(context);if(!slider||!slider->Value)return;
 const auto value=*slider->Value;auto* out=reinterpret_cast<wchar_t*>(reinterpret_cast<unsigned char*>(slider)+0xa4);
 if(value==8||value==9){out[0]=value==8?L'G':L'N';out[1]=value==8?L'S':L'L';out[2]=0;}
 else if(value>=10&&value<=112){unsigned i=0;if(value>=100)out[i++]=L'0'+value/100;out[i++]=L'0'+(value/10)%10;out[i++]=L'0'+value%10;out[i]=0;}
}
inline bool create(const native_ui_proxy::Api& api,Child* child,Widgets& w){
 w.slider=record_controls::slider(api,child,L"Units",8,112,&hitscan_options::units,0);
 w.enabled=record_controls::checkbox(api,child,L"Hitscan",&hitscan_options::enabled);
 if(!w.slider||!w.enabled||!api.label)return false;
 auto* slider=w.slider->GetAs<Slider>();slider->Calls.emplace_back(slider,&display);display(slider,nullptr);
 auto* check=w.enabled->GetAs<Checkbox>();check->Header.Flags.SameLine=true;
 auto* p=api.allocate(sizeof(Label));if(!p)return false;std::memset(p,0,sizeof(Label));
 api.label(p,child,L"May reduce FPS");api.insert(child,false,p);w.warning=static_cast<PElement>(p);
 w.warning->GetAs<Checkbox>()->Header.Flags.Visible=false;return true;
}
inline void place(Widgets& w,Child* child){
 if(!w.enabled)return;auto* check=w.enabled->GetAs<Checkbox>();
 const bool inline_row=child->Size.x>=check->ActivateSize.x+5*child->Padding.x;
 check->Header.Flags.SameLine=inline_row;
 check->LeftPaddign=inline_row?std::max(0,child->Size.x-2*child->Padding.x-check->ActivateSize.x):0;
}
inline void frame(Widgets& w,Child* child){
 if(!w.slider||!w.enabled||!w.warning)return;
 w.enabled->GetAs<Checkbox>()->Header.Flags.Editable=hitscan_options::installed;
 w.slider->GetAs<Slider>()->Header.Flags.Editable=hitscan_options::installed;
 const bool shown=hitscan_options::installed&&hitscan_options::enabled;
 auto& visible=w.warning->GetAs<Checkbox>()->Header.Flags.Visible;
 if(visible!=shown){visible=shown;place(w,child);child->CalculateLayout();}
 display(w.slider->GetAs<Slider>(),nullptr);hitscan_options::publish();
}
}

#pragma once
#include "record_session.h"
#include "record_options.h"
#include "record_hooks.h"
#include "record_world.h"
namespace record_runtime {
inline DWORD tls_slot=TLS_OUT_OF_INDEXES;
inline record_session::Api api{};
inline unsigned application_return=0;
struct Local {record_session::Scratch session{};bool rejected_apply=false,owned_apply=false,prepared_apply=false;};
inline Local* local(bool create=false) {
    if(tls_slot==TLS_OUT_OF_INDEXES)return nullptr;
    auto* p=static_cast<Local*>(TlsGetValue(tls_slot));
    if(!p&&create) {
        p=static_cast<Local*>(HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(Local)));
        if(p&&!TlsSetValue(tls_slot,p)){HeapFree(GetProcessHeap(),0,p);return nullptr;}
    }
    return p;
}
inline record_session::Options options(unsigned v) {
    return {int(v&1),int((v>>4)&255),int((v>>1)&1),int((v>>12)&63),
        int((v>>2)&1),int((v>>2)&1),int((v>>18)&31),int((v>>3)&1),int((v>>23)&3)};
}
inline record_session::Clock clock(void* context) {
    const auto* dt=*reinterpret_cast<const float* const*>(0x4346a338);
    const auto* now=*reinterpret_cast<const float* const*>(0x43467eb8);
    if(!context||!dt||!now)return {};
    using Upper=int(__thiscall*)(void*);
    const int upper=reinterpret_cast<Upper>(0x4337ea43)(context);
    return {*dt,*now,upper,upper};
}
inline void __cdecl begin(void* context,unsigned* args,int captured_upper) {
    const auto policy=record_options::policy.load(std::memory_order_acquire);
    auto* p=local((policy&15)!=0);if(!p)return;
    const bool first=args[0]==0x4332ff6b;
    if(!(policy&15)&&first){p->session.active=false;return;}
    auto* actor=reinterpret_cast<void*>(args[1]);auto* history=reinterpret_cast<void*>(args[2]);
    int low=int(args[4]),high=int(args[5]);
    auto c=clock(context);
    // A UI change between the two selectors takes effect on the next root
    // scan. Keep this scan's prepared poses and options immutable.
    if(!(policy&15)&&(!p->session.active||p->session.context!=context||p->session.actor!=actor||
       p->session.history!=history||p->session.clock.now!=c.now||p->session.clock.interval!=c.interval||
       !record_session::current(p->session))){p->session.active=false;return;}
    if(first&&captured_upper>=high&&captured_upper<=8000000&&captured_upper-high<=256)c.native_upper=captured_upper;
    else if(!first&&p->session.active&&p->session.context==context&&p->session.actor==actor&&
            p->session.history==history&&p->session.clock.now==c.now&&p->session.clock.interval==c.interval)
        c.native_upper=p->session.clock.native_upper;
    else c.native_upper=high;
    if(record_session::begin(p->session,actor,history,context,options(policy),c,low,high,first)) {
        args[4]=low;args[5]=high;
        if(!record_session::enhanced(p->session))record_options::last_status.store(0,std::memory_order_relaxed);
    }
}
inline int __fastcall getter(const void* history,int requested,int bone,void* origin,void* matrix) {
    auto* p=local();using Native=int(__fastcall*)(const void*,int,int,void*,void*);
    if(!p||!p->session.active||p->session.history!=history||!record_session::enhanced(p->session))
        return reinterpret_cast<Native>(0x433eedff)(history,requested,bone,origin,matrix);
    return record_session::point(p->session,history,requested,bone,origin,matrix,api)?requested:-1;
}
inline int __cdecl apply_prepared(void* frame,void* caller) {
    if(record_session::u32(caller,4)!=application_return)return 0;
    auto* p=local();if(!p||!p->session.active||!record_session::enhanced(p->session))return 0;
    auto& s=p->session;
    auto* scope=reinterpret_cast<void*>(record_session::u32(frame,0x58));
    auto* actor=reinterpret_cast<void*>(record_session::u32(frame,0x54));
    auto* history=reinterpret_cast<void*>(record_session::u32(frame,0x7c));
    auto* context=reinterpret_cast<void*>(record_session::u32(caller,8));
    const int tick=int(record_session::u32(caller,12));
    if(actor!=s.actor||history!=s.history||context!=s.context)return 0;
    const auto now=clock(context);
    if(now.now!=s.clock.now||now.interval!=s.clock.interval||now.check_upper!=s.clock.check_upper||
       !record_session::apply(s,actor,history,context,tick,scope,api)) {
        p->rejected_apply=true;record_options::rejected.fetch_add(1,std::memory_order_relaxed);
        record_options::last_status.store(4,std::memory_order_relaxed);return -1;
    }
    auto* e=record_session::prepare(s,tick,api);
    p->prepared_apply=true;
    record_options::last_status.store(e?unsigned(e->status):0,std::memory_order_relaxed);
    record_options::applied.fetch_add(1,std::memory_order_relaxed);return 1;
}
inline void __cdecl reset_apply(void* context){if(auto* p=local()) {
    p->rejected_apply=p->prepared_apply=false;
    p->owned_apply=p->session.active&&p->session.context==context&&record_session::enhanced(p->session);
}}
inline int __cdecl rejected_apply(unsigned native_result){auto* p=local();if(!p)return false;
    // Native Apply can fail before reaching the blend hook. Never continue HC
    // with an unconfirmed prepared pose when this wrapper owns the session.
    if(p->owned_apply&&(!p->prepared_apply||!(native_result&255))&&!p->rejected_apply) {
        p->rejected_apply=true;record_options::rejected.fetch_add(1,std::memory_order_relaxed);
        record_options::last_status.store(4,std::memory_order_relaxed);
    }
    return p->rejected_apply;
}
inline bool install(unsigned char* image,std::size_t size) {
    if(reinterpret_cast<std::uintptr_t>(image)!=core_image::image_base)return false;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,sizeof(record_hooks::Plan::code),MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!code)return false;record_hooks::Plan plan{};
    if(!record_hooks::make_plan(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&begin),
       reinterpret_cast<unsigned>(&apply_prepared),reinterpret_cast<unsigned>(&getter),
       reinterpret_cast<unsigned>(&reset_apply),reinterpret_cast<unsigned>(&rejected_apply),plan)) {
        VirtualFree(code,0,MEM_RELEASE);return false;
    }
    std::memcpy(code,plan.code,sizeof(plan.code));DWORD old=0;
    if(!VirtualProtect(code,sizeof(plan.code),PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(plan.code))) {
        VirtualFree(code,0,MEM_RELEASE);return false;
    }
    tls_slot=TlsAlloc();if(tls_slot==TLS_OUT_OF_INDEXES){VirtualFree(code,0,MEM_RELEASE);return false;}
    api={reinterpret_cast<record_session::Blend>(code+0x800),&record_world::sweep};application_return=plan.application_return;
    for(const auto& e:plan.edits)std::memcpy(image+e.offset,e.after,e.length);
    if(!FlushInstructionCache(GetCurrentProcess(),image,size)) {
        for(const auto& e:plan.edits)std::memcpy(image+e.offset,e.before,e.length);
        FlushInstructionCache(GetCurrentProcess(),image,size);TlsFree(tls_slot);tls_slot=TLS_OUT_OF_INDEXES;
        VirtualFree(code,0,MEM_RELEASE);return false;
    }
    record_options::installed=true;return true;
}
}

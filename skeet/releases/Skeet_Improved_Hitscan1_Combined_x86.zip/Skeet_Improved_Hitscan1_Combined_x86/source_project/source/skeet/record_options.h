#pragma once
#include <atomic>
namespace record_options {
// UI writes are copied to a compact atomic policy once per render frame.
// One capture is held for an entire selector/application session.
inline int backtrack=0,max_age_ms=200,limit_records=0,record_limit=16;
inline int consistent=0,gap=8,extrapolate=0,horizon=1;
inline std::atomic<unsigned> policy{0},last_status{0},applied{0},rejected{0};
inline bool installed=false;
inline void publish() {
    const auto clamp=[](int x,int a,int b){return x<a?a:(x>b?b:x);};
    unsigned word=(backtrack?1u:0)|(limit_records?2u:0)|(consistent?4u:0)|
        (consistent&&extrapolate?8u:0);
    word|=unsigned(clamp(max_age_ms,16,200))<<4;
    word|=unsigned(clamp(record_limit,1,32))<<12;
    word|=unsigned(clamp(gap,1,16))<<18;
    word|=unsigned(clamp(horizon,1,2))<<23;
    policy.store(installed?word:0,std::memory_order_release);
}
}

"""Build closed x86 fixture DLLs; never loads them into a live process.
Run on Linux with g++, Python requirements-build.txt and requirements-test.txt.
"""
from pathlib import Path
import os,subprocess,sys
r=Path(__file__).resolve().parent;b=r/'build';b.mkdir(exist_ok=True)
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(r/'.cache/global'))
for name in ['records_plan','improved_layout','nl_movement_probe','nl_movement_v2_probe','hitscan_plan','hitscan_points_probe','test_hitscan_points']:
 sources=[str(r/f'tests/{name}.cpp')]
 if name=='nl_movement_probe':sources.append(str(r/'source/skeet/nl_movement.cpp'))
 subprocess.run([os.environ.get('CXX','g++'),'-std=c++17','-O2','-ffp-contract=off',*sources,'-o',str(b/name)],check=True)
for name in ['records_probe','record_world_probe','hitscan_probe','improved_probe','improved_frame_probe']:
 args=[sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++23','-O1','-shared','-fms-extensions','-fasm-blocks','-ffp-contract=off','-DUNICODE','-D_UNICODE','-I',str(r/'source/compat'),'-I',str(r/'source/skeet'),str(r/f'tests/{name}.cpp'),'-o',str(b/f'{name}.dll')]
 print(name,flush=True)
 with (b/f'{name}.log').open('w')as log:result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:print((b/f'{name}.log').read_text()[-12000:]);raise SystemExit(result.returncode)

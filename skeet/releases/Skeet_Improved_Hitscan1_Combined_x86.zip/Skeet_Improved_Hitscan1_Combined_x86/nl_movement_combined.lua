-- Requires the wrapper built from the accompanying source project.
-- Normal/WASD + NL Directional selection with an adapted Source hull predictor.
-- The complete protected NL movement simulator is not reconstructed.
local ffi = require("ffi")
local bit = require("bit")
if not pcall(ffi.typeof,"nl8802_v2_input") then ffi.cdef[[
void* __stdcall GetModuleHandleA(const char*);
void* __stdcall GetProcAddress(void*, const char*);
typedef struct {
 uint32_t version,bytes,mode,phase,entity_index,flags,move_type,water_level,buttons;
 float vx,vy,vz,pitch,yaw,forward,side,smoothing,side_speed;
 struct {float x,y,z;} origin,mins,maxs;
 float interval,gravity,air_accelerate,max_wishspeed,max_speed,jump_impulse,surface_friction,saved_yaw;
} nl8802_v2_input;
typedef struct {
 uint32_t bytes,handled,mode,status,probes,traces;
 float forward,side,move_yaw,horizon;
} nl8802_v2_output;
]] end
local enabled = ui.new_checkbox("MISC", "Movement", "Neverlose movement")
local mode=ui.new_combobox("MISC","Movement","NL strafe mode","Normal","WASD","Directional")
local smooth = ui.new_slider("MISC", "Movement", "NL strafe smoothing", 0, 100, 50, true, "%")
local native = ui.reference("MISC", "Movement", "Air strafe")
local abi, calculate
local held, saved, warned = false, nil, false
local records, queue, next_phase, last_player, last_command = {}, {}, 0, nil, nil
local direction_yaw=nil
local prediction_warned={}
local input, output = ffi.new("nl8802_v2_input[1]"), ffi.new("nl8802_v2_output[1]")
local function finite(v)
 return type(v)=="number" and v==v and v>-math.huge and v<math.huge
end
local function reset()
 records, queue, next_phase, last_command = {}, {}, 0, nil
 direction_yaw=nil
end
local function release()
 if held and ui.get(native)==false then ui.set(native, saved) end
 held, saved = false, nil
 reset()
end
local function resolve()
 if calculate then return true end
 -- Resolve exports only from an already loaded module; do not load a DLL here.
 local module=ffi.C.GetModuleHandleA("skeet.dll")
 if module==nil then return false end
 local function symbol(name)
  local p=ffi.C.GetProcAddress(module,name)
  if p==nil then p=ffi.C.GetProcAddress(module,"_"..name) end
  return p
 end
 local v,ins,outs,run=symbol("nl_movement_api_version"),symbol("nl_movement_v2_input_size"),
   symbol("nl_movement_v2_output_size"),symbol("nl_movement_v2_calculate")
 if v==nil or ins==nil or outs==nil or run==nil then return false end
 local version=ffi.cast("unsigned (__cdecl*)(void)",v)
 if version()~=1 or ffi.cast("unsigned (__cdecl*)(void)",ins)()~=ffi.sizeof(input[0])
  or ffi.cast("unsigned (__cdecl*)(void)",outs)()~=ffi.sizeof(output[0]) then return false end
 abi=version
 calculate=ffi.cast("int (__cdecl*)(const nl8802_v2_input*, nl8802_v2_output*)",run)
 return true
end
local function synchronize()
 local on=ui.get(enabled)
 ui.set_visible(mode,on)
 ui.set_visible(smooth,on and ui.get(mode)~="Directional")
 if not on then release(); return false end
 if not resolve() then
  release()
  ui.set(enabled,false)
  if not warned then
   warned=true
   client.error_log("NL WASD strafe: matching combined skeet.dll with movement v2 exports is required")
  end
  return false
 end
 if not held then saved=ui.get(native); held=true end
 -- Keep exactly one strafe owner active while this feature is enabled.
 if ui.get(native)~=false then ui.set(native,false) end
 if ui.get(native)~=false then release();ui.set(enabled,false);return false end
 return true
end
local function snapshot(cmd,number)
 local cached=records[number]
 if cached then return cached end
 if last_command and number<last_command then reset() end
 local pitch,yaw=client.camera_angles()
 local forward,side=cmd.forwardmove,cmd.sidemove
 if not finite(pitch) or not finite(yaw) or not finite(forward) or not finite(side) then return nil end
 if math.abs(pitch)>89 or math.abs(forward)>450 or math.abs(side)>450 then return nil end
 cached={pitch=pitch,yaw=yaw,forward=forward,side=side,phase=next_phase,mode=ui.get(mode),saved_yaw=direction_yaw or yaw}
 records[number]=cached;queue[#queue+1]=number
 if #queue>128 then records[table.remove(queue,1)]=nil end
 next_phase=1-next_phase;last_command=number
 return cached
end
local function cv(name,default)
 local c=cvar[name]
 if c then local v=c:get_float();if finite(v)then return v end end
 return default
end
local function vec(player,name,x,y,z)
 local a,b,c=entity.get_prop(player,name)
 if finite(a)and finite(b)and finite(c)then return a,b,c end
 return x,y,z
end
local function command(cmd)
 if not synchronize() then return end
 local player=entity.get_local_player()
 if not player or not entity.is_alive(player) or globals.mapname()==nil then
  reset();last_player=nil;return
 end
 if player~=last_player then reset();last_player=player end
 local flags=entity.get_prop(player,"m_fFlags")
 local move_type=entity.get_prop(player,"m_MoveType")
 local water=entity.get_prop(player,"m_nWaterLevel")
 local vx,vy,vz=entity.get_prop(player,"m_vecVelocity")
 local walk=cmd.in_speed==1 or cmd.in_speed==true
 if not finite(flags) or not finite(move_type) or not finite(water)
  or not finite(vx) or not finite(vy) or not finite(vz) then reset();return end
 if bit.band(flags,1)~=0 or move_type~=2 or water>=2 or walk then reset();return end
 if math.abs(vx)>10000 or math.abs(vy)>10000 or math.abs(vz)>10000
  or (vx==0 and vy==0 and vz==0) then return end
 local number=cmd.command_number
 if not finite(number) or number<=0 or number%1~=0 then return end
 local state=snapshot(cmd,number)
 if not state then return end
 local side_speed=math.abs(cv("cl_sidespeed",450))
 if not finite(side_speed) then return end
 side_speed=math.min(side_speed,450)
 local a=input[0]
 a.version=2;a.bytes=ffi.sizeof(a);a.phase=state.phase
 a.mode=state.mode=="Normal" and 0 or(state.mode=="Directional" and 2 or 1);a.entity_index=player
 a.flags=flags;a.move_type=move_type;a.water_level=water;a.buttons=0
 a.vx=vx;a.vy=vy;a.vz=vz;a.pitch=state.pitch;a.yaw=state.yaw
 a.forward=state.forward;a.side=state.side;a.smoothing=ui.get(smooth);a.side_speed=side_speed
 local ox,oy,oz=entity.get_prop(player,"m_vecOrigin")
 if a.mode==2 and(not finite(ox)or not finite(oy)or not finite(oz))then
  a.mode=1
  if not prediction_warned.origin then
   prediction_warned.origin=true
   client.error_log("NL Directional: player origin unavailable; WASD steering is active")
  end
 end
 a.origin.x,a.origin.y,a.origin.z=vec(player,"m_vecOrigin",0,0,0)
 a.mins.x,a.mins.y,a.mins.z=vec(player,"m_vecMins",-16,-16,0)
 a.maxs.x,a.maxs.y,a.maxs.z=vec(player,"m_vecMaxs",16,16,bit.band(flags,2)~=0 and 54 or 72)
 a.interval=globals.tickinterval();a.gravity=cv("sv_gravity",800)
 a.air_accelerate=cv("sv_airaccelerate",12);a.max_wishspeed=cv("sv_air_max_wishspeed",30)
 local maxspeed=entity.get_prop(player,"m_flMaxspeed")
 a.max_speed=finite(maxspeed)and maxspeed>0 and maxspeed or cv("sv_maxspeed",320)
 a.jump_impulse=cv("sv_jump_impulse",301.99337768555);a.surface_friction=1;a.saved_yaw=state.saved_yaw
 output[0].bytes=ffi.sizeof(output[0])
 if calculate(input,output)~=1 or output[0].handled~=1 then return end
 local out=output[0]
 if not finite(tonumber(out.move_yaw))or not finite(tonumber(out.side))then return end
 if last_command==number and state.mode=="Directional"then direction_yaw=tonumber(out.move_yaw)end
 if out.status~=0 and not prediction_warned[tonumber(out.status)]then
  prediction_warned[tonumber(out.status)]=true
  client.error_log("NL Directional: Source prediction unavailable or budget exceeded; WASD steering is active")
 end
 -- Public GameSense movement frame. Aim angles, attack, tickbase and packet flags
 -- are not written. The host remains responsible for the final command transform.
 cmd.forwardmove=tonumber(out.forward);cmd.sidemove=tonumber(out.side)
 cmd.move_yaw=tonumber(out.move_yaw)
 cmd.in_forward=0;cmd.in_back=0
 cmd.in_moveleft=out.side<0 and 1 or 0
 cmd.in_moveright=out.side>0 and 1 or 0
end
ui.set_callback(enabled,synchronize)
ui.set_callback(mode,function()reset();synchronize()end)
client.set_event_callback("setup_command",command)
client.set_event_callback("paint_ui",function()
 if held and not ui.get(enabled) then release() end
end)
client.set_event_callback("shutdown",release)
client.set_event_callback("level_init",reset)
client.set_event_callback("round_start",reset)
ui.set(enabled,false)
ui.set(mode,"WASD")
ui.set_visible(mode,false)
ui.set_visible(smooth,false)

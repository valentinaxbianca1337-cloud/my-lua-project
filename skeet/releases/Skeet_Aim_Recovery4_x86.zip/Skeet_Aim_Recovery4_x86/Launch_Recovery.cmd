@echo off
cd /d "%~dp0"
injector.exe
pause

from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parents[1];src=r/'source/skeet'
image=(src/'Binary/skeet.bin').read_bytes()
assert hashlib.sha256(image).hexdigest()=='bbb5ee98d00db63dfc5c454b238d5edd3f809976686be226dbc5f6ae55018b07'
sites={0x4332ff66:'e850840600',0x4332ff92:'e824840600',0x43398505:'e8f5680500',
       0x43344d4e:'3b4e4c0f852c0e0000',0x4332ffb1:'e8564c0100',0x4335eef6:'8d8c24e0470000'}
for address,expected in sites.items():
 b=bytes.fromhex(expected);assert image[address-0x43310000:address-0x43310000+len(b)]==b,hex(address)
roots=[src/'skeet.cpp',src/'saver.cpp',src/'dllmain.cpp',src/'nl_movement.cpp']
seen=set();queue=roots[:]
while queue:
 p=queue.pop().resolve()
 if p in seen:continue
 seen.add(p);s=p.read_text(encoding='utf-8-sig',errors='replace')
 for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"',s,re.M):
  for base in [p.parent,src,src/'MinHook',r/'source/compat']:
   dep=base/name.replace('\\','/')
   if dep.is_file():queue.append(dep);break
assert not any(p.name in ['record_runtime.h','record_hooks.h','hitscan_runtime.h','hitscan_hook.h']for p in seen)
assert 'install_records'not in(src/'skeet.cpp').read_text()
assert 'install_records'not in(src/'cs2_visuals_impl.h').read_text()
assert 'installed=false' in(src/'record_options.h').read_text()
report={'passed':True,'active_custom_aim_detours':0,'production_local_translation_units':len(roots),
 'reachable_local_files':len(seen),'record_or_hitscan_installers_unreachable':True,
 'original_record_and_point_sites':list(map(hex,sites)),'original_core_sha256':hashlib.sha256(image).hexdigest(),
 'evidence_scope':'source include graph plus original embedded resource bytes; not live game memory',
 'live_game_executed':False,'hitrate_improvement_measured':False}
(r/'reports/recovery_boundary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

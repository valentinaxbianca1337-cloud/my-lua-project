-- Recovery boundary: native aiming/movement patch modules cannot run, even
-- when an imported configuration requests them. Fresh process is required;
-- this block does not restore bytes owned by an older/foreign Lua instance.
do
 local blocked = {
  "neverlose_air_strafe", "accurate_quick_stop", "shot_delay_fix",
  "double_tap_stability_fix", "double_tap_return_fix", "animation_flag_preservation",
  "air_autostop", "scan_accuracy_optimization", "spread_autostop_fix",
  "backtrack_record_fix", "force_shot", "custom_quick_switch",
  "defensive_double_tap_on_peek", "hide_shots_fakelag_fix",
 }
 local entrypoints = {
  "handle", "apply", "_apply", "setup", "tick", "sync", "shutdown", "restore",
  "set_limit", "on_paint_ui", "on_setup_command", "on_weapon_fire", "on_grenade_thrown",
  "capture", "update", "on_post_update_clientside_animation", "restore_settings", "apply_settings",
 }
 local function off() return false end
 local function block(module)
  if type(module) ~= "table" then return end
  for _, name in ipairs(entrypoints) do
   if type(module[name]) == "function" then module[name] = off end
  end
 end
 local function lock(control)
  if not control then return end
  pcall(function()
   control:set(false)
   control:set_callback(function()
    if control:get() then control:set(false) end
   end)
  end)
  local reference
  pcall(function() reference = control.ref end)
  if type(reference) == "number" then pcall(ui.set_enabled, reference, false) end
 end
 if Class.gamesense and Class.gamesense._mem then Class.gamesense._mem.write = off end
 for _, name in ipairs(blocked) do
  block(Class.gamesense and Class.gamesense[name])
  local group = Class.ui.menu.gamesense_settings[name]
  if group then lock(group.enabled) end
 end
 if Class.gamesense and Class.gamesense._mem then Class.gamesense._mem.write = off end
 for _, name in ipairs({"extended_yaw", "flick_exploit", "defensive_aa"}) do
  block(Class.antiaim and Class.antiaim[name])
 end
 block(Class.util and Class.util.break_lc_mem)
 block(Class.misc and Class.misc.duck_peek_assist_fix)
 block(Class.misc and Class.misc.optimize_cvars)
 block(Class.misc and Class.misc.unlock_hidden_cvars)
 block(Class.visuals and Class.visuals.animation_breaker)
 local misc = Class.ui.menu.misc_tab
 if misc then
  lock(misc.animation_breaker and misc.animation_breaker.enabled)
  lock(misc.optimize_cvars and misc.optimize_cvars.enabled)
  lock(misc.event_logger and misc.event_logger.force_teammate_aimbot and misc.event_logger.force_teammate_aimbot.enabled)
 end
 local fake_lag = Class.ui.menu.gamesense_settings.fake_lag
 if fake_lag then lock(fake_lag.reset_fake_lag_on_shot) end
end

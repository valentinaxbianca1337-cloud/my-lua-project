from pathlib import Path
import json
from lupa.luajit21 import LuaRuntime
r=Path(__file__).resolve().parents[1]
l=LuaRuntime(unpack_returned_tuples=True)
compiled=l.eval('function(s) local f,e=loadstring(s); assert(f,e); return true end')
assert compiled((r/'afterglow_aim_recovery.lua').read_text())
gate=l.execute('return function(Class,ui)\n'+(r/'quarantine.lua').read_text()+'\nend')
l.execute('''
 writes=0;calls=0;locked=0;nextref=1
 ui={set_enabled=function(ref,v)assert(type(ref)=="number"and v==false);locked=locked+1 end}
 function control()
  local t={value=true,ref=nextref};nextref=nextref+1
  function t:get()return self.value end
  function t:set(v)self.value=v;if self.callback then self.callback()end end
  function t:set_callback(f)self.callback=f end
  return t
 end
 names={"neverlose_air_strafe","accurate_quick_stop","shot_delay_fix","double_tap_stability_fix",
 "double_tap_return_fix","animation_flag_preservation","air_autostop","scan_accuracy_optimization",
 "spread_autostop_fix","backtrack_record_fix","force_shot","custom_quick_switch",
 "defensive_double_tap_on_peek","hide_shots_fakelag_fix"}
 methods={"handle","apply","_apply","setup","tick","sync","shutdown","restore","set_limit",
 "on_paint_ui","on_setup_command","on_weapon_fire","on_grenade_thrown","capture","update",
 "on_post_update_clientside_animation","restore_settings","apply_settings"}
 function module()
  local t={}
  for _,k in ipairs(methods)do t[k]=function()writes=writes+1;return true end end
  return t
 end
 Class={gamesense={_mem={write=function()writes=writes+1;return true end}},
  ui={menu={gamesense_settings={fake_lag={reset_fake_lag_on_shot=control()}},
   misc_tab={animation_breaker={enabled=control()},optimize_cvars={enabled=control()},
    event_logger={force_teammate_aimbot={enabled=control()}}}}},
  antiaim={extended_yaw=module(),flick_exploit=module(),defensive_aa=module(),
   ordinary_builder=function()calls=calls+1 end},
  misc={duck_peek_assist_fix=module(),optimize_cvars=module(),unlock_hidden_cvars=module()},
  util={break_lc_mem=module()},visuals={animation_breaker=module()},
  logger={reason=function()return "correction"end}}
 for _,n in ipairs(names)do Class.gamesense[n]=module();Class.ui.menu.gamesense_settings[n]={enabled=control()}end
 ''')
gate(l.globals().Class,l.globals().ui)
l.execute('''
 for _,n in ipairs(names)do
  for _,m in ipairs(methods)do assert(Class.gamesense[n][m]() == false)end
  local c=Class.ui.menu.gamesense_settings[n].enabled;assert(not c:get());c:set(true);assert(not c:get())
 end
 for _,m in ipairs(methods)do
  for _,t in ipairs({Class.antiaim.extended_yaw,Class.antiaim.flick_exploit,Class.antiaim.defensive_aa,
   Class.misc.duck_peek_assist_fix,Class.misc.optimize_cvars,Class.misc.unlock_hidden_cvars,Class.util.break_lc_mem,Class.visuals.animation_breaker})do
   assert(t[m]()==false)
  end
 end
 assert(Class.gamesense._mem.write()==false)
 assert(writes==0);Class.antiaim.ordinary_builder();assert(calls==1)
 assert(Class.logger.reason()=="correction")
 ''')
source=(r/'afterglow_aim_recovery.lua').read_text()
assert 'setup_force_teammate_aimbot()\n\nfunction play_state_action_sound'not in source
assert '-- Reset on Shoot: bypass fakelag'not in source
assert 'if aa.current_settings.break_lc and cmd then'not in source
audit=json.loads((r/'source_audit.json').read_text());assert audit['logger_reason_mapping_unchanged']
report={'passed':True,'full_lua_compiles':True,'quarantined_modules':22,'quarantined_method_calls':14*18+8*18,
 'native_memory_writes_in_gate_tests':l.globals().writes,'config_reactivation_rejected':True,
 'ordinary_builder_and_logger_sentinels_unchanged':True,'runtime':'LuaJIT2.1',
 'full_script_executed_in_game':False,'live_prediction_or_hitrate_measured':False}
(r/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

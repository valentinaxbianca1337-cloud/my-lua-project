@echo off
cd /d "%~dp0"
injector.exe
echo.
echo Diagnostic: improved-status.txt beside skeet.dll
pause

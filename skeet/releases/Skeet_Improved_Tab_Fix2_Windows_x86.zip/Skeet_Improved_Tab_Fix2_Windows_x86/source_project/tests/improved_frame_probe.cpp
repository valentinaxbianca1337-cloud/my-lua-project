#include "pch.h"
#include "SkeetSDK/skeetsdk.h"
#include "cs2_visuals_impl.h"
extern "C" ImprovedStatus skeet_improved_status={1};
extern "C" __declspec(dllexport) unsigned improved_production_frame(
    SkeetSDK::CMenu* menu,SkeetSDK::SkeetClass_* chain,unsigned draw,
    unsigned allocate,unsigned destroy,unsigned ctor,unsigned child,unsigned append) {
    using namespace improved_tab;
    static State fixture{};fixture=State{};current_state=&fixture;fixture.menu=menu;
    native_ui_proxy::Api value{};value.allocate=reinterpret_cast<native_ui_proxy::Allocate>(allocate);
    SkeetSDK::Memory::Allocator=value.allocate;SkeetSDK::Memory::Deallocator=reinterpret_cast<SkeetSDK::ThisFn>(destroy);
    configure(value,reinterpret_cast<TabCtor>(ctor),reinterpret_cast<ChildCtor>(child),reinterpret_cast<AppendChild>(append));
    cs2_visuals::context=chain;
    cs2_visuals::original_draw=reinterpret_cast<cs2_visuals::NativeDraw>(draw);
    skeet_improved_status={1};
    const bool legacy_ready=cs2_visuals::ready(menu);
    cs2_visuals::frame(menu,nullptr,nullptr);
    return (legacy_ready?0x100:0)|skeet_improved_status.stage;
}

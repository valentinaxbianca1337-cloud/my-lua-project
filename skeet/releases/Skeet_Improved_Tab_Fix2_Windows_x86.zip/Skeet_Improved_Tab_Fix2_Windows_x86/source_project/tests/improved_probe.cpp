#include "pch.h"
#include "SkeetSDK/skeetsdk.h"
#include "native_ui_proxy.h"
#include "improved_tab_impl.h"
using namespace SkeetSDK;
extern "C" ImprovedStatus skeet_improved_status={1};
extern "C" {
__declspec(dllexport) unsigned improved_prepare(CMenu* menu) {
    using namespace improved_tab;
    static State fixture{};
    fixture=State{};current_state=&fixture;fixture.menu=menu;
    fixture.custom=menu->Tabs.back();fixture.left=0;fixture.top=5;
    fixture.width=75;fixture.base_min_height=300;
    for(auto* tab:menu->Tabs)bind(tab);
    geometry(true);
    return fixture.custom->Header.Index;
}
__declspec(dllexport) void improved_geometry(){improved_tab::geometry(true);}
__declspec(dllexport) void improved_rebind(){for(auto* tab:improved_tab::state().menu->Tabs)improved_tab::bind(tab);}
__declspec(dllexport) unsigned improved_hover(CTab* tab,int x,int y){return tab->IsHovered(Vec2{x,y});}
__declspec(dllexport) void improved_event(CTab* tab,int kind){if(kind)tab->HandleDPI();else tab->HandleResize();}
__declspec(dllexport) void improved_draw(CTab* tab,IRenderer* renderer,Vec2* origin) {
    auto** table=*reinterpret_cast<void***>(tab);
    reinterpret_cast<improved_tab::Draw>(table[4])(tab,renderer,origin);
}
__declspec(dllexport) unsigned improved_native_shape(CMenu* menu){return native_menu_shape::valid(menu);}
__declspec(dllexport) unsigned improved_construct(CMenu* menu,unsigned allocate,unsigned destroy,
                                                unsigned ctor,unsigned child,unsigned append) {
    using namespace improved_tab;
    static State fixture{};fixture=State{};current_state=&fixture;fixture.menu=menu;
    native_ui_proxy::Api value{};value.allocate=reinterpret_cast<native_ui_proxy::Allocate>(allocate);
    Memory::Allocator=value.allocate;Memory::Deallocator=reinterpret_cast<ThisFn>(destroy);
    configure(value,reinterpret_cast<TabCtor>(ctor),reinterpret_cast<ChildCtor>(child),reinterpret_cast<AppendChild>(append));
    return initialize(menu);
}
}

#pragma once
// Keep the first nine native logical IDs stable; custom tabs only append.
namespace native_menu_shape {
template<class Menu> inline bool valid(const Menu* menu) {
    if(!menu||menu->Tabs.size()<9||menu->Tabs.size()>32||menu->CurrentTab>=menu->Tabs.size())return false;
    for(unsigned i=0;i<9;i++) {
        auto* tab=menu->Tabs[i];
        if(!tab||tab->Header.Index!=int(i)||tab->Menu!=menu)return false;
        if(menu->TabsArr[i]&&menu->TabsArr[i]!=tab)return false;
    }
    return true;
}
}

"""Build the Windows x86 guard installer fixture, not a running-game test."""
from pathlib import Path
import os, subprocess, sys
r=Path(__file__).resolve().parent
(r/'build').mkdir(exist_ok=True)
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(r/'.cache/global'))
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu',
    '-std=c++23','-O2','-shared','-fms-extensions','-fasm-blocks','-ffp-contract=off',
    '-I',str(r/'source/compat'),'-I',str(r/'source/skeet'),
    str(r/'tests/shot_guard_install_probe.cpp'),'-o',str(r/'build/shot_guard_install_probe.dll')],
    env=env,check=True)
print('Run tests/validate_shot_guard.py, then tests/validate_shot_guard_install.py.')

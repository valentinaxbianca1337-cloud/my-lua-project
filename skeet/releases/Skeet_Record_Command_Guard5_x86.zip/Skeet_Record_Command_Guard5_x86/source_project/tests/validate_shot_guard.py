"""Execute emitted x86 guard against original finalizer; no game/DLL entry.

The synthesized invalid inputs test the new invariant, not their frequency or
reachability in a real match. A resolver/hit-rate improvement is not measured.
"""
from pathlib import Path
import hashlib
import itertools
import json
import random
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE, UC_HOOK_MEM_WRITE
from unicorn.x86_const import *

ROOT=Path(__file__).resolve().parents[1]
IMAGE=(ROOT/'source/skeet/Binary/skeet.bin').read_bytes()
BASE, MEM=0x43310000, 0x200000
CONTEXT,CANDIDATE,COMMAND,INTERVAL,COUNTERS,SP=(MEM+x for x in (0x1000,0x2000,0x3000,0x4000,0x5000,0x9000))
SITE,RESUME,SKIP=0x43355de9,0x43355def,0x43356146
FINAL,FINAL_END=0x433560cd,0x43356123
GPRS=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]
STATE=GPRS+[UC_X86_REG_XMM0+i for i in range(8)]+[UC_X86_REG_MXCSR,UC_X86_REG_EFLAGS,UC_X86_REG_FPCW,UC_X86_REG_FPSW,UC_X86_REG_FPTAG,UC_X86_REG_ST0,UC_X86_REG_ST1]

def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def store(u,a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def word(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]

def fixture(location, plan, alignment, rate, lerp, tick, cap, attack=0, auto=1, mxcsr=0x1f80):
    u=Uc(UC_ARCH_X86,UC_MODE_32)
    u.mem_map(BASE,len(IMAGE));u.mem_write(BASE,IMAGE)
    u.mem_map(MEM,0x10000);u.mem_map(location,4096);u.mem_write(location,plan[:1024]);u.mem_write(SITE,plan[1024:1030])
    stack=SP+alignment
    store(u,0x4346a338,INTERVAL);store(u,INTERVAL,bits(1/rate))
    store(u,CONTEXT+0x198,bits(lerp));store(u,CONTEXT+0x18c,cap);store(u,CONTEXT+0x144,0)
    store(u,CANDIDATE+0xb4,tick);store(u,stack+0x18,CANDIDATE);store(u,stack+0x28,COMMAND);store(u,stack+0x90,bits(.5))
    store(u,COMMAND+8,777);store(u,COMMAND+0x30,attack)
    # Initialize a nonempty x87 stack; guard must leave it exactly intact.
    u.mem_write(MEM+0x100,b'\xdb\xe3\xd9\xe8\xd9\xeb');u.emu_start(MEM+0x100,MEM+0x106,count=3)
    for i,r in enumerate(GPRS):u.reg_write(r,0x11223300+i)
    for i in range(8):u.reg_write(UC_X86_REG_XMM0+i,0x123456789abcdef00123456789abcdef+i)
    u.reg_write(UC_X86_REG_EDI,CONTEXT);u.reg_write(UC_X86_REG_EDX,0x11223300|auto)
    u.reg_write(UC_X86_REG_ESP,stack);u.reg_write(UC_X86_REG_MXCSR,mxcsr)
    # Generate the real native TEST DL,DL flags at the actual predecessor.
    u.emu_start(0x43355de7,SITE,count=1)
    return u,stack

def execute(u,stack,expect,attack):
    state={r:u.reg_read(r)for r in STATE};game_before=bytes(u.mem_read(MEM,0x6000));writes=[];ended=[];trace=[]
    def stop(u,a,size,user):
        # Unicorn reports a non-wrapped callback PC for some rel32 Jcc
        # transitions from >=0x80000000, although the x86 EIP is 32 bits.
        a&=0xffffffff
        if len(trace)<8:trace.append((hex(a),hex(u.reg_read(UC_X86_REG_EFLAGS))))
        if a in (RESUME,SKIP):ended.append(a);u.emu_stop()
    def wrote(u,access,a,size,value,user):writes.append((a,size))
    h=u.hook_add(UC_HOOK_CODE,stop);w=u.hook_add(UC_HOOK_MEM_WRITE,wrote)
    try:u.emu_start(SITE,0,count=20000)
    except Exception as exc:raise RuntimeError((hex(u.reg_read(UC_X86_REG_EIP)),hex(stack),hex(expect),ended,trace,hex(state[UC_X86_REG_EFLAGS]))) from exc
    finally:u.hook_del(h);u.hook_del(w)
    assert ended==[expect],(ended,hex(expect))
    assert u.reg_read(UC_X86_REG_ESP)==stack
    for r,v in state.items():assert u.reg_read(r)==v,('state',r,hex(u.reg_read(r)),hex(v))
    for a,n in writes:
        assert stack-0x300<=a and a+n<=stack or COUNTERS<=a and a+n<=COUNTERS+8,('unexpected write',hex(a),n)
    after=bytearray(u.mem_read(MEM,0x6000));before=bytearray(game_before)
    after[COUNTERS-MEM:COUNTERS-MEM+8]=before[COUNTERS-MEM:COUNTERS-MEM+8]
    assert after==before,'guard mutated candidate/context/command/native inputs'
    assert word(u,COMMAND+0x30)==attack,'manual attack was changed'
    return word(u,COUNTERS),word(u,COUNTERS+4)

def main():
    assert hashlib.sha256(IMAGE).hexdigest()=='bbb5ee98d00db63dfc5c454b238d5edd3f809976686be226dbc5f6ae55018b07'
    subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/shot_guard_plan.cpp'),'-o',str(ROOT/'build/shot_guard_plan')],check=True)
    abi=agree=negative=invalid=no_shot=0
    examples=[]
    for location in (0x50000000,0xf0000000):
        out=ROOT/'build'/f'shot_guard_{location:x}.bin'
        args=[str(ROOT/'build/shot_guard_plan'),str(ROOT/'source/skeet/Binary/skeet.bin'),str(out),hex(location),hex(COUNTERS),hex(COUNTERS+4)]
        subprocess.run(args,check=True);plan=out.read_bytes();used=struct.unpack_from('<I',plan,1030)[0]
        assert used<1024 and plan[1024]==0xe9 and plan[1029]==0x90
        cases=itertools.product((0,4,8,12),(64,128),(0,1/128,1/64,1.5/64,2/64,.1),(0,90,98,99,100,101),(100,102))
        for alignment,rate,lerp,tick,cap in cases:
            extra=int(f32(f32(max(f32(lerp),1/64)/f32(1/rate))+.5))
            denied=tick>0 and tick+extra>cap
            attack=0x801 if alignment==12 else 0
            u,stack=fixture(location,plan,alignment,rate,lerp,tick,cap,attack)
            assert execute(u,stack,SKIP if denied else RESUME,attack)==(1,int(denied));abi+=1
            # Independent execution of the original late finalizer on same inputs.
            u.reg_write(UC_X86_REG_ESI,CANDIDATE);u.emu_start(FINAL,FINAL_END,count=20000)
            assert u.reg_read(UC_X86_REG_EIP)==FINAL_END
            assigned=word(u,COMMAND+8)!=777
            assert denied==(tick>0 and not assigned)
            if assigned:assert word(u,COMMAND+8)==tick+extra
            agree+=1
            if denied and len(examples)<3:examples.append({'rate':rate,'record_tick':tick,'cap':cap,'late_command_tick':word(u,COMMAND+8),'early_guard':'skips adding automatic attack'})
        for alignment,mxcsr in itertools.product((0,4,8,12),(0x1f80,0x3f80,0x5f80,0x7f80)):
            for tick,cap in ((90,100),(100,100)):
                u,stack=fixture(location,plan,alignment,64,1/64,tick,cap,mxcsr=mxcsr)
                execute(u,stack,RESUME if tick==90 else SKIP,0);abi+=1
        for alignment in (0,4,8,12):
            u,stack=fixture(location,plan,alignment,64,0,101,100,attack=0x801,auto=0)
            assert execute(u,stack,SKIP,0x801)==(0,0);no_shot+=1
        for field,badbits in itertools.product(('interval','lerp','floor'),(0x7fc00000,0x7f800000,0xff800000)):
            u,stack=fixture(location,plan,0,64,.01,99,100)
            store(u,{'interval':INTERVAL,'lerp':CONTEXT+0x198,'floor':0x43469254}[field],badbits)
            assert execute(u,stack,SKIP,0)==(1,1);invalid+=1
        for badbits in (0,0x80000000,0xbf800000,1):
            u,stack=fixture(location,plan,0,64,.01,99,100);store(u,INTERVAL,badbits)
            assert execute(u,stack,SKIP,0)==(1,1);invalid+=1
        # Unknown bytes/profile and malformed counter addresses must never emit a patch.
        for address in (0x43355de7,0x43355de9,0x433560cd,0x4332fc35,0x4334fb71):
            changed=bytearray(IMAGE);changed[address-BASE]^=1;p=ROOT/'build/shot_guard_changed.bin';p.write_bytes(changed)
            badargs=args[:];badargs[1]=str(p);assert subprocess.run(badargs).returncode==2;negative+=1
        for counters in ((0,COUNTERS+4),(COUNTERS+1,COUNTERS+4),(COUNTERS,COUNTERS)):
            badargs=args[:-2]+list(map(hex,counters));assert subprocess.run(badargs).returncode==2;negative+=1
    report={'passed':True,'state_and_abi_cases':abi,'original_finalizer_comparisons':agree,
            'no_shot_bypasses':no_shot,'invalid_input_rejections':invalid,'profile_negative_cases':negative,
            'checks':['original native tick math','stack/GPR/EFLAGS/XMM/MXCSR/x87 preservation','manual attack unchanged','candidate/context/command unchanged','32-bit high-address relocation','unknown profile rejected'],
            'examples':examples,'game_executed':False,'hitrate_improvement_measured':False,
            'scope':'prevents adding automatic attack when positive historical command tick fails final cap; no resolver replacement'}
    (ROOT/'reports/shot_guard.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()

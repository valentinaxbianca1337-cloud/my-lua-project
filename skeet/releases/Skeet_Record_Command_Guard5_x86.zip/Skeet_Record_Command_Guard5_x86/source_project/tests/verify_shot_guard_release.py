"""Check production PE/status/resource and known VM write boundaries."""
from pathlib import Path
import hashlib,json,struct
import pefile

r=Path(__file__).resolve().parents[1]
core=(r/'source/skeet/Binary/skeet.bin').read_bytes()
regions=[(0x43355de3,0x43355e07),(0x433560cd,0x43356123),
         (0x4332fc35,0x4332fc94),(0x4334fb71,0x4334fb9e)]
entries=json.loads((r/'source/skeet/VM/bytecode.json').read_text())
count=0
for unit in entries:
    if not unit.get('main'):continue
    for item in [unit['main']]+unit.get('others',[]):
        count+=1;v=int(item['vip']);size=int(item['size'])
        assert all(not(a<v+size and v<b)for a,b in regions),('VM overwrites profile',hex(v))
cpp=(r/'source/skeet/skeet.cpp').read_text()
tail=cpp[cpp.index('bool skeet_t::extra()'):cpp.index('bool skeet_t::entry()')]
assert tail.index('recompile();')<tail.index('shot_guard::install')
assert 'record_runtime.h'not in cpp and 'install_records'not in cpp
p=pefile.PE(str(r/'build/skeet.dll'));s={x.name.decode():x.address for x in p.DIRECTORY_ENTRY_EXPORT.symbols if x.name}
assert struct.unpack('<5I',p.get_data(s['skeet_record_guard_status'],20))==(1,20,0,0,0)
improved=p.get_data(s['skeet_improved_status'],256)
assert improved[28:].startswith(b'Record Command Guard 5\0')
assert all(json.loads((r/'reports'/name).read_text())['passed']for name in
           ('source.json','recovery_boundary.json','shot_guard.json','shot_guard_install.json',
            'windows_build_validation.json','movement_v2_windows.json'))
report={'passed':True,'native_guard_site':'0x43355de9','overwritten_core_bytes':6,
        'guard_installed_after_vm_fixups':True,'vm_write_entries_checked':count,
        'vm_overlap_with_guard_profile':False,'status_export_rva':hex(s['skeet_record_guard_status']),
        'stock_record_pose_and_point_hooks_disabled':True,'embedded_core_sha256':hashlib.sha256(core).hexdigest(),
        'dll_sha256':hashlib.sha256((r/'build/skeet.dll').read_bytes()).hexdigest(),
        'injector_sha256':hashlib.sha256((r/'build/injector.exe').read_bytes()).hexdigest(),
        'game_executed':False,'hitrate_improvement_measured':False,
        'scope':'native automatic-shot record/command consistency guard; not a resolver rewrite or demonstrated fix for all correction misses'}
(r/'reports/guard5_release.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

"""Execute the Windows x86 installer with deterministic WinAPI boundaries.
No DLL entry, injector, core entry thread, or live game is executed.
"""
from pathlib import Path
import json
import struct
import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_EAX, UC_X86_REG_EIP, UC_X86_REG_ESP

ROOT=Path(__file__).resolve().parents[1]
CORE=(ROOT/'source/skeet/Binary/skeet.bin').read_bytes()
BASE,STUB,MEM,API,STOP=0x43310000,0x50000000,0x200000,0x70000000,0x71000000
SITE=0x43355de9

def main():
    cases=[]
    for dllbase in (0x10000000,0x12000000):
        for case in ('success','unknown_site','wrong_base','wrong_size','alloc_fail','protect_fail',
                     'code_flush_fail','patch_flush_fail','concurrent_branch_change'):
            pe=pefile.PE(str(ROOT/'build/shot_guard_install_probe.dll'));pe.relocate_image(dllbase)
            symbols={s.name.decode():dllbase+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
            u=Uc(UC_ARCH_X86,UC_MODE_32)
            u.mem_map(dllbase,(pe.OPTIONAL_HEADER.SizeOfImage+4095)&~4095);u.mem_write(dllbase,pe.get_memory_mapped_image())
            for a,n in ((BASE,len(CORE)),(STUB,4096),(MEM,0x10000),(API,0x10000),(STOP,4096)):u.mem_map(a,n)
            u.mem_write(BASE,CORE)
            if case=='unknown_site':u.mem_write(SITE,b'\xcc')
            original=bytes(u.mem_read(SITE,6));apis={};calls=[];flushes=[];freed=[]
            for lib in pe.DIRECTORY_ENTRY_IMPORT:
                for item in lib.imports:
                    name=item.name.decode() if item.name else str(item.ordinal)
                    a=API+16*len(apis);apis[a]=name;u.mem_write(item.address,struct.pack('<I',a))
            def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
            def api(u,a,size,user):
                name=apis[a];sp=u.reg_read(UC_X86_REG_ESP);ret=word(sp);calls.append(name)
                if name=='VirtualAlloc':
                    count,result=4,0 if case=='alloc_fail'else STUB
                    assert [word(sp+i)for i in (4,8,12,16)]==[0,4096,0x3000,4]
                elif name=='VirtualProtect':
                    count,result=4,int(case!='protect_fail')
                    assert [word(sp+i)for i in (4,8,12)]==[STUB,4096,0x20]
                    u.mem_write(word(sp+16),struct.pack('<I',4))
                elif name=='GetCurrentProcess':count,result=0,0xffffffff
                elif name=='FlushInstructionCache':
                    count=3;flushes.append((word(sp+8),word(sp+12)))
                    result=int(not(case=='code_flush_fail'and len(flushes)==1 or case=='patch_flush_fail'and len(flushes)==2))
                    if case=='concurrent_branch_change'and len(flushes)==1:u.mem_write(SITE,b'\xcc')
                elif name=='VirtualFree':
                    count,result=3,1;freed.append(word(sp+4))
                    assert [word(sp+i)for i in (4,8,12)]==[STUB,0,0x8000]
                elif name in ('memcpy','memset'):
                    count=0;dst,src,n=[word(sp+i)for i in (4,8,12)]
                    u.mem_write(dst,bytes(u.mem_read(src,n))if name=='memcpy'else bytes([src&255])*n);result=dst
                else:raise AssertionError(('unexpected imported function',name))
                u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+4+count*4);u.reg_write(UC_X86_REG_EIP,ret)
            u.hook_add(UC_HOOK_CODE,api,begin=API,end=API+0xffff)
            sp=MEM+0xf000;pointer=BASE+4 if case=='wrong_base'else BASE;size=len(CORE)-1 if case=='wrong_size'else len(CORE)
            u.mem_write(sp,struct.pack('<III',STOP,pointer,size));u.reg_write(UC_X86_REG_ESP,sp)
            u.emu_start(symbols['probe_install'],STOP,count=200000)
            assert u.reg_read(UC_X86_REG_EIP)==STOP
            assert u.reg_read(UC_X86_REG_ESP)==sp+4
            accepted=bool(u.reg_read(UC_X86_REG_EAX));status=struct.unpack('<5I',u.mem_read(symbols['skeet_record_guard_status'],20))
            assert accepted==(case=='success') and status==(1,20,int(accepted),0,0),(case,status)
            patch=bytes(u.mem_read(SITE,6))
            if accepted:
                assert patch[0]==0xe9 and patch[5]==0x90
                assert (SITE+5+struct.unpack_from('<i',patch,1)[0])&0xffffffff==STUB
                assert len(flushes)==2 and not freed
                expected=(ROOT/'build/shot_guard_50000000.bin').read_bytes()[:1024]
                emitted=bytearray(u.mem_read(STUB,1024))
                # Only the two diagnostic counter absolute addresses differ.
                offsets=[i+3 for i in range(1021)if expected[i:i+3]==b'\xf0\xff\x05']
                assert len(offsets)==2
                for offset,field in zip(offsets,(12,16)):
                    assert struct.unpack_from('<I',emitted,offset)[0]==symbols['skeet_record_guard_status']+field
                    emitted[offset:offset+4]=expected[offset:offset+4]
                assert emitted==expected
            else:
                assert patch==(b'\xcc'+original[1:] if case=='concurrent_branch_change'else original),case
                if case not in ('unknown_site','wrong_base','wrong_size','alloc_fail'):assert freed==[STUB],case
            if case=='patch_flush_fail':assert len(flushes)==3,'rollback must flush original bytes'
            expected_core=bytearray(CORE)
            expected_core[SITE-BASE:SITE-BASE+6]=patch
            assert bytes(u.mem_read(BASE,len(CORE)))==expected_core,'installer modified another core site'
            cases.append({'dll_base':hex(dllbase),'case':case,'installed':accepted,'flushes':len(flushes)})
    report={'passed':True,'installer_cases':len(cases),'cases':cases,'game_executed':False,
            'scope':'actual compiled installer with WinAPI stubs: byte guards, RX transition, patch/rollback/cache, exported status'}
    (ROOT/'reports/shot_guard_install.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':True,'installer_cases':len(cases)}))

if __name__=='__main__':main()

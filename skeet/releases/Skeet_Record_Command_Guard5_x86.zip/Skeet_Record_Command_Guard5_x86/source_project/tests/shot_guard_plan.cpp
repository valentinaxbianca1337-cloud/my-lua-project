#include "../source/skeet/shot_guard_plan.h"
#include <fstream>
#include <iterator>
#include <string>
#include <vector>
int main(int argc,char** argv) {
    if(argc!=6)return 1;
    std::ifstream in(argv[1],std::ios::binary);
    std::vector<unsigned char> image((std::istreambuf_iterator<char>(in)),{});
    shot_guard::Plan plan{};
    if(!shot_guard::make_plan(image.data(),image.size(),std::stoul(argv[3],nullptr,0),
        std::stoul(argv[4],nullptr,0),std::stoul(argv[5],nullptr,0),plan))return 2;
    std::ofstream out(argv[2],std::ios::binary);
    out.write(reinterpret_cast<char*>(plan.code),sizeof(plan.code));
    out.write(reinterpret_cast<char*>(plan.patch),sizeof(plan.patch));
    out.write(reinterpret_cast<char*>(&plan.used),sizeof(plan.used));
    return out?0:3;
}

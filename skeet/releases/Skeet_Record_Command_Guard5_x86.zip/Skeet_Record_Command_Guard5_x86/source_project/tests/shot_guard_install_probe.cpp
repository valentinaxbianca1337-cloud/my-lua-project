#include <Windows.h>
#include "../source/skeet/shot_guard_runtime.h"
extern "C" __declspec(dllexport) int probe_install(unsigned char* image,unsigned size) {
    skeet_record_guard_status={1,sizeof(shot_guard::Status),0,0,0};
    return shot_guard::install(image,size,skeet_record_guard_status);
}

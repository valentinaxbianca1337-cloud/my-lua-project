"""Read-only source/package checks; does not compile or load any native code."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source/skeet'
REMOVED=[
 'scan_patch.h','precision_patch.h','record_eligibility.h',
 'body_preference.h','body_preference_patch.h','dt_accuracy.h',
 'dt_accuracy_client.h','dt_accuracy_patch.h','motion_patch.h',
 'motion_plan.h','motion_records.h','motion_trace.h','motion_settings.h',
 'motion_blend_sites.h','Binary/skeet_cv.bin']

def main():
    core=(SRC/'Binary/skeet.bin').read_bytes()
    digest=hashlib.sha256(core).hexdigest()
    assert digest=='bbb5ee98d00db63dfc5c454b238d5edd3f809976686be226dbc5f6ae55018b07'
    assert len(core)==0x2fc000
    for relative in REMOVED:assert not (SRC/relative).exists(),relative
    patterns=[Path(p).stem for p in REMOVED]+['__CBIN','skeet_cv.bin']
    local_includes=0
    for path in (ROOT/'source').rglob('*'):
        if not path.is_file() or path.suffix not in {'.h','.cpp','.rc','.vcxproj','.filters'}:continue
        text=path.read_text(encoding='utf-8-sig',errors='replace')
        for name in patterns:
            assert not re.search(r'\b'+re.escape(name)+r'\b',text),(str(path),name)
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',text,re.M):
            if include in {'Windows.h','winres.h'}:continue
            assert any((folder/include.replace('\\','/')).is_file()
                       for folder in [path.parent,SRC,SRC/'MinHook',ROOT/'source/compat']),(str(path),include)
            local_includes+=1
    resource=(SRC/'skeet.rc').read_text(encoding='utf-8-sig')
    assert len(re.findall(r'IDR_BINARY1\s+BINARY\s+"Binary/skeet.bin"',resource))==1
    expected=int(re.search(r'return hash == (0x[0-9a-f]+)ULL;',
                          (SRC/'core_image.h').read_text()).group(1),16)
    fingerprint=0xcbf29ce484222325
    for byte in core:fingerprint=((fingerprint^byte)*0x100000001b3)&0xffffffffffffffff
    assert fingerprint==expected
    ns={'m':'http://schemas.microsoft.com/developer/msbuild/2003'}
    project_paths=0
    for project in (ROOT/'source').rglob('*.vcxproj'):
        tree=ET.parse(project)
        for tag in ['ClInclude','ClCompile','None','ResourceCompile']:
            for element in tree.findall('.//m:'+tag,ns):
                name=element.get('Include')
                if not name:continue
                assert (project.parent/name.replace('\\','/')).is_file(),(str(project),name)
                project_paths+=1
    for path in ROOT.rglob('*'):
        if path.relative_to(ROOT).parts[0] in {'build','.cache'}:continue
        assert path.suffix.lower() not in {'.dll','.exe','.obj','.o','.res','.pdb'},str(path)
    cpp=(SRC/'skeet.cpp').read_text()
    assert 'overlay_patch::patch_calls' in cpp and 'recompile();' in cpp
    assert 'cs2_visuals::install' in cpp
    assert (SRC/'nl_movement.cpp').is_file() and (ROOT/'lua/nl_movement.lua').is_file()
    assert 'nl_movement.cpp' in (ROOT/'build_windows.py').read_text()
    assert ET.parse(SRC/'skeet.vcxproj').find('.//m:ClCompile[@Include="nl_movement.cpp"]',ns) is not None
    assert 'install_records' not in cpp
    assert 'record_runtime::install' not in (SRC/'cs2_visuals_impl.h').read_text()
    assert (SRC/'record_runtime.h').is_file() and (SRC/'record_controls.h').is_file()
    assert 'shot_guard::install' in cpp
    result={'passed':True,'scope':'original embedded resource; one native automatic-shot command guard; custom record/point detours absent; movement exports dormant without adapter',
            'original_core_sha256':digest,'core_bytes':len(core),
            'fingerprint':hex(fingerprint),'removed_source_files':REMOVED,
            'local_includes_checked':local_includes,'project_paths_checked':project_paths,
            'source_check_only':True,'game_tested':False}
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()

#pragma once
#include "core_image.h"
#include <cstring>
#include <initializer_list>

// One narrowly scoped invariant: do not add an automatic attack for a positive
// historical tick if the existing command finalizer would refuse that tick.
// This does not resolve enemy angles or replace any bone/record calculation.
namespace shot_guard {
inline constexpr unsigned site=0x43355de9, resume=0x43355def, skip=0x43356146;
struct Plan {unsigned char code[1024]{};unsigned used=0;unsigned char patch[6]{};};
inline void word(unsigned char* p,unsigned v){std::memcpy(p,&v,4);}
struct Emit {
    unsigned char* p;unsigned address,pos=0;
    void bytes(std::initializer_list<unsigned char> v){for(auto x:v)p[pos++]=x;}
    void value(unsigned x){word(p+pos,x);pos+=4;}
    void jump(unsigned target){bytes({0xe9});value(target-(address+pos+4));}
    void call(unsigned target){bytes({0xe8});value(target-(address+pos+4));}
    unsigned branch(unsigned op){bytes({0x0f,static_cast<unsigned char>(op)});auto at=pos;value(0);return at;}
    void fix(unsigned at,unsigned target){word(p+at,target-(address+at+4));}
    void save(){
        bytes({0x9c,0x60,0x81,0xec,0x20,2,0,0,0x8d,0x44,0x24,0x0f,0x83,0xe0,0xf0,
            0x0f,0xae,0,0x89,0x84,0x24,0x10,2,0,0});
    }
    void restore(){bytes({0x8b,0x84,0x24,0x10,2,0,0,0x0f,0xae,8,
        0x81,0xc4,0x20,2,0,0,0x61,0x9d});}
    void increment(unsigned address){bytes({0xf0,0xff,0x05});value(address);}
};
inline bool profile(const unsigned char* image,std::size_t size) {
    if(!image||size!=core_image::image_size)return false;
    struct Region {unsigned address,length;std::uint64_t hash;};
    constexpr Region regions[]={
        {0x43355de3,0x24,0x4192daa4db30fe62ULL}, // test DL; JZ; original attack-bit construction
        {0x433560cd,0x56,0xfc2492839a807540ULL}, // unchanged final command-tick assignment
        {0x4332fc35,0x5f,0xd95afa69ee8f06a3ULL}, // original scalar max helper
        {0x4334fb71,0x2d,0x0ed27a840ff0a423ULL} // initialization of the rounding spill
    };
    for(auto r:regions){
        std::uint64_t hash=0xcbf29ce484222325ULL;
        for(unsigned i=0;i<r.length;i++)hash=(hash^image[r.address-core_image::image_base+i])*0x100000001b3ULL;
        if(hash!=r.hash)return false;
    }
    return true;
}
inline bool make_plan(const unsigned char* image,std::size_t size,unsigned address,
                      unsigned considered,unsigned rejected,Plan& out) {
    if(!profile(image,size)||!address||!considered||!rejected||
       (considered&3)||(rejected&3)||considered==rejected)return false;
    out=Plan{};Emit e{out.code,address};
    // Preserve the native no-shot branch exactly, before touching any state.
    auto no_shot=e.branch(0x84);e.fix(no_shot,skip);
    e.save();e.increment(considered);
    // ESP is now original ESP - 0x244. Candidate lives at original [ESP+18].
    e.bytes({0x8b,0x9c,0x24,0x5c,2,0,0,0x8b,0x9b,0xb4,0,0,0,0x85,0xdb});
    const auto current_pose=e.branch(0x8e); // selected_tick <= 0: retain native behavior
    // Validate finite inputs without executing arithmetic on NaNs/zero dt.
    e.bytes({0x8b,0x35});e.value(0x4346a338);e.bytes({0x8b,6,0x85,0xc0});
    const auto bad_interval=e.branch(0x8e);
    e.bytes({0x25,0,0,0x80,0x7f,0x3d,0,0,0x80,0x7f});
    const auto infinite_interval=e.branch(0x83);
    e.bytes({0x85,0xc0});const auto subnormal_interval=e.branch(0x84);
    e.bytes({0x8b,0x87,0x98,1,0,0,0x25,0,0,0x80,0x7f,0x3d,0,0,0x80,0x7f});
    const auto bad_lerp=e.branch(0x83);
    e.bytes({0xa1});e.value(0x43469254);
    e.bytes({0x25,0,0,0x80,0x7f,0x3d,0,0,0x80,0x7f});const auto bad_floor=e.branch(0x83);
    // Mirror the exact native helper/divide/rounding sequence and operands.
    e.bytes({0xf3,0x0f,0x10,0x0d});e.value(0x43469254);
    e.bytes({0xf3,0x0f,0x10,0x87,0x98,1,0,0});e.call(0x4332fc35);
    e.bytes({0xf3,0x0f,0x5e,6,0xf3,0x0f,0x58,0x84,0x24,0xd4,2,0,0,
             0xf3,0x0f,0x2c,0xc8,0x85,0xc9});
    const auto bad_conversion=e.branch(0x88);
    e.bytes({0x03,0xcb});const auto tick_overflow=e.branch(0x80);
    e.bytes({0x8b,0x87,0x8c,1,0,0,0x03,0x87,0x44,1,0,0});
    const auto cap_overflow=e.branch(0x80);
    e.bytes({0x3b,0xc8});const auto outside_cap=e.branch(0x8f);
    const auto allowed=address+e.pos;e.fix(current_pose,allowed);
    e.restore();e.jump(resume);
    const auto denied=address+e.pos;
    for(auto at:{bad_interval,infinite_interval,subnormal_interval,bad_lerp,bad_floor,
                 bad_conversion,tick_overflow,cap_overflow,outside_cap})e.fix(at,denied);
    e.increment(rejected);e.restore();e.jump(skip);
    if(e.pos>sizeof(out.code))return false;
    out.used=e.pos;out.patch[0]=0xe9;word(out.patch+1,address-(site+5));out.patch[5]=0x90;
    return true;
}
}

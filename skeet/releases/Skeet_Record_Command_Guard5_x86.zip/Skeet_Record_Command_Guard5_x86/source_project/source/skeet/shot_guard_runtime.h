#pragma once
#include "shot_guard_plan.h"
#include <Windows.h>

namespace shot_guard {
// Read-only diagnostics exported by the wrapper. Counters are incremented by
// emitted LOCK INC instructions once per potential automatic shot, not per ray.
struct Status {unsigned version,size;volatile LONG installed,considered,rejected;};
static_assert(sizeof(Status)==20);
inline bool install(unsigned char* image,std::size_t size,Status& status) {
    if(reinterpret_cast<std::uintptr_t>(image)!=core_image::image_base||!profile(image,size))return false;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!code)return false;
    Plan plan{};
    if(!make_plan(image,size,reinterpret_cast<unsigned>(code),
        reinterpret_cast<unsigned>(&status.considered),reinterpret_cast<unsigned>(&status.rejected),plan)) {
        VirtualFree(code,0,MEM_RELEASE);return false;
    }
    std::memcpy(code,plan.code,plan.used);DWORD old=0;
    if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,plan.used)) {
        VirtualFree(code,0,MEM_RELEASE);return false;
    }
    constexpr unsigned char before[]={0x0f,0x84,0x57,3,0,0};
    auto* target=image+site-core_image::image_base;
    if(std::memcmp(target,before,sizeof(before))) {VirtualFree(code,0,MEM_RELEASE);return false;}
    // Initialization precedes the original core entry thread. No active game
    // thread can enter this new image while the six-byte branch is replaced.
    std::memcpy(target,plan.patch,sizeof(plan.patch));
    if(!FlushInstructionCache(GetCurrentProcess(),target,sizeof(plan.patch))) {
        std::memcpy(target,before,sizeof(before));FlushInstructionCache(GetCurrentProcess(),target,sizeof(before));
        VirtualFree(code,0,MEM_RELEASE);return false;
    }
    InterlockedExchange(&status.installed,1);return true;
}
}
extern "C" __declspec(dllexport) inline shot_guard::Status skeet_record_guard_status={1,sizeof(shot_guard::Status),0,0,0};

#include "../source/skeet/hitscan_points.h"
#include <cassert>
#include <iostream>
#include <limits>
using namespace hitscan_points;
int main(){
 struct Buffer{unsigned before=0x12345678;Point p[112]{};unsigned after=0x87654321;}buf;
 const Capsule shape{{100,0,-5},{100,0,5},5,6,2};const Vec eye{0,0,10};unsigned cases=0;
 for(unsigned setting:{1,2,4,8,9,10,32,64,112})for(unsigned limit:{4,16,64,112}){
  buf=Buffer{};buf.p[0]={{100,0,0},0x11223344,2,0x55667788};buf.p[1]={{102.5f,0,0},0xaabbccdd,2,0x8899aabb};Point original[2];std::memcpy(original,buf.p,sizeof(original));
  unsigned nl=0;auto n=enrich(buf.p,2,limit,&shape,1,eye,4,4,setting,&nl);
  assert(nl>=2&&nl<=limit);
  assert(n<=limit&&n>=2&&std::memcmp(buf.p,original,sizeof(original))==0);
  assert(n==std::max(2u,std::min(limit,setting)));
  assert(nl==std::min(limit,5u));
  for(unsigned i=2;i<n;i++)assert(inside(buf.p[i].position,shape)&&buf.p[i].group==2&&buf.p[i].auxiliary==original[0].auxiliary&&buf.p[i].flags==original[0].flags);
  assert(buf.before==0x12345678&&buf.after==0x87654321);++cases;
 }
 for(unsigned scenario=0;scenario<9;scenario++){
  Capsule s=shape;buf=Buffer{};buf.p[0]={{100,0,0},0,2,0};buf.p[1]={{102.5f,0,0},0,2,0};unsigned mask=4,multi=4,mode=112;
  if(scenario==0)mask=0;if(scenario==1)multi=0;if(scenario==2)s.radius=-1;if(scenario==3)s.radius=std::numeric_limits<float>::quiet_NaN();
  if(scenario==4)buf.p[0].position.x=std::numeric_limits<float>::infinity();if(scenario==5)s.group=8;if(scenario==6)buf.p[1].position.x=100;if(scenario==7)mode=0;if(scenario==8)mode=113;
  auto saved=buf;assert(enrich(buf.p,2,112,&s,1,eye,mask,multi,mode)==2&&std::memcmp(&buf,&saved,sizeof(buf))==0);++cases;
 }
 // Selection respects the native feet mask and the NL routine's exclusions.
 for(unsigned index:{1,2,13,14}){Capsule s=shape;s.index=index;Vec out[3];assert(nl_pattern(s,eye,.5f,out)==0);++cases;}
 for(unsigned index:{11,12}){Capsule s=shape;s.index=index;buf=Buffer{};buf.p[0]={{100,0,0},0,2,0};buf.p[1]={{102.5,0,0},0,2,0};assert(enrich(buf.p,2,112,&s,1,eye,4,4,112)==2);assert(enrich(buf.p,2,112,&s,1,eye,0x200,0x200,112)==112);++cases;}
 std::cout<<"{\"passed\":true,\"portable_cases\":"<<cases<<",\"canaries_and_original_prefix_preserved\":true,\"game_tested\":false}\n";
}

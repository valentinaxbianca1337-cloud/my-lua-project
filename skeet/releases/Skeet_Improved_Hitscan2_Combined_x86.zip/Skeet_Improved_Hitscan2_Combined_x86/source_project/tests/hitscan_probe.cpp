#include "../source/skeet/hitscan_runtime.h"
extern "C" {
__declspec(dllexport) void hitscan_policy_probe(unsigned value){hitscan_options::policy.store(value);}
__declspec(dllexport) void hitscan_enrich_probe(void* stack,void* frame){hitscan_runtime::enrich(stack,frame);}
__declspec(dllexport) unsigned hitscan_counts_probe(){return hitscan_options::reference_counts.load();}
__declspec(dllexport) unsigned hitscan_added_probe(){return hitscan_options::added.load();}
}

"""Regression: original native hover/mouse code, controlled constructors only."""
from pathlib import Path
import importlib.util,json
r=Path(__file__).resolve().parents[1]
def fixture(root):
 spec=importlib.util.spec_from_file_location('ui',root/'tests/validate_improved_native.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
 u,s,word,put,floats,call,original=f.machine(1.,32)
 assert call('improved_construct',[f.MENU,f.ALLOC,f.FREE,f.CTOR,f.CHILD,f.APPEND])==1
 return f,u,s,word,put,floats,call
f,u,s,word,put,floats,call=fixture(r)
slider,check=[x[0]for x in s['widgets'][8:10]];cursor=f.MEM+0x61000;msg=cursor+0x20;cases=0
for dpi in [.75,1.,1.25,1.5,2.,3.]:
 for width in [400,450,500,640,800,1200,640]:
  floats(0x4346d490,dpi);put(f.MENU+0x14,round(width*dpi));put(f.MENU+0x18,round(700*dpi));call('improved_geometry')
  call('hitscan_controls_counts',[24,37]);call('hitscan_controls_frame',[1,64,1])
  # Render uses Pos.x, Pos.y+3 and the DPI-scaled 8x8 glyph size.
  put(cursor,word(check+0x20)+max(1,word(check+0x60)//2));put(cursor+4,word(check+0x24)+3+max(1,word(check+0x64)//2))
  assert call('',[cursor],this=check,address=0x4339c9e1)&255
  assert not(call('',[cursor],this=slider,address=0x433ba3f2)&255)
  for before in [1,0]:
   saved=word(s['widgets'][8][4]);put(msg+4,0x201)
   assert not(call('',[msg,cursor],this=slider,address=0x433e5250)&255)
   assert call('',[msg,cursor],this=check,address=0x4333043a)&255
   put(msg+4,0x202);assert call('',[msg,cursor],this=check,address=0x4333043a)&255
   assert word(s['widgets'][9][4])==int(not before)
   assert word(s['widgets'][8][4])==saved
   assert call('hitscan_controls_publish')==(0 if before else(1|(64<<1)))
   cases+=1
for gs,nl,value,expected in [(0,0,8,'8'),(0,0,9,'9'),(24,37,24,'GS (24)'),(24,37,37,'NL (37)'),(24,37,38,'38'),(32,32,1,'GS/NL (32)'),(53,67,67,'NL (67)')]:
 call('hitscan_controls_counts',[gs,nl]);call('hitscan_controls_frame',[1,value,1])
 assert word(slider+0x94)==(gs or 1)
 assert bytes(u.mem_read(slider+0xa4,64)).decode('utf-16-le').split('\0')[0]==expected
# A full native buffer must not create a zero-length native slider range.
call('hitscan_controls_counts',[112,112]);call('hitscan_controls_frame',[1,1,1])
assert word(slider+0x94)<word(slider+0x90) and word(s['widgets'][8][4])==112
assert bytes(u.mem_read(slider+0x14,1))==b'\0'
assert bytes(u.mem_read(slider+0xa4,24)).decode('utf-16-le')=='GS/NL (112)\0'
# Optional baseline proof is local-only, not required by a portable source zip.
old=Path('/workspace/output/Skeet_Improved_Hitscan_Source_8802');regression=None
if old.exists():
 of,ou,os,ow,op,ofs,oc=fixture(old);a,b=[x[0]for x in os['widgets'][8:10]];point=of.MEM+0x61000
 op(point,ow(b+0x20)+4);op(point+4,ow(b+0x24)+7)
 regression=bool(oc('',[point],this=a,address=0x433ba3f2)&255);assert regression
report={'passed':True,'native_checkbox_square_toggles':cases,'native_slider_declines_square_click':True,'numeric_marker_cases':8,'full_buffer_range_safe':True,'old_overlap_reproduced':regression,'boundaries':['allocation/constructors','renderer unused; native mouse and value-set callbacks executed'],'game_tested':False}
(r/'reports/hitscan_input.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

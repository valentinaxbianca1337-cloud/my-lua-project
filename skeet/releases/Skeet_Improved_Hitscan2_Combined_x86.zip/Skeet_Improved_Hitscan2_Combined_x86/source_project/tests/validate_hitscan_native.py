"""Execute the emitted hook, compiled callback, and original GS vector/loop code.
No DLL entry, injector, damage trace or actual game is executed.
"""
from pathlib import Path
import struct,json,subprocess
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
r=Path(__file__).resolve().parents[1];core=(r/'source/skeet/Binary/skeet.bin').read_bytes();base=0x43310000
pe=pefile.PE(str(r/'build/hitscan_probe.dll'));pb=pe.OPTIONAL_HEADER.ImageBase
sym={x.name.decode().lstrip('_@').split('@')[0]:pb+x.address for x in pe.DIRECTORY_ENTRY_EXPORT.symbols if x.name}
mem=0x200000;api=0x600000;sp=mem+0x60000;frame=sp+0x8100;shooter=mem+0x1000;job=mem+0x2000;stop=api+0x1000
class Case:
 def __init__(self,code=0x50000000,offset=0):
  self.code=code;self.stack=sp+offset;self.u=u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(base,len(core));u.mem_write(base,core)
  u.mem_map(pb,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(pb,pe.get_memory_mapped_image());u.mem_map(mem,0x100000);u.mem_map(api,0x2000);u.mem_map(code,4096)
  self.queries=0
  self.put=lambda a,v:u.mem_write(a,struct.pack('<I',v&0xffffffff))
  self.word=lambda a:struct.unpack('<I',u.mem_read(a,4))[0]
  self.floats=lambda a,*v:u.mem_write(a,struct.pack('<'+'f'*len(v),*v))
  self.imports={}
  for lib in pe.DIRECTORY_ENTRY_IMPORT:
   for item in lib.imports:
    address=api+len(self.imports)*16;self.put(item.address,address);self.imports[address]=item.name.decode()if item.name else '#'+str(item.ordinal)
  def boundary(u,a,size,user):
   if a not in self.imports:return
   s=u.reg_read(UC_X86_REG_ESP);name=self.imports[a];result=0;clean=4
   if name=='VirtualQuery':
    pointer,info,n=[self.word(s+i)for i in [4,8,12]];assert n==28;self.queries+=1;clean=16
    if mem<=pointer<mem+0x100000:
     for off,v in [(0,mem),(4,mem),(8,4),(12,0x100000),(16,0x1000),(20,4),(24,0x20000)]:self.put(info+off,v)
     result=28
   elif name in ['memset','memcpy','memmove']:
    dst,src,n=[self.word(s+i)for i in [4,8,12]];u.mem_write(dst,bytes([src&255])*n if name=='memset'else bytes(u.mem_read(src,n)));result=dst
   else:raise AssertionError(name)
   u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,s+clean);u.reg_write(UC_X86_REG_EIP,self.word(s))
  u.hook_add(UC_HOOK_CODE,boundary)
  out=r/'build'/f'hitscan_plan_{code:x}.bin'
  subprocess.run([str(r/'build/hitscan_plan'),str(r/'source/skeet/Binary/skeet.bin'),str(out),hex(code),hex(sym['hitscan_enrich_probe'])],check=True)
  data=out.read_bytes();assert len(data)==263;u.mem_write(code,data[:256]);u.mem_write(0x4335eef6,data[256:])
  s=self.stack;self.put(frame+8,shooter);self.floats(shooter+0xdc,0,0,10);self.put(s+0x5c,job)
  self.put(job+0xc0,6);self.put(job+0xcc,6);self.put(s+0x48,24)
  # Execute the original input-vector initializer.
  self.call_address(0x43365490,ecx=s+0x1250);self.put(s+0x1ce0,7)
  for index,group,a,b,radius in [(0,1,(100,0,0),(100,0,10),4),(6,2,(100,0,-20),(100,0,-10),5)]:
   p=s+0x1cf0+index*0x90;self.put(p,index);self.put(p+0x44,group);self.floats(p+0x48,*a,*b);self.floats(p+0x70,radius)
  self.begin=s+0x1260;original=[(100,0,5,0,1,0),(102.4,0,5,.5,1,0),(100,0,-15,0,2,0),(103,0,-15,.5,2,0)]
  for i,p in enumerate(original):u.mem_write(self.begin+i*24,struct.pack('<4f2I',*p))
  self.put(s+0x1254,self.begin+len(original)*24);self.original=bytes(u.mem_read(self.begin,96))
 def call_address(self,address,args=(),ecx=0):
  call_sp=mem+0x50000
  for i,v in enumerate([stop,*args]):self.put(call_sp+4*i,v)
  self.u.reg_write(UC_X86_REG_ESP,call_sp);self.u.reg_write(UC_X86_REG_ECX,ecx);self.u.emu_start(address,stop,count=1000000)
  assert self.u.reg_read(UC_X86_REG_EIP)==stop and self.u.reg_read(UC_X86_REG_ESP)==call_sp+4
  return self.u.reg_read(UC_X86_REG_EAX)
 def policy(self,enabled,units):self.call_address(sym['hitscan_policy_probe'],[int(enabled)|(units<<1)])
 def run(self):
  u=self.u;s=self.stack;done=[]
  u.mem_write(api+0x1300,b'\xdb\xe3\xd9\xe8\xd9\xeb');u.emu_start(api+0x1300,api+0x1306,count=3)
  gprs=[UC_X86_REG_EBX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI]
  for i,reg in enumerate(gprs):u.reg_write(reg,0x12340000+i)
  for i in range(8):u.reg_write(UC_X86_REG_XMM0+i,0x3f800000400000004040000040800000+i)
  u.reg_write(UC_X86_REG_ESP,s);u.reg_write(UC_X86_REG_EBP,frame);u.reg_write(UC_X86_REG_MXCSR,0x3f80);u.reg_write(UC_X86_REG_EFLAGS,0x246)
  registers=gprs+[UC_X86_REG_EBP,UC_X86_REG_MXCSR,UC_X86_REG_FPCW,UC_X86_REG_FPSW,UC_X86_REG_FPTAG,UC_X86_REG_ST0,UC_X86_REG_ST1]+[UC_X86_REG_XMM0+i for i in range(8)]
  saved={reg:u.reg_read(reg)for reg in registers}
  def stop_at(u,a,size,user):
   if(a&0xffffffff)==0x4335eefd:assert u.reg_read(UC_X86_REG_EFLAGS)==0x246
   if(a&0xffffffff)==0x4335ef02:done.append(True);u.emu_stop()
  h=u.hook_add(UC_HOOK_CODE,stop_at);u.emu_start(0x4335eef6,stop,count=1000000);u.hook_del(h)
  assert done and u.reg_read(UC_X86_REG_ESP)==s
  for reg,value in saved.items():assert u.reg_read(reg)==value,('CPU state',reg,hex(value),hex(u.reg_read(reg)))
  assert self.word(s+0x47e0)==s+0x47f0 and self.word(s+0x47e8)==s+0x47f0+112*56
  count=(self.word(s+0x1254)-self.begin)//24
  assert bytes(u.mem_read(self.begin,96))==self.original and count<=112
  return count
 def native_reads(self,count):
  # Execute the original worker's point dispatch up to its evaluation call.
  s=self.stack;u=self.u
  u.reg_write(UC_X86_REG_ESP,s);u.emu_start(0x4335ef18,0x4335ef37,count=20)
  assert u.reg_read(UC_X86_REG_EAX)==count
  for index in range(count):
   u.reg_write(UC_X86_REG_ESP,s);u.reg_write(UC_X86_REG_ECX,index);u.reg_write(UC_X86_REG_EDX,0);u.emu_start(0x4335ef62,0x4335ef87,count=20)
   assert u.reg_read(UC_X86_REG_EDI)==self.begin+index*24
   assert self.word(s+0x40)==self.word(self.begin+index*24+16)
   assert self.word(s+0x7c)==self.word(self.begin+index*24+20)
checks={'disabled':0,'numeric_budget':0,'native_point_dispatches':0,'guard_rejections':0}
for address in [0x50000000,0xf0000000]:
 for offset in [0,4,8,12]:
  for enabled,units in [(0,1),(0,112),(1,1),(1,4),(1,8),(1,9),(1,10),(1,64),(1,112)]:
   c=Case(address,offset);c.policy(enabled,units);count=c.run()
   if not enabled:assert count==4 and c.queries==0;checks['disabled']+=1
   else:
    assert count==max(4,units),(units,count)
    assert c.call_address(sym['hitscan_counts_probe'])==(4|(9<<8))
    c.native_reads(count);checks['native_point_dispatches']+=count;checks['numeric_budget']+=1
for bad in ['capacity','count','shape_count','shooter','job','selection','multipoints','box','nan','single_sample']:
 c=Case();c.policy(True,112);s=c.stack
 if bad=='capacity':c.put(s+0x1258,c.begin+111*24)
 if bad=='count':c.put(s+0x1254,c.begin+113*24)
 if bad=='shape_count':c.put(s+0x1ce0,20)
 if bad=='shooter':c.put(frame+8,0x12300000)
 if bad=='job':c.put(s+0x5c,0x12300000)
 if bad=='selection':c.put(job+0xc0,0)
 if bad=='multipoints':c.put(job+0xcc,0)
 if bad=='box':
  for i in [0,6]:c.floats(s+0x1cf0+i*0x90+0x70,-1)
 if bad=='nan':c.floats(c.begin,float('nan'));c.original=bytes(c.u.mem_read(c.begin,96))
 if bad=='single_sample':c.put(s+0x1254,c.begin+24)
 before=bytes(c.u.mem_read(c.begin,112*24));end=c.word(s+0x1254)
 # Invalid-count fixture intentionally bypasses Case.run's normal <=112 check.
 if bad=='count':
  c.call_address(sym['hitscan_enrich_probe'],[s,frame]);assert c.word(s+0x1254)==end
 else:c.run();assert c.word(s+0x1254)==end
 assert bytes(c.u.mem_read(c.begin,112*24))==before,bad;checks['guard_rejections']+=1
# Full native capacity: preserve all entries and publish the measured floor.
c=Case();c.policy(True,112)
for i in range(4,112):c.u.mem_write(c.begin+i*24,c.original[:24])
c.put(c.stack+0x1254,c.begin+112*24);saved=bytes(c.u.mem_read(c.begin,112*24))
assert c.run()==112 and bytes(c.u.mem_read(c.begin,112*24))==saved
assert c.call_address(sym['hitscan_counts_probe'])==(112|(112<<8))
report={'full_native_buffer_preserved':True,'passed':True,'checks':checks,'gpr_xmm_x87_mxcsr_preserved':True,'eflags_preserved_before_native_constructor':True,'stack_alignments':[0,4,8,12],'native_input_capacity':112,'native_output_capacity':112,'preserved_native_prefix':True,'original_point_dispatch_executed':True,'native_damage_and_hc_not_executed':True,'boundaries':['VirtualQuery','CRT memory calls','stop before live damage/HC evaluation'],'game_tested':False}
(r/'reports/hitscan_native.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

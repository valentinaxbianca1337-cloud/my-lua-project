#pragma once
#include <windows.h>

inline constexpr char kImprovedBuild[] = "Improved Hitscan 2 + NL Movement";
enum ImprovedStage : LONG {
    ImprovedWaiting=0, ImprovedHookInstalled=1, ImprovedMenuRejected=2,
    ImprovedMenuClosed=3, ImprovedCreating=4, ImprovedActive=5,
    ImprovedFailed=6
};
struct ImprovedStatus {
    DWORD version;
    volatile LONG stage;
    DWORD frames, menu, chain_head, tabs, custom_index;
    char build[64];
    char message[164];
};
static_assert(sizeof(ImprovedStatus)==256);

#pragma once
#include "hitscan_options.h"
namespace hitscan_controls {
using namespace SkeetSDK;
struct Widgets {PElement slider=nullptr,enabled=nullptr,warning=nullptr;};
inline void __fastcall display(void* context,void*){
 auto* slider=static_cast<Slider*>(context);if(!slider||!slider->Value)return;
 const auto value=*slider->Value;auto* out=reinterpret_cast<wchar_t*>(reinterpret_cast<unsigned char*>(slider)+0xa4);
 const unsigned counts=hitscan_options::reference_counts.load(std::memory_order_acquire),gs=counts&255,nl=(counts>>8)&255;
 unsigned i=0;const wchar_t* marker=nullptr;
 if(gs&&unsigned(value)==gs)marker=gs==nl?L"GS/NL":L"GS";
 else if(nl&&unsigned(value)==nl)marker=L"NL";
 if(marker){while(*marker)out[i++]=*marker++;out[i++]=L' ';out[i++]=L'(';}
 if(value>=1&&value<=112){if(value>=100)out[i++]=L'0'+value/100;if(value>=10)out[i++]=L'0'+(value/10)%10;out[i++]=L'0'+value%10;}
 if(marker)out[i++]=L')';out[i]=0;
}
inline bool create(const native_ui_proxy::Api& api,Child* child,Widgets& w){
 w.slider=record_controls::slider(api,child,L"Units",1,112,&hitscan_options::units,0);
 w.enabled=record_controls::checkbox(api,child,L"Hitscan",&hitscan_options::enabled);
 if(!w.slider||!w.enabled||!api.label)return false;
 auto* slider=w.slider->GetAs<Slider>();slider->Calls.emplace_back(slider,&display);display(slider,nullptr);
 auto* check=w.enabled->GetAs<Checkbox>();check->DefActivateSize.x=70;check->Header.Flags.SameLine=true;
 auto* p=api.allocate(sizeof(Label));if(!p)return false;std::memset(p,0,sizeof(Label));
 api.label(p,child,L"May reduce FPS");api.insert(child,false,p);w.warning=static_cast<PElement>(p);
 w.warning->GetAs<Checkbox>()->Header.Flags.Visible=false;return true;
}
inline void place(Widgets& w,Child* child){
 if(!w.enabled||!w.slider)return;
 auto* check=w.enabled->GetAs<Checkbox>();auto* slider=w.slider->GetAs<Slider>();
 const float scale=*reinterpret_cast<const float*>(0x4346d490);
 if(!std::isfinite(scale)||scale<.5f||scale>4.f)return;
 const int padding=child->Padding.x,min_width=std::max(1,int(40*scale+.5f));
 check->ActivateSize.x=std::max(1,int(check->DefActivateSize.x*scale+.5f));
 const int gap=std::max(12,int(12*scale+.5f)); // native slider hover extends 10px beyond the track
 const int check_left=child->Size.x-padding-check->ActivateSize.x;
 const int inline_width=check_left-gap-(padding+slider->LeftPaddign);
 const bool inline_row=inline_width>=min_width;
 check->Header.Flags.SameLine=inline_row;
 check->LeftPaddign=inline_row?check_left-padding:0;
 const int native_width=std::max(child->Size.x-int(100*scale+.5f),min_width);
 slider->MaxLen=std::min(int(200*scale+.5f),inline_row?inline_width:native_width);
 slider->Size.x=std::min(native_width,slider->MaxLen);
}
inline void frame(Widgets& w,Child* child){
 if(!w.slider||!w.enabled||!w.warning)return;
 w.enabled->GetAs<Checkbox>()->Header.Flags.Editable=hitscan_options::installed;
 auto* slider=w.slider->GetAs<Slider>();
 const unsigned gs=hitscan_options::reference_counts.load(std::memory_order_acquire)&255;
 // Keep native candidates. Never advertise a total budget smaller than the
 // measured native baseline. A subsequent larger baseline is retained too.
 const int floor=gs>=1&&gs<=112?int(gs):1;
 // Native slider rendering divides by Max-Min. A full native buffer has
 // no room for additions; retain a valid range and disable its interaction.
 slider->Min=floor<112?floor:1;
 slider->Header.Flags.Editable=hitscan_options::installed&&floor<112;
 hitscan_options::units=std::clamp(hitscan_options::units,floor,112);
 const bool shown=hitscan_options::installed&&hitscan_options::enabled;
 auto& visible=w.warning->GetAs<Checkbox>()->Header.Flags.Visible;
 if(visible!=shown){visible=shown;place(w,child);child->CalculateLayout();}
 display(slider,nullptr);hitscan_options::publish();
}
}

#pragma once
#include <atomic>
namespace hitscan_options {
// Numeric total candidate budget. Preset names are measured count markers,
// never sentinel values in the slider's numeric domain.
inline int enabled=0,units=64;
inline bool installed=false;
inline std::atomic<unsigned> policy{0},added{0},scans{0},reference_counts{0};
inline void publish(){const unsigned n=unsigned(units<1?1:(units>112?112:units));policy.store(installed&&enabled?(1u|(n<<1)):0u,std::memory_order_release);}
}

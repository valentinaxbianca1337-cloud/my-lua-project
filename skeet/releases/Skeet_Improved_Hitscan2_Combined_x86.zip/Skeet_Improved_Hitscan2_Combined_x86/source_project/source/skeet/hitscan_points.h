#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
namespace hitscan_points {
inline constexpr unsigned capacity=112;
struct Vec {float x,y,z;};
inline Vec add(Vec a,Vec b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Vec sub(Vec a,Vec b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Vec mul(Vec a,float s){return {a.x*s,a.y*s,a.z*s};}
inline float dot(Vec a,Vec b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline bool finite(Vec a){return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z);}
inline bool coordinate(Vec a){return finite(a)&&std::fabs(a.x)<=32768&&std::fabs(a.y)<=32768&&std::fabs(a.z)<=32768;}
struct Capsule {Vec a,b;float radius;unsigned index,group;};
struct Point {Vec position;std::uint32_t auxiliary,group,flags;};
static_assert(sizeof(Point)==24);
inline Vec center(const Capsule& s){return mul(add(s.a,s.b),.5f);}
inline bool valid(const Capsule& s){return coordinate(s.a)&&coordinate(s.b)&&std::isfinite(s.radius)&&s.radius>.01f&&s.radius<=64&&s.index<19&&s.group>=1&&s.group<=7&&dot(sub(s.a,s.b),sub(s.a,s.b))<=16384;}
inline double distance2(Vec p,const Capsule& s){
 const auto axis=sub(s.b,s.a),offset=sub(p,s.a);const double den=dot(axis,axis);
 const double t=den>1e-12?std::clamp(double(dot(offset,axis))/den,0.,1.):0.;
 const double x=offset.x-axis.x*t,y=offset.y-axis.y*t,z=offset.z-axis.z*t;return x*x+y*y+z*z;
}
inline bool inside(Vec p,const Capsule& s,float tolerance=1.0001f){return coordinate(p)&&distance2(p,s)<=double(s.radius)*s.radius*tolerance;}
// Adapter for the Source clipping boundary used by the reviewed NL pattern.
// Earliest segment entry into the union of finite cylinder and end spheres.
inline bool surface(Vec start,Vec end,const Capsule& s,Vec& out) {
 if(!valid(s)||!coordinate(start)||!coordinate(end)||!inside(end,s))return false;
 const Vec rd=sub(end,start),ba=sub(s.b,s.a),oa=sub(start,s.a);
 const auto dp=[](Vec a,Vec b){return double(a.x)*b.x+double(a.y)*b.y+double(a.z)*b.z;};
 const double d2=dp(rd,rd),baba=dp(ba,ba),bard=dp(ba,rd),baoa=dp(ba,oa),rdoa=dp(rd,oa),oaoa=dp(oa,oa),r2=double(s.radius)*s.radius;
 if(d2<1e-16)return false;
 if(inside(start,s)){out=start;return true;}
 double best=2.;
 const auto candidate=[&](double t){if(std::isfinite(t)&&t>=0&&t<=1&&t<best)best=t;};
 if(baba>1e-12){
  const double a=baba*d2-bard*bard,b=baba*rdoa-baoa*bard,c=baba*oaoa-baoa*baoa-r2*baba;
  const double h=b*b-a*c;
  if(a>1e-12&&h>=0){const double t=(-b-std::sqrt(h))/a,y=baoa+t*bard;if(y>=0&&y<=baba)candidate(t);}
 }
 for(Vec cap:{s.a,s.b}){
  const auto o=sub(start,cap);const double b=dp(rd,o),c=dp(o,o)-r2,h=b*b-d2*c;
  if(h>=0)candidate((-b-std::sqrt(h))/d2);
 }
 if(best>1)return false;
 out={float(start.x+rd.x*best),float(start.y+rd.y*best),float(start.z+rd.z*best)};return inside(out,s,1.001f);
}
inline bool basis(Vec c,Vec eye,Vec& side,Vec& up,Vec& toward) {
 constexpr float epsilon=1.1920928955078125e-7f;
 const auto delta=sub(c,eye);const float length=std::sqrt(dot(delta,delta));
 if(!finite(delta)||!std::isfinite(length)||length<.001f)return false;
 const auto v=mul(delta,1.f/(length+epsilon));toward=mul(v,-1.f);
 if(v.x==0&&v.y==0){side={0,-1,0};up={-v.z,0,0};return true;}
 const float xy=v.x*v.x+v.y*v.y;side=mul(Vec{v.y,-v.x,0},1.f/(std::sqrt(xy)+epsilon));
 const Vec raw{-v.x*v.z,-v.y*v.z,xy};up=mul(raw,1.f/(std::sqrt(dot(raw,raw))+epsilon));
 return finite(side)&&finite(up)&&finite(toward);
}
// Generic capsule distribution from NL41490FA0: two side intersections and
// an additional upper intersection for hitbox6. Scale and clipping are adapters,
// not a reconstruction of NL's complete weapon/spread auto-scale or ragebot.
inline unsigned nl_pattern(const Capsule& s,Vec eye,float scale,Vec* out) {
 if(!out||!valid(s)||!std::isfinite(scale)||scale<=0||scale>1)return 0;
 if(s.index==1||s.index==2||s.index==13||s.index==14)return 0;
 const auto c=center(s);Vec side,up,toward;if(!basis(c,eye,side,up,toward))return 0;
 const float reach=std::sqrt(dot(sub(s.b,s.a),sub(s.b,s.a)))+s.radius*2.009999990463257f;
 const Vec directions[]={side,mul(side,-1),up};const unsigned count=s.index==6?3:2;
 unsigned made=0;
 for(unsigned i=0;i<count;i++){
  Vec hit;if(!surface(add(c,mul(directions[i],reach)),c,s,hit))continue;
  const auto p=add(c,mul(sub(hit,c),scale));if(inside(p,s))out[made++]=p;
 }
 return made;
}
inline bool dense_point(const Capsule& s,Vec eye,float scale,unsigned sequence,Vec& out) {
 Vec side,up,toward;const auto c=center(s);if(!basis(c,eye,side,up,toward)||scale<=0||scale>1)return false;
 // A deterministic, progressively refined camera-facing hemisphere.
 const float z=float((sequence*73u+37u)%257u)/257.f;
 const float angle=float(sequence)*2.39996322972865332f;
 const float radial=std::sqrt(std::max(0.f,1-z*z));
 const auto direction=add(add(mul(side,std::cos(angle)*radial),mul(up,std::sin(angle)*radial)),mul(toward,z));
 const float reach=std::sqrt(dot(sub(s.b,s.a),sub(s.b,s.a)))+s.radius*2.01f;
 Vec hit;if(!surface(add(c,mul(direction,reach)),c,s,hit))return false;
 out=add(c,mul(sub(hit,c),scale));return inside(out,s);
}
inline bool duplicate(const Point* points,unsigned count,Vec p,unsigned group) {
 for(unsigned i=0;i<count;i++)if(points[i].group==group&&dot(sub(points[i].position,p),sub(points[i].position,p))<.0001f)return true;
 return false;
}
struct Selected {Capsule capsule;Point model;float scale;};
// Original candidates are retained verbatim. Only native-selected/multipointed
// capsules with a usable existing surface sample are eligible for additions.
inline unsigned enrich(Point* points,unsigned count,unsigned limit,const Capsule* shapes,unsigned shape_count,Vec eye,unsigned selection,unsigned multipoints,unsigned setting,unsigned* nl_reference=nullptr) {
 if(nl_reference)*nl_reference=0;
 if(!points||!shapes||count>capacity||limit>capacity||count>limit||shape_count>19||!coordinate(eye)||setting<1||setting>112)return count;
 for(unsigned i=0;i<count;i++)if(!coordinate(points[i].position)||points[i].group<1||points[i].group>7)return count;
 if(nl_reference)*nl_reference=count;
 Selected selected[19]{};unsigned eligible=0;const unsigned original=count;
 for(unsigned k=0;k<shape_count;k++){
  const auto& s=shapes[k];if(!valid(s))continue;
  const unsigned mask=(s.index==11||s.index==12)?0x200u:1u<<s.group;
  if(!(selection&mask)||!(multipoints&mask))continue;
  int model=-1;double nearest=1e30;float ratio=0;unsigned matches=0;
  for(unsigned i=0;i<original;i++)if(points[i].group==s.group&&inside(points[i].position,s,1.001f)){
   ++matches;const auto d=sub(points[i].position,center(s));const double dist=dot(d,d);
   if(dist<nearest){nearest=dist;model=int(i);}
   ratio=std::max(ratio,float(std::sqrt(distance2(points[i].position,s))/s.radius));
  }
  if(model<0||matches<2||nearest>double(s.radius)*s.radius||ratio<.01f)continue;
  selected[eligible++]={s,points[model],std::min(.95f,ratio)};
 }
 if(!eligible)return count;
 const auto append=[&](const Selected& s,Vec p){if(count<limit&&!duplicate(points,count,p,s.capsule.group)){points[count]=s.model;points[count++].position=p;}};
 // Measure the complete adapted NL union even when the requested budget is
 // smaller. The temporary entries beyond the returned count are never copied.
 for(unsigned i=0;i<eligible&&count<limit;i++){Vec p[3];const unsigned n=nl_pattern(selected[i].capsule,eye,selected[i].scale,p);for(unsigned j=0;j<n;j++)append(selected[i],p[j]);}
 if(nl_reference)*nl_reference=count;
 const unsigned target=std::max(original,std::min(limit,setting));
 count=std::min(count,target);
 if(count<target){
  for(unsigned round=0;round<224&&count<target;round++)for(unsigned i=0;i<eligible&&count<target;i++){
   Vec p;if(dense_point(selected[i].capsule,eye,selected[i].scale,round,p))append(selected[i],p);
  }
 }
 return count;
}
}

from pathlib import Path
import base64, hashlib, json, re, struct, zlib
from lupa.luajit21 import LuaRuntime

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'nyameeow.pink.lua'
lua=LuaRuntime(encoding=None,unpack_returned_tuples=True)
lua.globals()[b'py_b64encode']=lambda x:base64.b64encode(x)
lua.globals()[b'py_b64decode']=lambda x:base64.b64decode(x,validate=True)
lua.execute(b'''
package.preload['gamesense/base64']=function() return {encode=py_b64encode,decode=py_b64decode} end
RESULTS={}
function check(name, condition) assert(condition,name);RESULTS[#RESULTS+1]=name end
function clone(v) if type(v)~='table' then return v end local t={} for k,x in pairs(v)do t[k]=clone(x)end return t end
controls={};local next_id=0
function make(kind,name,value,opts,lo,hi)
 next_id=next_id+1;controls[next_id]={kind=kind,name=name,value=clone(value),options=opts,min=lo,max=hi};return next_id
end
ui={}
function ui.new_checkbox(t,c,n)return make('checkbox',n,false)end
function ui.new_combobox(t,c,n,...)local a={...};return make('combo',n,a[1],a)end
function ui.new_slider(t,c,n,lo,hi,value)return make('slider',n,value,nil,lo,hi)end
function ui.new_label(t,c,n)return make('label',n,n)end
function ui.new_button(t,c,n,cb)local id=make('button',n,false);controls[id].callback=cb;return id end
function ui.new_multiselect(t,c,n,...)return make('multi',n,{},{...})end
function ui.new_hotkey(t,c,n,inline,key)local id=make('hotkey',n,false);controls[id].mode=1;controls[id].key=key or 0;return id end
function ui.new_string(n,v)return make('string',n,v)end
function ui.get(id)
 if FAIL_GET==id and (FAIL_GET_COUNT or 0)>0 then FAIL_GET_COUNT=FAIL_GET_COUNT-1;error('injected get failure')end
 local c=assert(controls[id],'unknown ref '..tostring(id))
 if c.kind=='hotkey'then return c.value,c.mode,c.key end return clone(c.value)
end
function ui.set(id,value,key,...)
 local c=assert(controls[id],'unknown ref')
 if FAIL_SET==id and (FAIL_SET_COUNT or 0)>0 then FAIL_SET_COUNT=FAIL_SET_COUNT-1;error('injected set failure')end
 if c.kind=='checkbox'then assert(type(value)=='boolean','checkbox expects boolean')
 elseif c.kind=='slider'then assert(type(value)=='number'and value==value and value>=c.min and value<=c.max,'slider range/type')
 elseif c.kind=='combo'then local found=false for _,x in ipairs(c.options)do if x==value then found=true end end assert(found,'unknown combo '..tostring(value))
 elseif c.kind=='multi'then
  if type(value)~='table'then value={value,key,...}end
 elseif c.kind=='hotkey'then
  local modes={['Always on']=0,['On hotkey']=1,['Toggle']=2,['Off hotkey']=3};assert(modes[value]~=nil,'hotkey expects mode string')
  c.mode=modes[value];if key~=nil then c.key=key end;return
 end
 local changed=c.value~=value;c.value=clone(value)
 if changed and c.callback and c.kind~='button'then c.callback(id)end
end
function ui.set_callback(id,fn)controls[id].callback=fn end
function ui.set_visible(id,value)end
function ui.set_enabled(id,value)end
function ui.is_menu_open()return false end
function ui.type(id)return controls[id].kind end
function ui.update(id,values)controls[id].options=values end
NOW=0;events={};logs={}
globals={realtime=function()return NOW end,curtime=function()return NOW end,tickcount=function()return math.floor(NOW*64)end,tickinterval=function()return 1/64 end}
client={error_log=function(x)logs[#logs+1]=x end,log=function(x)logs[#logs+1]=x end,
 set_event_callback=function(n,f)events[n]=f end,unset_event_callback=function(n)events[n]=nil end}
modules={symbols={format=function(s)return s end}}
TAB=setmetatable({},{__index=function()return function()end end})
''')
source=SOURCE.read_bytes()
lua.execute(b'assert(loadstring(...))',source)
lua.globals()[b'SOURCES']=lua.execute(source[:source.index(b'\nlocal modules = {}')]+b'\nreturn sources')
lua.execute(b'''
builder=SOURCES.builder_menu(modules);builder:init(TAB,{});builder:init_sections(TAB,{})
modules.builder=builder
cfg=SOURCES.config(modules)
cfg.menu={builder=builder,refs={},visuals={},misc_rage={refs={}}}
cfg.report=function(self,ok,msg)logs[#logs+1]=msg end
local function snapshot()return builder:snapshot()end
ui.set(builder.refs.pitch,'Custom');ui.set(builder.refs.pitch_value,37)
builder:apply({pitch='Down'})
check('partial state does not inherit previous custom pitch',ui.get(builder.refs.pitch_value)==0)
local payload={states={['Terrorist:Standing']={override=true,yaw_single=27,desync='Jitter',desync_value=60}},
 selection={team='Terrorist',condition='Standing'},current_key='Counter-Terrorist:Air'}
check('builder payload applied',cfg:apply_builder_blob(payload)==true)
check('selection and current profile remain consistent',builder.current_key=='Terrorist:Standing')
check('legacy sixty-degree setting migrated',builder.states['Terrorist:Standing'].desync_value==58)
check('unmentioned states retain independent defaults',builder.states['Counter-Terrorist:Air'].yaw_single==0)
local old_key=builder.current_key
local ok=pcall(cfg.apply_builder_blob,cfg,{states={['BAD:Standing']={}},selection={team='Terrorist',condition='Standing'}})
check('unknown team rejected before mutation',not ok and builder.current_key==old_key and not builder.changing)
ok=pcall(cfg.apply_builder_blob,cfg,{states={['Terrorist:Standing']={yaw_single=0/0}}})
check('NaN in imported angle rejected',not ok and not builder.changing)
local prior=ui.get(builder.refs.yaw_single);FAIL_SET=builder.refs.yaw_single;FAIL_SET_COUNT=1
ok=pcall(cfg.apply_builder_blob,cfg,{states={['Terrorist:Standing']={yaw_single=80}},selection={team='Terrorist',condition='Standing'}})
check('failed builder load rolls back UI',not ok and ui.get(builder.refs.yaw_single)==prior)
check('failed builder load releases all locks',not builder.changing and not builder.defensive_changing and not cfg.menu.updating_aa)
FAIL_SET=nil

-- Actual binary codec: roundtrip file plus detection of corrupt/truncated data.
local preset={name='Test',mask=2,data={format='pui-v1',pui={aa={enabled=true,values={1,2,'three'}}}}}
local encoded=cfg.encode_file({preset});local decoded=cfg.decode_file(encoded)
check('preset binary roundtrip',decoded[1].name=='Test'and decoded[1].data.pui.aa.values[3]=='three')
check('truncated preset rejected',not pcall(cfg.decode_file,encoded:sub(1,#encoded-2)))
local bad=encoded:sub(1,#encoded-1)..string.char((encoded:byte(#encoded)+1)%256)
check('corrupt preset rejected',not pcall(cfg.decode_file,bad))
local disk={['afterglow/afterglow_presets.dat']='legacy untouched'}
function readfile(path)return disk[path]end
function writefile(path,data)
 if path==FAIL_PATH then FAIL_PATH=nil;error('injected disk write failure')end
 disk[path]=data
end
cfg.presets={preset};cfg:persist()
check('new presets use renamed storage path',type(disk['nyameeow.pink_presets.dat'])=='string')
check('preset persistence preserves legacy file',disk['afterglow/afterglow_presets.dat']=='legacy untouched')
local previous=disk['nyameeow.pink_presets.dat'];FAIL_PATH='nyameeow.pink_presets.dat'
check('failed disk write reports error',not pcall(cfg.persist,cfg))
check('failed disk write preserves previous data',disk['nyameeow.pink_presets.dat']==previous)

-- Snapshot package rejection after a partial change must release every guard.
local live={rage={v=1},aa={v=2},visuals={},misc={}}
local load_calls=0
cfg.package={save=function()return clone(live)end,load=function(self,v)
 load_calls=load_calls+1;live=clone(v);if load_calls==1 then error('package failed after a partial change')end
end}
cfg.restore_internal_state=function()error('internal restore failure')end
ok=pcall(cfg.load_pui_snapshot,cfg,{aa={v=99}},2)
check('PUI rejection restores previous snapshot',not ok and live.aa.v==2 and load_calls==2)
check('PUI rejection releases builder and menu locks',not builder.changing and not builder.defensive_changing and not cfg.menu.updating_aa)
cfg.package.load=function(self,v)live=clone(v)end
ok=pcall(cfg.load_pui_snapshot,cfg,{aa={v=100}},2)
check('internal-restore exception rolls back snapshot',not ok and live.aa.v==2)
check('internal-restore exception releases guards',not builder.changing and not builder.defensive_changing)

-- Both encoded persistent blobs are restored if the second write fails.
local pre_save=cfg.before_config_save
cfg.cfg_snapshot_ref=ui.new_string('test_cfg','old cfg')
cfg.builder_snapshot_ref=ui.new_string('test_builder','old builder')
cfg.flush_builder_active=function()end
cfg.save_pui_snapshot=function()return {aa={x=1}}end
cfg.encode_builder_blob=function()return 'new builder'end
FAIL_SET=cfg.builder_snapshot_ref;FAIL_SET_COUNT=1
check('paired persistent writes report failure',pre_save(cfg)==false)
check('paired persistent writes rollback both values',ui.get(cfg.cfg_snapshot_ref)=='old cfg'and ui.get(cfg.builder_snapshot_ref)=='old builder')
FAIL_SET=nil

-- Native CFG loading cannot leave a nested/stale guard behind on exceptions.
cfg.cfg_snapshot_ref=nil;cfg.builder_snapshot_ref=nil
cfg.restore_internal_state=function()error('broken internal snapshot')end
cfg:before_config_load();cfg:before_config_load()
check('native CFG hook reports failure without throwing',cfg:after_config_load()==false)
check('native CFG hook always releases its guard',cfg.config_load_guard==nil and not builder.changing and not builder.defensive_changing and not cfg.menu.updating_aa)
cfg._boot_cfg_snapshot=nil
check('startup load error is recoverable',cfg:bootstrap_from_persistent()==false and not builder.changing and not cfg.menu.updating_aa)

-- Restore order after a transient native reference failure.
rt=SOURCES.builder_runtime(modules)
local function native_combo(name,...)return ui.new_combobox('AA','Anti-aimbot angles',name,...)end
rt.references={enabled={make('checkbox','Enabled',true)},pitch={native_combo('Pitch','Off','Down','Up','Custom','Random'),make('slider','Custom pitch',0,nil,-89,89)},
 yaw_base={native_combo('Yaw base','Local view','At targets')},yaw={native_combo('Yaw','Off','180'),make('slider','Yaw offset',0,nil,-180,180)},
 yaw_jitter={native_combo('Jitter','Off','Offset','Center','Random','Skitter'),make('slider','Jitter offset',0,nil,-180,180)},
 body_yaw={native_combo('Body','Off','Static','Jitter','Opposite'),make('slider','Body offset',0,nil,-180,180)}}
rt.aa_ready=true;rt.modifier_ready=true;rt.body_ready=true
rt:apply_basic({pitch='Down',yaw_single=23},{command_number=1,chokedcommands=0})
FAIL_GET=rt.references.yaw[2];FAIL_GET_COUNT=1;rt:release()
check('partial restore failure retained for retry',#rt.owned==1)
FAIL_GET=nil
rt:apply_basic({pitch='Custom',pitch_value=18,yaw_single=35},{command_number=2,chokedcommands=0})
check('partial restore cannot swap pitch and yaw controls',ui.get(rt.references.pitch[1])=='Custom'and ui.get(rt.references.pitch[2])==18 and ui.get(rt.references.yaw[2])==35)
local hot=ui.new_hotkey('AA','Anti-aimbot angles','FS',true,18)
rt:write_native('fs_test',hot,'Always on',2)
check('native freestanding hotkey uses mode API',controls[hot].mode==0 and controls[hot].key==18)
check('native hotkey mode/key restore succeeds',rt:restore_native('fs_test')and controls[hot].mode==1 and controls[hot].key==18)
rt:write_native('fs_test',hot,'Always on',2);controls[hot].key=33
check('hotkey restore preserves a user key edit',rt:restore_native('fs_test')and controls[hot].mode==1 and controls[hot].key==33)
rt:apply_basic({pitch='Custom',pitch_value=500,yaw_single=1000},{command_number=3,chokedcommands=0})
check('pitch clamped to native safe API range',ui.get(rt.references.pitch[2])==89)
check('yaw normalized to native API range',ui.get(rt.references.yaw[2])>=-180 and ui.get(rt.references.yaw[2])<=180)
rt:apply_body({desync='Jitter',desync_value=999},{command_number=4,chokedcommands=0})
check('body jitter bounded to requested range',ui.get(rt.references.body_yaw[2])==58)
FAIL_GET=rt.references.body_yaw[2];FAIL_GET_COUNT=1;rt:release();FAIL_GET=nil
rt:apply_body({desync='Jitter',desync_value=-17},{command_number=5,chokedcommands=0})
check('partial body restore cannot swap mode and amount',ui.get(rt.references.body_yaw[1])=='Jitter'and ui.get(rt.references.body_yaw[2])==-17)
rt:apply_modifier({modifier='Center',modifier_value=23},{command_number=6,chokedcommands=0})
FAIL_GET=rt.references.yaw_jitter[2];FAIL_GET_COUNT=1;rt:release();FAIL_GET=nil
rt:apply_modifier({modifier='Off'},{command_number=7,chokedcommands=0})
check('partial modifier restore cannot swap mode and offset',controls[rt.references.yaw_jitter[1]].kind=='combo'and controls[rt.references.yaw_jitter[2]].kind=='slider')

-- Production core event wrapper must resume after the first builder exception.
local noop=setmetatable({},{__index=function()return function()end end})
local calls=0
local fake_menu={builder={changing=false},config={},init=function()end,
 builder_runtime=setmetatable({setup_command=function()calls=calls+1;if calls==1 then error('one transient frame')end end},getmetatable(noop)),
 anti_bruteforce=noop,misc_runtime=noop,rage_runtime=noop,rage_fixes=noop,visuals_runtime=noop}
local core=SOURCES.core({menu=fake_menu,statistics=noop,enemy_misses=noop})
check('core starts in callback fixture',core:start()==true)
NOW=0;events.setup_command({});NOW=.1;events.setup_command({});NOW=.26;events.setup_command({});NOW=.27;events.setup_command({})
check('builder resumes automatically after transient failure',calls==3)
fake_menu.config.config_load_guard={};NOW=.3;events.setup_command({})
check('builder pauses during native config transaction',calls==3)
fake_menu.config.config_load_guard=nil;NOW=.31;events.setup_command({})
check('builder resumes after config transaction',calls==4)

-- All accepted clipboard signatures remain readable after the rename.
local imported
cfg.menu.refs.config_mode=make('combo','Config mode','Local',{'Local'})
cfg.entries={};cfg.presets={}
cfg.commit=function(self,presets,entries,name)imported=name end
local clipboard_text
package.preload['gamesense/clipboard']=function()return {get=function()return clipboard_text end}end
for _,prefix in ipairs({'afterglow_','AGP1:','nyameeow.pink_'})do
 imported=nil;clipboard_text=prefix..require('gamesense/base64').encode(cfg.encode_preset(preset))
 check('clipboard compatibility '..prefix,cfg:import_preset()==true and imported=='Test')
end
''')
names=[v.decode()for _,v in lua.globals()[b'RESULTS'].items()]
# Independent PNG validation and byte identity of the new Base64 assets.
reference=ROOT/'reference/afterglow.original.txt'
if not reference.exists():reference=Path('/workspace/attachments/8232aa2b-c950-4e8f-9ade-69c16c5b33fb/afterglow.lua')
original=reference.read_bytes()
old_assets=[bytes(int(n)for n in re.findall(rb'\\([0-9]{3})',m[0]))for m in re.finditer(rb'"(?:\\[0-9]{3}){32,}"',original)]
new_assets=[base64.b64decode(m[1],validate=True)for m in re.finditer(rb"nyameeow_decode64\('([A-Za-z0-9+/=]+)'\)",source)]
assert len(new_assets)==len(old_assets)+1
assert new_assets[1:]==old_assets
for raw in new_assets:
    assert raw.startswith(b'\x89PNG\r\n\x1a\n')
    offset=8
    while offset<len(raw):
        n=struct.unpack_from('>I',raw,offset)[0];kind=raw[offset+4:offset+8];data=raw[offset+8:offset+8+n]
        crc=struct.unpack_from('>I',raw,offset+8+n)[0];assert zlib.crc32(kind+data)&0xffffffff==crc
        offset+=12+n
    assert offset==len(raw)
report={'passed':True,'lua_engine':'LuaJIT 2.1','full_file_compiles':True,'behavior_checks':len(names),'checks':names,
        'lossless_png_assets':len(new_assets),'source_bytes':len(source),'original_source_bytes':len(original),
        'game_executed':False,'native_ffi_ui_executed':False,'new_icon_embedded':False,
        'limits':['Injected UI/native errors are controlled fixtures, not a full CS:GO session.',
                  'The new portrait needs its original PNG/WebP file; the previous tab PNG is retained.']}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

"""Reproduce source-level failures in the supplied, unchanged original file."""
from pathlib import Path
import ast,base64,json
from lupa.luajit21 import LuaRuntime

root=Path(__file__).resolve().parents[1]
reference=root/'reference/afterglow.original.txt'
if not reference.exists():reference=Path('/workspace/attachments/8232aa2b-c950-4e8f-9ade-69c16c5b33fb/afterglow.lua')
tree=ast.parse((root/'tests/test_runtime_and_config.py').read_text())
setup=next(n.value.args[0].value for n in tree.body if isinstance(n,ast.Expr)and isinstance(n.value,ast.Call)
           and isinstance(n.value.func,ast.Attribute)and n.value.func.attr=='execute')
l=LuaRuntime(encoding=None,unpack_returned_tuples=True)
l.globals()[b'py_b64encode']=base64.b64encode;l.globals()[b'py_b64decode']=base64.b64decode
l.execute(setup)
source=reference.read_bytes()
l.globals()[b'SOURCES']=l.execute(source[:source.index(b'\nlocal modules = {}')]+b'\nreturn sources')
l.execute(b'''
builder=SOURCES.builder_menu(modules);builder:init(TAB,{});builder:init_sections(TAB,{})
ui.set(builder.refs.pitch,'Custom');ui.set(builder.refs.pitch_value,37);builder:apply({pitch='Down'})
check('original partial state retains previous pitch amount',ui.get(builder.refs.pitch_value)==37)
cfg=SOURCES.config(modules);cfg.menu={builder=builder,refs={},visuals={},misc_rage={refs={}}}
cfg.package={save=function()return {aa={}}end,load=function()return true end}
cfg.restore_internal_state=function()error('injected internal load failure')end
local ok=pcall(cfg.load_pui_snapshot,cfg,{aa={}},2)
check('original failed PUI load leaves builder locked',not ok and builder.changing==true and builder.defensive_changing==true)
local rt=SOURCES.builder_runtime(modules)
local hot=ui.new_hotkey('AA','Anti-aimbot angles','FS',true,18)
rt:write_native('freestanding_hotkey',hot,true)
check('original boolean hotkey write silently fails',controls[hot].mode==1)
local noop=setmetatable({},{__index=function()return function()end end})
local calls=0
local menu={builder={changing=false},config={},init=function()end,
 builder_runtime=setmetatable({setup_command=function()calls=calls+1;error('one transient frame')end},getmetatable(noop)),
 anti_bruteforce=noop,misc_runtime=noop,rage_runtime=noop,rage_fixes=noop,visuals_runtime=noop}
local core=SOURCES.core({menu=menu,statistics=noop,enemy_misses=noop});assert(core:start())
NOW=0;events.setup_command({});NOW=1;events.setup_command({});NOW=10;events.setup_command({})
check('original core disables builder permanently after one error',calls==1)
''')
checks=[v.decode()for _,v in l.globals()[b'RESULTS'].items()]
report={'passed':True,'original_failures_reproduced':len(checks),'checks':checks,'game_executed':False}
(root/'original_bug_reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

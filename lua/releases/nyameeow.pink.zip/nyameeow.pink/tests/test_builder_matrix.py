"""Builder output/state-machine checks. Native UI is modeled, not CS:GO animation."""
from pathlib import Path
import contextlib,io,json,runpy

root=Path(__file__).resolve().parents[1]
with contextlib.redirect_stdout(io.StringIO()):
    context=runpy.run_path(str(root/'tests/test_runtime_and_config.py'))
lua=context['lua']
lua.execute(b'''
local previous_checks=#RESULTS
local refs=rt.references
local matrix=0
math.randomseed(2701)
for _,mode in ipairs({'Off','Opposite','Static','Jitter','L/R Desync','Randomize Jitter'})do
 for _,two in ipairs({false,true})do for _,delay in ipairs({false,true})do
  for _,invert in ipairs({false,true})do for _,left in ipairs({false,true})do
   for _,v in ipairs({-999,-58,-17,0,17,58,999})do for _,chance in ipairs({0,50,100})do
    for _,direction in ipairs({'+','-'})do
     local settings={desync=mode,second_yaw=two,delay_enable=delay,desync_value=v,
      desync_left=17,desync_right=42,desync_random=100,desync_direction=direction,desync_invert_chance=chance}
     rt.body_state=nil;rt.lr={left=left};rt.inverter_active=invert;rt.current={settings=settings}
     local cmd={command_number=1000+matrix,chokedcommands=0}
     rt:apply_body(settings,cmd)
     local body_mode,value=ui.get(refs.body_yaw[1]),ui.get(refs.body_yaw[2])
     assert(value==value and value>=-58 and value<=58,'body range')
     assert(body_mode=='Off'or body_mode=='Opposite'or body_mode=='Static'or body_mode=='Jitter','native body mode')
     local side=rt:requested_body_left(settings)
     if side~=nil and body_mode=='Static'and value~=0 then assert(side==(value<0),'requested side disagrees with actual written offset')end
     rt:apply_body(settings,cmd)
     assert(ui.get(refs.body_yaw[2])==value,'replaying a command changes random body amount')
     assert(settings.desync==mode and settings.desync_value==v,'runtime mutated profile')
     matrix=matrix+1
    end
   end end
  end end
 end end
end
check('body matrix uses valid bounded native values',matrix>0)
check('body matrix is idempotent for repeated commands',true)
check('requested side agrees with controlled body offset',true)
BODY_MATRIX_CASES=matrix

local function settings(mode)
 return {desync=mode,desync_direction='+',second_yaw=true,delay_enable=true,delay_mode='Sequential',
 delay_count=2,delay_1=2,delay_2=3,delay_features={},yaw_left=-12,yaw_right=33}
end
local function command(n,choke)return {command_number=n,chokedcommands=choke or 0}end
local s=settings('Static')
rt.lr=nil;rt.body_state=nil;rt.inverter_active=false;rt.current={settings=s}
rt:update_lr(s,command(1),'Terrorist','Standing');local first=rt.lr.left
rt:update_lr(s,command(1),'Terrorist','Standing')
check('initial command replay does not consume delay',rt.lr.left==first and rt.lr.counter==0)
rt:update_lr(s,command(2),'Terrorist','Standing');check('static delay holds first interval',rt.lr.left==first)
rt:update_lr(s,command(3),'Terrorist','Standing');check('static delay advances L/R yaw',rt.lr.left~=first)
local phase=rt.lr.left
rt:apply_basic(s,command(3));rt:apply_body(s,command(3))
check('static body remains fixed while yaw delay advances',ui.get(refs.body_yaw[2])==58 and ui.get(refs.yaw[2])==(phase and -12 or 33))
local value=ui.get(refs.body_yaw[2]);rt:update_lr(s,command(4),'Terrorist','Standing');rt:apply_body(s,command(4))
check('static body magnitude is not a yaw phase',ui.get(refs.body_yaw[2])==value)

s=settings('L/R Desync');s.delay_count=1;s.delay_1=2
rt.lr=nil;rt:update_lr(s,command(100),'Terrorist','Standing')
rt:update_lr(s,command(101),'Terrorist','Standing')
rt.lr.freeze_until=999999;rt.lr.disable_until=999999
rt:update_lr(s,command(102),'Counter-Terrorist','Air')
check('team/state change does not inherit delay or freeze timers',rt.lr.counter==0 and rt.lr.freeze_until==0 and rt.lr.disable_until==0)
local count,side=rt.lr.counter,rt.lr.left
rt:update_lr(s,command(103,10),'Counter-Terrorist','Air')
check('choked command does not advance send-based delay',rt.lr.counter==count and rt.lr.left==side)

for _,mode in ipairs({'Sequential','Smart Random','Random'})do
 s=settings('L/R Desync');s.delay_mode=mode;s.delay_features={};rt.lr=nil
 local previous
 for n=1,80 do
  rt:update_lr(s,command(200+n),'Terrorist','Standing')
  assert(rt.lr.next==2 or rt.lr.next==3,'delay not from configured list')
  if mode=='Smart Random'and rt.lr.next~=previous then previous=rt.lr.next end
  local before,counter=rt.lr.left,rt.lr.counter
  rt:update_lr(s,command(200+n),'Terrorist','Standing')
  assert(rt.lr.left==before and rt.lr.counter==counter,'duplicate sent command advances delay')
 end
 check('delay mode stays in configured list and rejects replay '..mode,true)
end

s=settings('Jitter');s.delay_count=1;s.delay_1=1;s.delay_features={'Freeze Inverter'}
s.freeze_chance=100;s.freeze_time=3;s.freeze_cooldown=1;rt.lr=nil
NOW=0;rt:update_lr(s,command(400),'Terrorist','Standing')
NOW=1/64;rt:update_lr(s,command(401),'Terrorist','Standing');local frozen=rt.lr.left
NOW=2/64;rt:update_lr(s,command(402),'Terrorist','Standing')
check('Freeze Inverter holds the configured side',rt.lr.left==frozen)
NOW=4/64;rt:update_lr(s,command(404),'Terrorist','Standing')
check('Freeze Inverter expires and permits the next transition',rt.lr.left~=frozen)
s=settings('Jitter');s.delay_count=1;s.delay_1=2;s.delay_features={'Disabling'}
s.disable_chance=100;s.disable_time=3;rt.lr=nil
NOW=0;rt:update_lr(s,command(410),'Terrorist','Standing')
NOW=1/64;rt:update_lr(s,command(411),'Terrorist','Standing')
NOW=2/64;rt:update_lr(s,command(412),'Terrorist','Standing');local before=rt.lr.left
NOW=3/64;rt:update_lr(s,command(413),'Terrorist','Standing')
check('Disabling temporarily bypasses delay without disabling AA',rt.lr.left~=before and ui.get(refs.enabled[1])==true)

-- Defensive Desync switching follows the controlled signed body request.
local defensive={defensive_pitch='Keep',defensive_yaw='Custom',defensive_yaw_value=10,
 defensive_yaw_second=70,defensive_yaw_add_second=true,defensive_yaw_switch='Desync'}
rt.current={settings={desync='Jitter',second_yaw=true,delay_enable=true,desync_value=-58,desync_invert_chance=100}}
rt.lr={left=true};rt.inverter_active=false;rt.defensive_anim={phase=0,sample_time=0}
rt:apply_body(rt.current.settings,command(501))
local _,yaw=rt:defensive_angles(defensive,command(501))
check('negative jitter keeps defensive Desync switch on matching side',ui.get(refs.body_yaw[2])==58 and yaw==70)
rt.current.settings={desync='Static',desync_direction='+'};rt.lr.left=true
_,yaw=rt:defensive_angles(defensive,command(502))
check('static defensive Desync switch ignores independent yaw phase',yaw==70)
rt.inverter_active=true;_,yaw=rt:defensive_angles(defensive,command(503))
check('inverter is applied once to static defensive side',yaw==10)
rt:apply_basic({pitch='Custom',pitch_value=0/0,yaw_single=math.huge,yaw_value=0/0},command(504))
check('nonfinite raw legacy angles cannot reach native setters',ui.get(refs.pitch[2])==0 and ui.get(refs.yaw[2])==0)

-- Exercise the actual top-level builder route for both teams and every profile.
local scene={}
entity={get_local_player=function()return 1 end,is_alive=function()return true end,
 get_prop=function(id,name)
  if name=='m_iTeamNum'then return scene.team end
  if name=='m_fFlags'then return scene.flags end
  if name=='m_vecVelocity'then return scene.speed or 0,0,0 end
  if name=='m_flDuckAmount'then return scene.duck or 0 end
  if name=='m_flPoseParameter'then return .25 end
 end}
local states={'Shared','Standing','Running','Slowing','Air','Air Crouching','Crouching','Sneaking','Freestanding','Manual','Legit AA'}
local scenes={Shared={1,0,0},Standing={1,0,0},Running={1,100,0},Slowing={1,100,0},Air={0,0,0},
 ['Air Crouching']={0,0,1},Crouching={1,0,1},Sneaking={1,100,1},Freestanding={1,0,0},Manual={1,0,0},['Legit AA']={1,0,0}}
builder.defensive_states={}
local routes=0
for _,team in ipairs({'Terrorist','Counter-Terrorist'})do
 for i,condition in ipairs(states)do
  local p=clone(builder.defaults);p.override=true;p.desync='Jitter';p.desync_value=i-6;p.yaw_single=i
  builder.states[team..':'..condition]=p
 end
end
for ti,team in ipairs({'Terrorist','Counter-Terrorist'})do
 for i,condition in ipairs(states)do
  local r=SOURCES.builder_runtime(modules);r.references=refs;r.aa_ready=true;r.body_ready=true;r.modifier_ready=true
  r.builder=builder;r.menu_refs={};r.bind_states={};r.native_owned={}
  r.update_hotkeys=function(self)
   self.freestanding_applied=condition=='Freestanding';self.manual_applied=condition=='Manual'
   self.manual_yaw=self.manual_applied and 90 or 0;self.manual_direction=self.manual_applied and 1 or 0
   self.inverter_active=false;self.edge_yaw_active=false
  end
  r.legit_aa_state=function()return condition=='Legit AA'end
  local a=scenes[condition];scene={team=ti+1,flags=a[1],speed=a[2],duck=a[3]}
  if condition=='Slowing'then r.references=clone(refs);r.references.slow={make('checkbox','slow',true)}end
  if condition=='Shared'then builder.states[team..':Standing'].override=false end
  NOW=1000+routes
  r:setup_command(command(1000+routes))
  assert(r.current.team==team and r.current.effective==condition,'wrong routed profile '..team..':'..condition)
  assert(ui.get(refs.pitch[2])>=-89 and ui.get(refs.pitch[2])<=89,'pitch range')
  assert(ui.get(refs.yaw[2])>=-180 and ui.get(refs.yaw[2])<=180,'yaw range')
  assert(ui.get(refs.body_yaw[2])>=-58 and ui.get(refs.body_yaw[2])<=58,'body range')
  r:reset();builder.states[team..':Standing'].override=true;routes=routes+1
 end
end
check('top-level builder routes all profiles for both teams',routes==22)
rt.references.freestanding_body={make('checkbox','native FS body',true)}
rt.current={settings={desync='Static',desync_direction='+'}}
rt.manual_applied=false;rt.legit_active=false
check('native automatic body side is not inferred from requested offset',rt:requested_body_left(rt.current.settings)==nil)
rt.native_owned={freestanding_body={original={false,n=1},applied=true}}
rt.freestanding_body=false
check('planned release of owned freestanding body uses requested side',rt:requested_body_left(rt.current.settings)==true)
FULL_PROFILE_ROUTES=routes
BUILDER_AUDIT_CHECKS={}
for i=previous_checks+1,#RESULTS do BUILDER_AUDIT_CHECKS[#BUILDER_AUDIT_CHECKS+1]=RESULTS[i]end
''')
checks=[v.decode()for _,v in lua.globals()[b'BUILDER_AUDIT_CHECKS'].items()]
report={'passed':True,'body_matrix_cases':lua.globals()[b'BODY_MATRIX_CASES'],
        'top_level_profile_routes':lua.globals()[b'FULL_PROFILE_ROUTES'],'checks':checks,
        'baseline_regression_checks':42,'game_executed':False,'actual_server_desync_measured':False,
        'scope':'configured body offset bounds and state-machine consistency; not a degree-to-server-desync calibration'}
(root/'builder_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

"""Scope viewmodel flag ownership/lifecycle tests, using weapon-library stubs."""
from pathlib import Path
import contextlib,io,json,runpy
root=Path(__file__).resolve().parents[1]
with contextlib.redirect_stdout(io.StringIO()):ctx=runpy.run_path(str(root/'tests/test_runtime_and_config.py'))
lua=ctx['lua']
lua.execute(b'''
local start=#RESULTS
local scoped,alive,player,weapon,id=1,true,1,100,9
local raw_a={hide_view_model_zoomed=true,zoom_levels=2,zoom_fov_1=40}
local raw_b={hide_view_model_zoomed=true,zoom_levels=2,zoom_fov_1=40}
local library={[9]={raw=raw_a},[40]={raw=raw_b},[8]={raw={hide_view_model_zoomed=false,zoom_levels=1,zoom_fov_1=55}}}
local requires=0
package.preload['gamesense/csgo_weapons']=function()requires=requires+1;return library end
entity={get_local_player=function()return player end,is_alive=function()return alive end,
 get_player_weapon=function()return weapon end,
 get_prop=function(e,name)
  if name=='m_bIsScoped'then return scoped end
  if name=='m_iItemDefinitionIndex'then return id end
 end,
 set_prop=function()error('scope feature must not change player prediction netprops')end}
local draw_value,draw_writes=0,0
cvar={r_drawviewmodel={get_int=function()return draw_value end,
 set_raw_int=function(self,v)draw_value=v;draw_writes=draw_writes+1 end},
 fov_cs_debug={set_int=function()error('must preserve zoom')end}}
local m={refs={world_select=make('multi','world',{'Viewmodel Changer'})},visuals={refs={
 viewmodel=make('checkbox','viewmodel',true),viewmodel_features=make('multi','features',{'Show in scope'})}}}
local world=SOURCES.visuals_world(modules);world:init(m)
world:pre_render()
check('scope option changes only the weapon hide flag and draw gate',raw_a.hide_view_model_zoomed==false and draw_value==1)
check('scoped state remains unchanged',scoped==1)
local writes=draw_writes;world:pre_render()
check('repeated render frame avoids redundant cvar writes',draw_writes==writes and requires==1)
ui.set(m.visuals.refs.viewmodel_features,{})
world:pre_render()
check('turning option off restores original values',raw_a.hide_view_model_zoomed==true and draw_value==0)
ui.set(m.visuals.refs.viewmodel_features,{'Show in scope'})
world:pre_render();id=40;world:pre_render()
check('weapon switch restores previous weapon data',raw_a.hide_view_model_zoomed==true and raw_b.hide_view_model_zoomed==false)
scoped=0;world:pre_render()
check('leaving scope restores weapon flag and cvar',raw_b.hide_view_model_zoomed==true and draw_value==0)
scoped=1;id=8;world:pre_render();world:restore_scope_viewmodel()
check('weapon whose original flag was false stays false',library[8].raw.hide_view_model_zoomed==false)
id=9;world:pre_render();alive=false;world:pre_render()
check('death releases owned values',raw_a.hide_view_model_zoomed==true and draw_value==0)
alive=true;world:pre_render();weapon=nil;world:pre_render()
check('missing weapon releases owned values',raw_a.hide_view_model_zoomed==true and draw_value==0)
weapon=100;world:pre_render();id=7;world:pre_render()
check('unsupported weapon does not mutate its data',raw_a.hide_view_model_zoomed==true and draw_value==0)
id=9;world:pre_render();ui.set(m.visuals.refs.viewmodel,false);world:pre_render()
check('master viewmodel switch releases scope feature',raw_a.hide_view_model_zoomed==true and draw_value==0)
ui.set(m.visuals.refs.viewmodel,true);world:pre_render()
ui.set(m.refs.world_select,{});world:pre_render()
check('world category deselection releases scope feature',raw_a.hide_view_model_zoomed==true and draw_value==0)
ui.set(m.refs.world_select,{'Viewmodel Changer'});world:pre_render();draw_value=2
world:restore_scope_viewmodel()
check('external draw-cvar change is preserved',draw_value==2)
draw_value=0;world:pre_render();raw_a.hide_view_model_zoomed=true
world:restore_scope_viewmodel()
check('external hide-flag change is respected',raw_a.hide_view_model_zoomed==true)
world:pre_render();local replacement={hide_view_model_zoomed=true,zoom_levels=2,zoom_fov_1=40};library[9].raw=replacement
world:restore_scope_viewmodel()
check('replaced library pointer is not overwritten during restore',replacement.hide_view_model_zoomed==true)
library[9].raw=raw_a;raw_a.hide_view_model_zoomed=true
world:pre_render();world:level_init()
check('level/disconnect cleanup restores scope flag',raw_a.hide_view_model_zoomed==true and draw_value==0)
world:pre_render();world:shutdown()
check('Lua shutdown restores scope flag',raw_a.hide_view_model_zoomed==true and draw_value==0)

-- Different IDs can share a descriptor; resnapshot only after the old restore.
library[40].raw=raw_a;id=9;world:pre_render();id=40;world:pre_render();world:restore_scope_viewmodel()
check('shared descriptor restores its actual original flag',raw_a.hide_view_model_zoomed==true)

-- An unknown installed schema must fail without touching arbitrary offsets.
library[9].raw={};id=9;world:pre_render()
check('unsupported weapon schema disables only this visual feature',world.failed['Show in scope']==true and draw_value==0)
library[9].raw={hide_view_model_zoomed=true,zoom_levels=256,zoom_fov_1=40}
world:level_init();world:pre_render()
check('inconsistent zoom layout is rejected before any write',world.failed['Show in scope']==true and library[9].raw.hide_view_model_zoomed==true and draw_value==0)
library[9].raw=raw_a;world:level_init();world:pre_render()
check('supported schema recovers on level reset',world.failed['Show in scope']==nil and raw_a.hide_view_model_zoomed==false)
world:restore_scope_viewmodel()
local setter=cvar.r_drawviewmodel.set_raw_int
cvar.r_drawviewmodel.set_raw_int=function()error('injected cvar write failure')end
world:pre_render()
check('draw-gate failure rolls back the weapon flag',world.failed['Show in scope']==true and raw_a.hide_view_model_zoomed==true and draw_value==0)
cvar.r_drawviewmodel.set_raw_int=setter;world:level_init()
scoped=true;world:pre_render()
check('boolean scoped property is accepted',raw_a.hide_view_model_zoomed==false)
player=nil;world:pre_render()
check('disconnect with no local player restores owned values',raw_a.hide_view_model_zoomed==true and draw_value==0)
player=1;scoped=0

-- The new Features item is accepted by the existing config schema/codec.
cfg.menu.visuals.refs=m.visuals.refs
local preset={name='Scoped hands',mask=4,data={visuals={controls={viewmodel_features={'Show in scope'}}}}}
check('new option passes legacy config validation',cfg:validate_entry(preset)==true)
local encoded=cfg.encode_preset(preset);local decoded=cfg.decode_preset(encoded)
check('new option roundtrips through config codec',decoded.data.visuals.controls.viewmodel_features[1]=='Show in scope')
SCOPE_CHECKS={};for i=start+1,#RESULTS do SCOPE_CHECKS[#SCOPE_CHECKS+1]=RESULTS[i]end
''')
checks=[v.decode()for _,v in lua.globals()[b'SCOPE_CHECKS'].items()]
report={'passed':True,'scope_behavior_checks':len(checks),'checks':checks,'baseline_checks':42,
        'uses_installed_weapon_library_layout':True,'hardcoded_weapon_data_offsets':False,
        'player_prediction_props_written':False,'fov_override_used':False,
        'native_ffi_executed':False,'game_executed':False,
        'limits':['Weapon data and cvar APIs are controlled fixtures; actual in-game drawing remains untested.']}
(root/'scope_viewmodel_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

"""Reproduce timing/side bugs in the previous nyameeow.pink release."""
from pathlib import Path
import contextlib,io,json,runpy
root=Path(__file__).resolve().parents[1]
with contextlib.redirect_stdout(io.StringIO()):context=runpy.run_path(str(root/'tests/test_runtime_and_config.py'))
lua=context['lua']
previous=root/'reference/nyameeow.previous.txt'
if not previous.exists():previous=Path('/workspace/output/nyameeow_pink/nyameeow.pink.lua')
s=previous.read_bytes();a=s.index(b"['builder_runtime'] = ")+len(b"['builder_runtime'] = ")
b=s.index(b"['anti_bruteforce'] = ",a);chunk=s[a:b].strip();assert chunk.endswith(b',')
lua.globals()[b'OLD_BUILDER']=lua.execute(b'return '+chunk[:-1])
lua.execute(b'''
OLD_RESULTS={}
local function oldcheck(n,v)assert(v,n);OLD_RESULTS[#OLD_RESULTS+1]=n end
local old=OLD_BUILDER(modules);old.references=rt.references;old.aa_ready=true;old.body_ready=true
local function s(mode)return {desync=mode,desync_direction='+',second_yaw=true,delay_enable=true,
 delay_mode='Sequential',delay_count=1,delay_1=1,delay_features={},desync_invert_chance=100}end
local function cmd(n)return {command_number=n,chokedcommands=0}end
local p=s('Static');old:update_lr(p,cmd(1),'Terrorist','Standing');local first=old.lr.left
old:update_lr(p,cmd(2),'Terrorist','Standing');old:update_lr(p,cmd(3),'Terrorist','Standing')
oldcheck('previous Static path ignores explicit yaw delay',old.lr.left==first and old.lr.source=='static')
p=s('L/R Desync');old.lr=nil;old:update_lr(p,cmd(10),'Terrorist','Standing');first=old.lr.left
old:update_lr(p,cmd(10),'Terrorist','Standing')
oldcheck('previous initial command replay consumes a phase',old.lr.left~=first)
old.lr.freeze_until=99999;old:update_lr(p,cmd(11),'Counter-Terrorist','Air')
oldcheck('previous state switch retains old freeze timer',old.lr.freeze_until==99999)
p=s('Jitter');p.desync_value=-58;old.lr={left=true};old.current={settings=p};old.inverter_active=false
old.defensive_anim={phase=0,sample_time=0};old:apply_body(p,cmd(20))
local d={defensive_pitch='Keep',defensive_yaw='Custom',defensive_yaw_value=10,
 defensive_yaw_second=70,defensive_yaw_add_second=true,defensive_yaw_switch='Desync'}
local _,yaw=old:defensive_angles(d,cmd(20))
oldcheck('previous negative jitter selects the opposite defensive side',ui.get(old.references.body_yaw[2])==58 and yaw==10)
''')
report={'passed':True,'previous_release_bugs_reproduced':4,
        'checks':[v.decode()for _,v in lua.globals()[b'OLD_RESULTS'].items()],'game_executed':False}
(root/'builder_previous_reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
